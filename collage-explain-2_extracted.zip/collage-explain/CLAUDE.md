# Instructions for the agent using this skill
0. Read rule.md FIRST and follow it literally. It overrides your own ideas.
1. Read SKILL.md next, including "Lessons learned" and "Known gaps".
2. Do not guess when a request is unclear; ask one short question. Ask for timestamps when frames are reported wrong.
3. Keep code changes surgical; compare reference and render side by side before editing.
4. Draft at 720p/15 fps first; render 1080p/30 only after the user says "render it". Run ffprobe QA after every render.
5. When code improves, add the lesson to SKILL.md "Lessons learned" so the next video starts better.
6. For ANY new video: follow "NEW PIPELINE" in SKILL.md (script -> auto_cast -> check_cast -> story-data.js -> probe -> draft). Characters come only from the cast sheet; never reuse man()/girl().
