---
name: collage-explain
description: Build a 9:16 "collage explain" video - a paper-cutout story told with jointed paper puppets, painted gradient backdrops, torn-paper caption chips with a moving red word, and narration. Use when the user wants an explainer or true-story short in this look, or wants the Nirma-story video re-made, or says "collage explain style".
---

# Collage Explain style

**Read `rule.md` first. Its rules are mandatory for any agent using this skill.**

Paper-cutout storytelling. Every frame is drawn by `scripts/runtime.js` as a pure function of time (`render(t)`), rendered frame by frame in Chromium, and muxed with the narration by ffmpeg.

## Look (copy the reference; do not invent a different look)
- Canvas: logical 360x640 (9:16). Draft 720x1280 @15 fps (`--scale 2`). Final 1080x1920 @30 fps (`--scale 3`), only after the user says "render it". 16:9 is NOT built yet (needs a re-layout, not a crop).
- Palette (muted, warm): cream #F3EDE0, ink #1F1A18, red #C0392B, mustard #F2B705, blue #2457A6, skin #B5784B. Grade the whole frame: saturate .8, contrast .95, sepia .12.
- Texture: fibre grain pattern clipped inside every cut-out (multiply, .45) + inner dark rim; white cut edge 2.2 px; soft drop shadow; creased-paper overlay (overlay, .6); vignette; blotchy painted washes on every gradient fill; far layers blurred.
- Type: Anton (OFL), 29 px caps. Caption chip = torn white strip at about 75% height, 2-3 words, small random tilt, pop-in with overshoot. ONE word per chip is red and the red word moves along the phrase with the voice. No chips during full-screen title cards.
- Pacing: one clause per board, boards 2-4 s, hard board-slap transition (new board slides over in 0.16 s with a dark edge shadow). About 3.3 spoken words per second.
- Motion: camera drift (4% zoom per scene), push-ins on emotional beats, idle life on every figure (breathing 0.6%, head bob, arm sway 1.6 deg, blink 0.13 s every 2.7 s), stepped 8 fps edge "boil".
- Allowed: cut paper, brass brad pins, tape, torn tags, glows, bokeh, rain, sparkles, dotted construction lines. Forbidden: flat halftone/vector-clean look (rejected by the user in v1), real photos of people, copyrighted logos beyond the story's own product.

## The puppet (core.js `man()`, `girl()`, `head()`, `arm()`)
- Proportions at scale 1: torso 120x135 with sloped shoulders, head radius 50 drawn at 0.9, full figure about 340 tall (use scale 1.0-1.15 for full body).
- Jointed arms: sleeve 26 wide + brown forearm 18 wide, brass brads at shoulder and elbow, knee brads on trousers. Angle 0 = hanging down, 90 = horizontal, 180 = up; `side` -1 left, +1 right.
- Face: small half-lidded eyes, thick but small mustache, thin angled brows, cheek blush, side-parted hair with highlights. Moods: smile, grin, open, flat, sad (+ `wide`, `shut`, `happy`, `tear`).

## Workflow
1. Study the reference: frame every 0.5 s (contact sheets), scene cuts, loudness, speech onsets -> `reference/`.
2. Write `idea.md` + `script.md` first (script from captions or `scripts/transcribe.py`).
3. Define boards as `S.push([start,end,(u,d)=>{...}])` in `scenes.js` part of runtime.js and chips in `CH`.
4. Probe frames (`probe` pattern: render(t) -> jpeg), compare side by side with the reference BEFORE changing code.
5. Draft 720p/15: `python3 scripts/render.py --html examples/<name>/index.html --audio <voice> --fps 15 --scale 2 --out draft.mp4`; ffprobe QA; show the user.
6. On "render it": `--fps 30 --scale 3`, ffprobe QA again.
7. Optional sound: `make_sfx.py`, cue sheet, `mix.py` to -14 LUFS / -1 dBTP.

## Lessons learned (apply these before the first draft)
Look and texture
- The user wants the reference copied closely. Compare reference vs render side by side before any change; do not invent a new look.
- Painterly beats flat: gradient + washes + blurred far layers + grain tooth + inner rim + crumple overlay + global grade. Clean vector fills read as "not the reference".
- Faces: sleepy small eyes and a smaller mustache match the reference; big round cartoon eyes and a big head do not (head scaled 0.9, ears small).
- Sad brows need the INNER ends raised; inverted brows look angry.
Body must look complete (the "looks cut" fixes)
- Bust scenes need real shoulders + neck + collar + buttons, never a plain dome under a floating head.
- Show legs whenever the camera shows the full figure; hide them only once a table covers the lap.
- Seated figures need a seat plank in front and legs below it; backrest slats behind the shoulders, not across the chest.
- Props must sit within arm reach (basin, flask, stamp) and never behind or over the face; put idea props beside the character.
- When zooming into the face, put the zoom centre on the face. Clip close-up photos and keep the eyes visible inside the frame.
Visuals must match the narration (the "doesn't match the video" fixes)
- Caption timing was measured against speech onsets: median offset 0.04 s, mean 0.11 s. Timing is fine; check CONTENT instead.
- Every noun in a line needs a recognisable visual: "car" -> a car with headlights; "factory" -> sawtooth roof + chimney; "distributor" -> a truck. Show a prop only after the line that introduces it (bag and ribbon only after the crash).
- If two idea-outlines would overlap, fade the first out when the second appears.
Cast variety (user's agent failed here)
- One face template with colour swaps makes every character identical. Use a cast sheet + one parametric person function (build, height, head shape, hair, skin, facial hair, glasses, outfit); give old people grey/thin hair and wrinkles; sleepy eyes only for calm/tired; stage groups in two depth rows on shared ground lines; one caption system at a time; export full-frame with no black bars. See agent_prompt_fix_characters.md.
Process
- Ask for exact timestamps when the user says "some frames are wrong"; do not guess and re-render repeatedly (each full draft render is about 3-4 minutes).
- Keep patches surgical (string replace with an assert that the old text exists).

## NEW PIPELINE: script -> cast -> scenes -> animation (use this for every new video)
Never use `man()` / `girl()` / `head()` for new videos (they are ONE fixed face; that is why every character looked the same). They only exist for the old Nirma example.
1. Write `script.md`, then split it into lines with start/end times (from the voice or `transcribe.py`).
2. Make the cast from the script:
   - list every character (id, role, age child/young/adult/old, gender m/f) in `roles.json`
   - `python3 scripts/auto_cast.py roles.json cast.json --seed 1`  (guarantees >=5 differences between any two people; you may pin fields such as outfit or hair_style)
   - `python3 scripts/check_cast.py cast.json --out qa` -> look at `qa_lineup.png` and `qa_silhouettes.png`. Exit code 1 = two characters too alike: fix before going on.
3. Write `story-data.js` (see `examples/cast-demo/`): `window.CASTLIST=<cast.json>; window.STORY={duration, scenes:[...]}`.
   Per scene: `start,end,bg` (shop_night, classroom, home_day, bedroom_night, street_day, lab, sunset_roof), `cast:[ids]`, `lines:[{start,end,text,speaker,emotion,gesture,reactions:{id:emotion},gestures:{id:gesture}}]`.
   - Emotions: calm tired bored happy proud laugh surprised shocked sad crying worried angry shouting singing thinking determined love (sleepy eyes ONLY calm/tired/bored).
   - Gestures: point point_left hand_on_chest hands_on_hips wipe_tear rub_eyes scratch_head cup_ear wave clap cheer think shrug hold hold_up stretch count cry_hands hug idle_a.
   - Every line needs a speaker, an emotion and a gesture that fit the words. Listeners get `reactions` so nobody just stands there.
4. `index.html` = runtime.js + cast.js + story.js + story-data.js (copy `examples/cast-demo/index.html`). Staging, ground lines, shadows, lip-sync, blinking, captions (2-3 word chips, max 75% width) are automatic.
5. `python3 scripts/probe.py examples/<n>/index.html --every 2 --out probe` -> contact sheet; check every scene (rule.md section F), then draft render, then ffprobe. Final 1080p only after "render it".
`makePerson(spec,x,floorY,s,{emotion,gesture,u,talk,look,lean,nolegs})` is the only way to draw people. (x, floorY) is the FEET position, so all people of a row share one ground line.

Actions (whole-body animation, set per line with `action:` or per other character with `actions:{id:..}`): walk_in walk_out step step_back hop jump jump_fail anticipate_jump laugh shake tremble lean_in sag tumble turn_away bow. Scene `cam`: push pull pan_left pan_right; line `shake:true` for impact. Run `python3 scripts/motion_check.py <index.html>` before showing anything (exit 0 required). See rule.md section I.

Lessons learned (cast system)
- Same-face bug = one drawing function + colour swaps. Fixed by `makePerson(spec)`: head shape, hair (10 styles), facial hair, glasses, brows, eyes, nose, ears, wrinkles, build, outfit (9 outfits drawn separately) all come from the cast sheet.
- Place people by feet (floorY), not by belt, so heights differ but ground lines match.
- Tallest people go to the back row, shortest to the front, otherwise a child disappears behind adults.

## Known gaps (be honest about these)
- Art is code-drawn, so it is simpler than the painted reference. For painted quality the user must supply or generate images; the engine can then animate them.
- On badge frames the letter "I" in NIRMA reads like a slash for a moment.
- 16:9 not built. `build_band.py` / `gen_web_assets.py` from the blueprint were not made: this engine draws everything procedurally, so there is no HTML band DSL or web asset pipeline to feed.
- `transcribe.py` and `fetch_images.py` were written but not run (no network in the build sandbox). `make_sfx.py`, `mix.py`, `gen_assets.py`, `render.py` were run and work.
- The approved draft uses the reference narration as its voice; no new Hinglish voice could be generated there.
