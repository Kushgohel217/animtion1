# collage-explain (skill)
Paper-cutout explainer videos: jointed paper puppets, painted backdrops, torn-paper captions. See SKILL.md for the spec and lessons.

## Quick start
```bash
bash setup.sh
python3 scripts/render.py --html examples/nirma-story/index.html --audio <narration.wav|mp4> --fps 15 --scale 2 --out draft_720p.mp4
ffprobe -v error -show_entries stream=codec_name,width,height,r_frame_rate:format=duration -of default=nw=1 draft_720p.mp4
# final, only after approval:
python3 scripts/render.py --html examples/nirma-story/index.html --audio <narration> --fps 30 --scale 3 --out final_1080p.mp4
```
Optional sound: `python3 scripts/make_sfx.py`, write a cue sheet (see scripts/mix.py), `python3 scripts/mix.py cues.json mix.wav`, then mux:
`ffmpeg -i final_1080p.mp4 -i mix.wav -map 0:v -map 1:a -c:v copy -c:a aac -b:a 192k -shortest out.mp4`

## Script-driven videos with a different cast
See SKILL.md "NEW PIPELINE" and `examples/cast-demo/` (6 different characters, 4 scenes, emotions + gestures per line):
`python3 scripts/render.py --html examples/cast-demo/index.html --fps 15 --scale 2 --out draft.mp4`
