# RULES FOR THE AGENT (read fully, follow every rule, no exceptions)

You are weak at coding and at guessing what the user wants. So: follow these rules literally. When a rule and your idea disagree, the rule wins.

## A. How to behave
1. If the request is unclear, ask ONE short question. Never guess.
2. Before changing code, say in one line what you will change and why. After changing, say what you checked.
3. Change only what the user asked. Do not "improve" other code. Do not rename, reformat or reorganise.
4. Do the smallest change that works. If 200 lines can be 50, write 50.
5. Never say a video is good until you have LOOKED at frames (rule F). Never claim something works unless you ran it.
6. If something fails, say what failed. Do not hide it. Do not pretend.
7. When you fix something, add one line to SKILL.md "Lessons learned" so the next video starts better.

## B. Coding rules (this is where you fail most - be careful)
1. Always read the file before editing it. Edit with exact string replace; the old text MUST exist (assert it). If the replace fails, stop and re-read.
2. One change -> render 3 test frames -> look -> next change. Never make 10 changes and then render.
3. Every frame is a pure function of time: `render(t)`. Do not keep state between frames. No `Math.random()` inside scenes; use the seeded `R(seed)`.
4. Wrap transforms: every `ctx.translate/rotate/scale` must be inside `ctx.save()` ... `ctx.restore()`. Count them. Unbalanced save/restore breaks every later object.
5. Draw order (back to front) is fixed: sky/wall -> far props (blur them) -> mid props -> character -> foreground (table, counter, bench seat) -> glow/particles -> caption. Never draw a prop that should be behind the character after the character.
6. Never hide an error. Open the page console / `pageerror` output. Any `PAGE ERROR` means the render is invalid.
7. Use the helpers, do not write new drawing code if a helper exists: `paper()`, `rrect()`, `ell()`, `poly()`, `circ()`, `glow()`, `sky()`, `mottle()`, `wash()`, `blur()`, `man()`, `girl()`, `packet()`, `boxBlue()`, `cloth()`.
8. Time inside a scene is `u` (seconds since the scene started). Use `u` for everything. Convert like this: prop appears when `u>T`, animates with `ease((u-T)/dur)`; pop-in uses `back((u-T)/dur)`.
9. Keep numbers explicit. Do not write magic formulas you cannot explain. Comment only what is not obvious.
10. Draft render: `--fps 15 --scale 2` (720x1280). Final: `--fps 30 --scale 3` (1080x1920) ONLY after the user says "render it". Always run ffprobe afterwards and report width, height, fps, duration.

## C. Character rules (alignment)
Canvas is 360 wide x 640 tall. Origin top-left. y grows downward.

Man: `man(x, y, s, opts)`
- (x, y) = belt line, centre of the body. NOT the feet and NOT the head.
- At s=1: head centre is 184 above y, torso top 138 above y, shoulders at 118 above y and 62 left/right of x, legs go 0..108 below y, shoes at +116. Full height about 350*s. Use s between 0.8 and 1.15.
- FEET ON THE FLOOR: floor line = y + 126*s. Put a soft shadow ellipse under the feet: `ell(x, floor, 60*s, 8, 'rgba(60,30,10,.3)', {ns:1,ne:1})`.
- Bust shots (counter/desk/bench in front): pass `nolegs:1`, and the counter/desk must be drawn AFTER the man and must cover the belt line. Never leave a belt floating in the air.
- Camera shows the full figure -> legs MUST be drawn (no `nolegs`).
- Arms: angle 0 = hanging down, 90 = horizontal outward, 180 = straight up. Elbow `bL/bR` bends the forearm (negative = toward the body). Left arm is `aL`, right arm is `aR`.
- To hold something, use the `hL` / `hR` callback: it draws in the hand's own coordinates (0,0 = palm). Never place a held object with world coordinates.
- Props the character touches (basin, flask, stamp, packet) must be inside arm reach: horizontal distance from the shoulder <= 100*s and vertical <= 110*s.
- NEVER put a prop on the face. Keep a 60 px clear zone around the head centre.
- Zooming into a face: set the zoom centre = the head centre. Keep both eyes inside the frame.
- Two characters: the one further back is drawn first and is smaller (s 0.8-0.9). Keep at least 30 px between their bodies unless they touch on purpose (hold hands).
- Girl: `girl(x, y, s)`, (x,y) = waist, head centre 84 above, feet 137 below, skirt width `sw` 40-70.
- Seated figure: bench/chair back slats BEHIND, seat plank IN FRONT of the lap, legs visible below the plank.
- Bust without legs must still show shoulders + neck + collar. Never a plain dome under a floating head.

Face / mood (use `mouth`: smile, grin, open, flat, sad; extras `wide`, `shut`, `happy`, `tear`)
- Happy = smile/grin + `shut:1,happy:1` for laughing. Worried/sad = `mouth:'sad'`. Shock = `mouth:'open', wide:1`. Calm = `flat`.
- Sad eyebrows must slope UP towards the nose. If he looks angry, the brows are wrong - fix before shipping.
- Half-lidded eyes are ONLY for calm, tired or bored. Shock = wide round eyes, happy = open or curved shut, sad = lowered. Using sleepy eyes on every face is a bug.

## D. Background rules
1. Never use a flat colour. Every background = `sky(y0,y1,[[0,c1],[1,c2]])` (gradient) + the automatic wash. Add `mottle()` for clouds/painted blotches.
2. Build 4 layers: (1) sky or wall, (2) far shapes (city, hills, shelves) drawn inside `blur(1..1.5, ...)`, (3) mid props, (4) floor/foreground. Far layers are lighter and blurrier, near layers darker and sharper.
3. Horizon / floor line sits at 55-65% of the height (y 350-420) unless the story needs otherwise.
4. Colours are muted and warm. Sunset: pink #A24E72 -> orange #E98B52 -> pale yellow #F8D88E. Night: navy #1F2750 -> purple #3E4290. Lab: pale blue #D3E7EB + teal #1F7A73. Shop: teal #1E706A. Do not use pure #FF0000 / #00FF00.
5. Light sources (sun, lamp, lantern, bulb, moon) always get `glow(x,y,r,'R,G,B',alpha)`. Lamps also get `lampcone`.
6. Every scene has at least 6 props that tell where we are (clothes on a line, flasks, clock, shelves of boxes, houses...). An empty background is a bug.
7. Every noun in the narration needs a recognisable picture: car, factory, truck, bag, photo, packet. Show the picture only AFTER the line that introduces it.
8. Props that explain an idea go beside the character, never behind the body.
9. Text on the screen stays inside x 20..340. Caption chip is at y=484 (29 px Anton). Keep important action above y=450.

## E. Animation rules
1. Every figure must always be alive: breathing, head bob, arm sway, blink. This is built into `man()`/`head()`; do not remove it. Do not freeze a character.
2. Motion timing (seconds): pop-in 0.12-0.35 with `back()` overshoot; slide-in 0.6-0.9 with `ease()`; board transition 0.16; stamp/pour/stir = stepped (`st(u)`, 10 steps per second); camera drift = 4% zoom over the scene; push-in = 1.0-1.3 zoom over 0.7-1.3 s.
3. Emotional beats need a camera move (push-in) or a colour change, not just a pose.
4. Anything that appears should arrive with motion (slide, pop, grow, drop). Nothing just "turns on", except lights.
5. Captions: chips of 2-3 words, change every 0.5-1.0 s, exactly when those words are spoken (check against speech onsets, tolerance 0.15 s). One red word that moves along the chip. No chips on full-screen title cards.
6. Transition between boards: the new board slides in from the right in 0.16 s over the old one with a dark edge shadow.
7. Texture/finish is NOT optional: grain tooth in every cut-out, creased-paper overlay, vignette, global grade (saturate .8, contrast .95, sepia .12). Skip it and the video looks fake.

## F. Before you show the user (checklist - answer each with yes/no)
1. Did the render finish with no `PAGE ERROR`?
2. Did I look at one frame from EVERY scene (contact sheet), not just the first scene?
3. Is any character cut, floating, missing legs, or holding something out of reach?
4. Is any prop covering a face?
5. Does every spoken noun have a visible picture at that time?
6. Is any area of a frame empty or flat-coloured?
7. Do captions match the voice (look at 5 random chips against the audio)?
8. Does ffprobe show the right size, fps, duration and an audio stream?
If any answer is bad, fix it first. Then show the user and list honestly what is still weak.

## G. Never do
- Never invent a new visual style. Copy the reference look.
- Never render the 1080p final before the user says "render it".
- Never re-render the whole video to test a small change: probe 3-5 frames with `probe.py`-style code first.
- Never delete files the user did not ask you to delete.
- Never tell the user "done" if you did not look at the output.

## H. Cast variety (mandatory - the last agent made everybody look the same)
0. New videos MUST draw people only with `makePerson()` from scripts/cast.js, with the cast made by `scripts/auto_cast.py` and checked by `scripts/check_cast.py`. Using `man()`/`girl()` for new videos is forbidden. Follow "NEW PIPELINE" in SKILL.md.
1. Before drawing, write cast.json: every character differs from every other in at least 5 of: build, height, head shape, hair style, hair colour, skin tone, facial hair, glasses, outfit, outfit colour, accessory.
2. One parametric `makePerson(spec)`. Never copy `man()` and swap colours. Old people get grey/white/thin hair or bald plus wrinkles. Children get a big head and short legs.
3. Each script line has an explicit emotion; the face is drawn from it (see agent_prompt_fix_characters.md section 5).
4. Groups: two depth rows, one ground line per row, overlapping bodies, different heights. Never a straight row of identical figures with arms hanging.
5. Test before showing: lineup.png and silhouettes.png. If two characters look alike, fix them.
6. One caption system at a time, chip width <= 75% of the screen, exported full-frame with no black bars.


## I. Animation is mandatory
I1. A video is not finished if two consecutive 1-second samples show the same pose. Every second needs at least 3 things moving (e.g. body action, arm gesture, mouth, blink, camera, ambient).
I2. Every script line has an `action` (whole-body move) or a clearly different gesture + emotion than the previous line. No pose is held longer than 1.2 s.
I3. Every scene has: one entrance or exit (walk_in/walk_out/step) OR one big action (jump, tumble, sag), one camera move (`cam`), and animated background/ambient life.
I4. Emotion must match the words. Half-closed "sleepy" eyes only for calm/tired/bored lines. A fox that fails and gets angry needs `angry`/`sad`/`shocked`, not `calm`.
I5. Show the story, not the narration. If the line says "he jumped", the character jumps. If it says "he walked away", he walks out of the frame.
I6. Secondary characters (monkey, crowd) must react to the speaker with their own action each line (laugh, lean_in, step_back). Never a static prop.
I7. Character height >= 55% of the frame, feet always visible above the caption chip, bottom third never empty.
I8. Anticipation and follow-through: before a jump use `anticipate_jump` (0.3 s squash), after a landing let the body settle (the ACTS table does this). Never teleport.
I9. No repeated decorations (same sign/label every scene), no empty thought bubbles, nothing covering a character.
I10. Run `motion_check.py` and the contact-sheet check. Report the numbers; if it fails, fix and rerun. Do not say "done" on a failed check.
