# AGENT PROMPT: make the video ANIMATED (fox-and-grapes contact sheet = what NOT to ship)

You are fixing a Hinglish paper-puppet explainer ("Angoor khatte the": fox, monkey, grapes). Skill: `collage-explain` (read SKILL.md and rule.md first, especially "NEW PIPELINE" and section I below).

## 1. What is wrong in the current video (checked frame by frame, 15 frames)
1. **It is a slideshow, not an animation.** In all 15 frames the fox is in the same spot with the same pose (left hand holding a paper, right arm out). Nothing in the story is acted: no walking in, no jumping at the grapes, no falling, no walking away.
2. **Same face every frame.** Heavy half-closed "sleepy" eyes in almost every frame, even for the lines "koshish karna chhod" and the moral. Emotion never matches the words.
3. **Story beats are not shown.** The script is a fable (see grapes, try, fail, call them sour, walk away, moral about hard work and right time). The visuals only swap 3 backgrounds (forest, green grapes, purple grapes). The grapes are never reached for, never moved, never touched.
4. **Feet are hidden.** The caption chip covers the fox's legs. The character floats in the lower-middle with the bottom 35% of the frame wasted on empty road with dashes.
5. **Characters are too small and the monkey is a prop.** The monkey sits tiny in a corner in the same pose and never reacts (it should laugh at the fox).
6. **No camera, no life in the background.** No push-in, no parallax, grapes and trees never sway, no moving leaves, birds only appear as stickers.
7. **Clutter that does nothing:** the "ANGOOR" sign repeats in every frame, the thought bubble is empty dots, the QR code in the last frame covers the monkey.

## 2. Do this (in order)
1. **Beat sheet first.** For every script line write ONE visible verb: e.g. `walks in`, `looks up`, `crouches`, `jumps`, `misses and falls`, `jumps again`, `slumps`, `turns away`, `shrugs`, `monkey laughs`. A line with no verb is not allowed. Save as `beats.md`.
2. **Cast.** Use `makePerson` only (no man()/girl()/fox copy with fixed arms). Fox and monkey need their own animal heads/bodies in cast.js style (ears, snout, tail that moves). Run `check_cast.py`.
3. **story-data.js.** For every line set `speaker, emotion, gesture` AND `action` (from the ACTS list: walk_in walk_out step step_back hop jump jump_fail anticipate_jump laugh shake tremble lean_in sag tumble turn_away bow) and `actions:{id:action}` for the other characters. Set `cam` for every scene (push, pull, pan_left, pan_right) and `shake:true` on shock lines.
4. **Story sequence for this video (minimum):** fox walks in (walk_in, happy) > sees grapes (look up, surprised) > crouch (anticipate_jump) > jump (jump) > miss, land hard (jump_fail, sad) > second try, third try (jump, jump_fail, tired) > monkey laughs (laugh, actions on monkey) > fox slumps (sag) > "angoor khatte hain" (turn_away, shrug, proud-but-fake smile) > walks out (walk_out) > moral scene: purple ripe grapes at sunset, fox returns with a ladder or monkey helps, right time + hard work (step, hold_up, cheer) > CTA card.
5. **Framing.** Character height >= 55% of the frame. Feet at y <= 440, caption chip below the feet, never over them. No empty bottom third: ground band <= 20% of the frame, fill the rest with the scene (grass, roots, fallen grapes, shadows).
6. **Make the world move.** Grapes bunches swing, leaves sway, 10+ ambient particles drift (already in story.js `ambient`), birds FLY across (not stickers), background drifts slowly (already in story.js). Props react to the action: when the fox jumps and misses, one grape bunch bounces; when he gives up, one leaf falls.
7. **Remove clutter.** Show the keyword sign once at the start, not in every scene. Thought bubbles must contain an icon (grape, question mark) or be removed. The QR card goes in the last 2 seconds in a free corner, never over a character.
8. **Check before showing the user:**
   - `python3 scripts/check_cast.py cast.json --out qa` (exit 0)
   - `python3 scripts/motion_check.py examples/<n>/index.html` (exit 0; fails if any 1.5 s window is static or a scene has no action)
   - `python3 scripts/probe.py examples/<n>/index.html --every 1 --out probe` and LOOK at the sheet: the character position or pose must differ between neighbouring frames, feet visible, no frame with the same pose as the previous one.
   - Draft render with `render.py`, then `ffprobe` (duration, size, audio).
9. Final 1080p only after the user says "render it".

## 3. RULES to add to rule.md (section I, "Animation is mandatory")
I1. A video is not finished if two consecutive 1-second samples show the same pose. Every second needs at least 3 things moving (e.g. body action, arm gesture, mouth, blink, camera, ambient).
I2. Every script line has an `action` (whole-body move) or a clearly different gesture + emotion than the previous line. No pose is held longer than 1.2 s.
I3. Every scene has: one entrance or exit (walk_in/walk_out/step) OR one big action (jump, tumble, sag), one camera move (`cam`), and animated background/ambient life.
I4. Emotion must match the words. Half-closed "sleepy" eyes only for calm/tired/bored lines. A fox that fails and gets angry needs `angry`/`sad`/`shocked`, not `calm`.
I5. Show the story, not the narration. If the line says "he jumped", the character jumps. If it says "he walked away", he walks out of the frame.
I6. Secondary characters (monkey, crowd) must react to the speaker with their own action each line (laugh, lean_in, step_back). Never a static prop.
I7. Character height >= 55% of the frame, feet always visible above the caption chip, bottom third never empty.
I8. Anticipation and follow-through: before a jump use `anticipate_jump` (0.3 s squash), after a landing let the body settle (the ACTS table does this). Never teleport.
I9. No repeated decorations (same sign/label every scene), no empty thought bubbles, nothing covering a character.
I10. Run `motion_check.py` and the contact-sheet check. Report the numbers; if it fails, fix and rerun. Do not say "done" on a failed check.

## 4. Report back
Tell the user in 5 lines: which beats were animated, which actions each scene uses, the motion_check result, what is still weak, and the draft file name.
