# PROMPT FOR THE VIDEO AGENT - paste everything below this line

You are making a paper-puppet story video with the collage-explain skill. Read rule.md and SKILL.md first. Your last video had serious problems. Fix ALL of them. Do not skip any point. Do not tell me it is done until you finish section 11.

## 1. What was wrong in your last video (I checked 4 frames)
1. EVERY character has the same face. The old man, the middle-aged man and the woman all use the same head, the same black bowl-shaped hair, the same half-asleep eyes, the same mouth. Only colour, glasses or a bun changed.
2. Every face has sleepy half-closed eyes, even when the character is shocked or singing.
3. The old man has black hair. Old people need grey or white or thin hair or a bald head.
4. All bodies are the same box with the same arms. No thin, heavy, short, tall, child.
5. Three people stand in a straight line, facing the camera, arms hanging, same size, same pose. It looks like a mannequin shop.
6. Feet are not on one ground line: the middle man's feet are lower than the others and his legs look shorter. A caption covers his legs.
7. Backgrounds are nearly empty: flat navy wall + brown counter + one lamp. Not enough props.
8. The same words are shown twice at once (a taped note "AALSI THA! SO GAYA!" and a chip "SO GAYA"). One chip is almost the full screen width.
9. The video is not full-frame: black bars at the top and bottom.
10. Characters hang their arms down and do nothing. No acting.

## 2. Goal
Every character is recognisable from its SILHOUETTE alone. The cast looks like different real people. Every moment has acting, depth and a full background.

## 3. Step 1 - write the CAST SHEET before any drawing code
Create `cast.json`. One entry per character with these fields:
id, role, age (child / young / adult / old), build (thin / medium / heavy), height_scale (0.75 child ... 1.15 tall), head_shape (round / oval / square_jaw / pointed), head_width (0.85-1.1), skin_hex, hair_style, hair_hex, facial_hair (none / mustache / beard / grey_mustache), glasses (true/false), brow (thin / thick / bushy), eye_shape (almond / round / narrow), nose (small / medium / big), ear (small / big), outfit (kurta / shirt_tie / lab_coat / saree / school_uniform / sweater / apron / dhoti / frock), outfit_colours (2-3 hex), accessory (watch / bindi / pen_in_pocket / topi / shawl / bag / none), signature_pose.

RULE: any two characters must differ in at least FIVE of: build, height, head_shape, hair_style, hair_colour, skin tone, facial_hair, glasses, outfit, outfit colour, accessory.
Example cast (change as the story needs):
- Father, 40s, medium, 1.0, oval head, side-part black hair, thick black mustache, white shirt + brown tie, pen in pocket.
- Grandfather, 70s, thin, 0.95, long head, bald top with white side hair, white bushy mustache, round glasses, blue kurta, shawl.
- Mother, 30s, medium-heavy, 0.95, round head, hair bun, no facial hair, bindi, red-gold saree.
- Daughter, 8, 0.6, big round head (head = 1/3 of body), two long braids with red ribbons, white frock with blue band.
- Shopkeeper, 50s, heavy, 1.05, square jaw, grey crew-cut, grey mustache, check shirt, apron.
- Scientist, 30s, thin, 1.1, pointed chin, curly black hair, thin mustache, white lab coat.

## 4. Step 2 - build ONE parametric function, not copies
Write `makePerson(spec)` that draws a person from the cast entry. Do NOT copy `man()` and change colours.
- Head: draw the head path from head_shape + head_width. Ears from `ear`. Nose from `nose`.
- Hair: at least 8 different styles (side_part_short, bald_with_side_hair, grey_thin, bun, long_braid, two_braids, topi_cap, curly, crew_cut). Hair covers the forehead edge naturally. NEVER one bowl-shaped cap for everybody.
- Old age: add wrinkles (forehead lines, lines beside the eyes and mouth), grey/white hair, slightly bent back (tilt torso 3-5 degrees).
- Facial hair, glasses, brows from the cast sheet.
- Body: torso width from build (thin 100 / medium 120 / heavy 145 at scale 1), arm thickness from build, shoulders and belly shape change. Child: shorter legs, bigger head.
- Outfits: each outfit is its own drawing (collar, buttons, folds, saree pleats and pallu, lab-coat lapels, apron straps, school-uniform tie). Not only a colour change.
- Keep the brass pins at shoulders, elbows and knees, the white cut-edge outline, the paper grain.

## 5. Face acting - eyes are NOT sleepy by default
Each line of the script gets an explicit emotion in the scene data. Draw the face from the emotion:
| emotion | eyes | brows | mouth |
|---|---|---|---|
| calm / tired / bored | half-lidded (ONLY here) | flat | small flat |
| happy | open, or curved shut when laughing | slightly raised | smile / grin |
| surprised / shocked | wide round, small pupils | high | open O |
| sad | slightly lowered, looking down | inner ends UP | corners down, tear if needed |
| worried | open, looking sideways | inner ends up, one higher | small, wobbly |
| angry | narrow | inner ends DOWN | tight |
| singing / shouting | open or shut | raised | wide open with teeth |
| thinking | looking up or to the side | one brow up | pursed |
Blink every 2-3 s. Different characters blink at different times. Pupils may look at what the character looks at.

## 6. Body acting - nobody stands with arms hanging
- Every beat gets a gesture: point, hold an object, clap, wipe a tear, hand on chest, scratch head, cup ear, wave, rub eyes, stretch.
- Left and right arms must differ by at least 15 degrees. Shift weight: one leg a little forward, hip tilted, head tilted 4-8 degrees.
- Secondary motion: when an arm stops, the hand overshoots then settles. Props sway.
- Idle breathing and head bob for every character, with a different phase for each so they never move in sync.
- Characters look at each other or at the object, not always at the camera. Use a 3/4 turn: squeeze the head width by 8% and shift the nose and eyes 6 px toward the look direction.

## 7. Staging for groups (fix the line-up)
- Never put 3 people in a straight row. Use two depth rows: front row scale 1.0, back row scale 0.85, back row 20-30 px higher and drawn first; overlap bodies by 15-30%.
- ONE ground line per row. Feet of the same row have the same y. Draw a soft shadow ellipse under every pair of feet.
- Different heights (see height_scale). Characters turn toward the speaker.
- A caption must never cover hands, feet or a face. If it does, move the camera or the characters up.

## 8. Backgrounds - minimum 6 props, 4 layers
Layers: wall/sky -> far props (blurred) -> mid props -> character -> foreground. Examples:
- Shop counter at night: hanging lamp with glow, shelves with jars and boxes, ledger book, weighing scale, tea glass, wall calendar, window with night sky, wooden floor lines, coins.
- Classroom: chalkboard with text, desks, map, school bag, window light with dust, clock.
- Sleeping scene: bed or mat, pillow, moon through window, clock showing late hour, blanket, lamp off.
Never flat colours. Use gradient + painted blotches + paper texture. Add light direction and shadows.

## 9. Captions and text
- Show ONE caption system at a time. Never show a taped note and a chip with the same words.
- Chip width at most 75% of the screen width. Longer text wraps into 2 lines. Margin 28 px.
- Story text cards (chalkboard, signs) are part of the scene art, separate from the caption chip.

## 10. Output format
- Export EXACTLY 1080 x 1920 (or 720 x 1280 for drafts), full frame, no black bars, square pixels. Run ffprobe and show width, height, fps, duration.

## 11. Verification you MUST do before showing me anything
1. Render `lineup.png`: every cast member side by side on a plain background at the same scale. If any two characters look alike, fix them.
2. Render `silhouettes.png`: fill every character solid black. Each one must be recognisable. If not, change hair, build or outfit.
3. Render one frame from EVERY scene and make a contact sheet. Check: feet on a ground line, no prop on a face, no caption over hands, each scene has 6 or more props, emotions match the lines.
4. Check ffprobe size and no black bars.
5. Report to me as a table: character - how it differs from the others (5 differences) - emotion used per scene. Then list honestly what is still weak.

## 12. Forbidden
- One head/hair/face template for all characters.
- Sleepy eyes on every face.
- Characters standing in a row with arms hanging.
- Empty or flat backgrounds.
- Duplicate text on screen.
- Saying "done" without doing section 11.
