All WAVs are synthesised by scripts/make_sfx.py (numpy noise and sine sweeps, 48 kHz mono). No samples, free to use.
whoosh=board slap, pop=caption chip, ding=idea bulb, thud=price tag/impact, burst=powder burst, sparkle=sparkles/stamp-in, rain=rain bed (loop), flash=headlight flash.
