#!/usr/bin/env python3
"""Word timestamps with faster-whisper -> ../examples/<name>/work/words.json   (NOT run in the build sandbox: needs pip install faster-whisper + model download)
python3 transcribe.py narration.wav words.json [--lang hi]"""
import json,sys
from faster_whisper import WhisperModel
lang=sys.argv[sys.argv.index('--lang')+1] if '--lang' in sys.argv else None
segs,_=WhisperModel('small',compute_type='int8').transcribe(sys.argv[1],word_timestamps=True,language=lang)
w=[{'w':x.word.strip(),'s':round(x.start,2),'e':round(x.end,2)} for s in segs for x in s.words]
json.dump(w,open(sys.argv[2],'w'),ensure_ascii=False,indent=1);print(len(w),'words')
