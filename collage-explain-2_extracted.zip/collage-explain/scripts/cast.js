/* cast.js - parametric cast system for collage-explain. Load AFTER runtime.js.
   makePerson(spec, x, floorY, s, o) draws ONE person from a cast-sheet entry.
   Nobody is drawn with man()/head() any more: every face, hair, body and outfit comes from the spec.
   (x, floorY) = feet position, so a whole row shares one ground line whatever the heights are.
   o: {emotion, gesture, u, talk, face(+1/-1), look(-1..1), lean(-1..1), nolegs (floorY = belt line), aL,bL,aR,bR, hL,hR, noshadow}
*/
const CASTREG={};
const AGE_H={child:.62,young:.98,adult:1,old:.94};
const BUILDW={thin:50,medium:60,heavy:73};
const OUTFIT_DEF={kurta:['#4D6DA8','#EFE9DA','#6b4a2a'],shirt_tie:['#EAE4D6','#7a2a2a','#4a4f5c'],lab_coat:['#F4F7F8','#8DB6D8','#3b4350'],saree:['#B5382E','#C9962B','#E0A020'],school_uniform:['#F4F1EA','#B03030','#26357a'],sweater:['#8A4B6B','#E8D9B0','#3b4350'],apron:['#C9B79A','#2E7D6B','#4a4f5c'],dhoti:['#6A8F6B','#F2EEE2','#8a5a30'],frock:['#FBFBF6','#3A78C8','#FBFBF6']};
const hashS=s=>{let h=7;for(const c of String(s))h=(h*31+c.charCodeAt(0))%100003;return h};
function shade(hex,k){if(!hex||hex[0]!=='#')return hex;const n=parseInt(hex.slice(1),16);let r=n>>16,g=n>>8&255,b=n&255;const f=k<0?0:255,p=Math.abs(k);return`rgb(${Math.round(r+(f-r)*p)},${Math.round(g+(f-g)*p)},${Math.round(b+(f-b)*p)})`}
function specFill(sp){const d={age:'adult',build:'medium',height_scale:null,head_shape:'round',head_width:1,skin_hex:'#B5784B',hair_style:'side_part_short',hair_hex:'#1f1816',facial_hair:'none',glasses:false,brow:'thin',eye_shape:'almond',nose:'medium',ear:'small',outfit:'shirt_tie',outfit_colours:null,accessory:'none',signature_pose:'idle',default_emotion:'calm'};
 const o=Object.assign({},d,sp);if(o.height_scale==null)o.height_scale=AGE_H[o.age]||1;o.phase=(hashS(o.id||'x')%97)/97*6.28;
 const df=OUTFIT_DEF[o.outfit]||OUTFIT_DEF.shirt_tie;o.c=[0,1,2].map(i=>(o.outfit_colours&&o.outfit_colours[i])||df[i]);return o}
function registerCast(list){list.forEach(s=>{CASTREG[s.id]=specFill(s)});return CASTREG}

/* ---------- emotions: eyes / brows / mouth. lid = half-closed amount (ONLY calm/tired/bored use it) ---------- */
const EM={
 calm:{lid:.4,bo:0,bi:0,m:'flat'},tired:{lid:.55,bo:2,bi:0,m:'flat'},bored:{lid:.5,bo:1,bi:0,m:'flat',look:1},
 neutral:{lid:0,bo:0,bi:0,m:'flat'},
 happy:{bo:-3,bi:0,m:'smile'},proud:{lid:.15,bo:-4,bi:0,m:'smile'},laugh:{shut:1,happy:1,bo:-4,bi:0,m:'grin'},
 surprised:{wide:1,bo:-10,bi:0,m:'o'},shocked:{wide:1,bo:-12,bi:0,m:'o',pup:.6},
 sad:{lid:.2,bo:3,bi:7,m:'sad',ly:3},crying:{lid:.2,bo:3,bi:8,m:'sad',ly:3,tear:1},
 worried:{bo:-2,bi:6,asym:2,m:'wobble',look:1},angry:{narrow:1,bo:2,bi:-7,m:'tight'},
 shouting:{bo:-5,bi:0,m:'shout'},singing:{bo:-3,bi:0,m:'shout'},
 thinking:{bo:-2,bi:0,asym:1,m:'purse',lookUp:1},determined:{narrow:.6,bo:1,bi:-3,m:'tight'},
 love:{bo:-2,bi:2,m:'smile',happy:0}
};
EM.excited=EM.happy;EM.scared=EM.worried;EM.nervous=EM.worried;EM.listening=EM.neutral;EM.curious=EM.thinking;EM.sleepy=EM.tired;EM.relieved=EM.happy;EM.joy=EM.laugh;EM.fear=EM.worried;EM.shock=EM.shocked;EM.sing=EM.singing;EM.shout=EM.shouting;

/* ---------- 2-bone IK for arms so gestures can target a point (body coords, belt line = 0,0) ---------- */
function ik(side,tx,ty,sx,sy,l1,l2,outward){let dx=tx-sx,dy=ty-sy,d0=Math.hypot(dx,dy)||1,d=Math.min(l1+l2-.5,Math.max(Math.abs(l1-l2)+.5,d0));
 const phi=Math.atan2(dy,dx),al=Math.acos(clamp((l1*l1+d*d-l2*l2)/(2*l1*d),-1,1));let best=null;
 [1,-1].forEach(sg=>{const a=phi+sg*al,ex=sx+Math.cos(a)*l1,ey=sy+Math.sin(a)*l1,sc=outward?side*(ex-sx)+ey*.2:ey;if(!best||sc>best.sc)best={a,ex,ey,sc}});
 const hx=sx+dx/d0*d,hy=sy+dy/d0*d,a1=Math.atan2(side*Math.cos(best.a),Math.sin(best.a)),a2=Math.atan2(side*(hx-best.ex),hy-best.ey);
 let b=(a2-a1)*180/Math.PI;while(b>180)b-=360;while(b<-180)b+=360;return{a:a1*180/Math.PI,b}}

/* gesture -> per-arm {x,y} hand target (body coords) or {a,b} angles. P={bw,hc,sy}; u = seconds in scene */
function gestureArms(name,u,P,ph){const w=Math.sin(u*9+ph),sw=Math.sin(u*2+ph),bw=P.bw,hc=P.hc,idle=(side)=>({a:side<0?9+sw*2:27+sw*2,b:side<0?-4:-20});
 const T=(x,y)=>({x,y});const L=-1,Rr=1;
 switch(name){
 case'point':return{L:idle(L),R:T(bw+120,P.sy+4+w*2)};
 case'point_left':return{L:T(-bw-120,P.sy+4+w*2),R:idle(Rr)};
 case'hand_on_chest':return{L:idle(L),R:T(-14,P.sy+26+sw*2)};
 case'hands_on_hips':return{L:T(-bw-1,-6),R:T(bw+1,-6)};
 case'wipe_tear':return{L:idle(L),R:T(-14+w*6,hc+12)};
 case'rub_eyes':return{L:T(14+w*5,hc+8),R:T(-14-w*5,hc+8)};
 case'scratch_head':return{L:idle(L),R:T(bw*.4+w*5,hc-48)};
 case'cup_ear':return{L:idle(L),R:T(bw*.95,hc+8+sw*2)};
 case'wave':return{L:idle(L),R:T(bw+48+w*14,hc-14)};
 case'clap':{const o=Math.abs(Math.sin(u*8+ph))*22;return{L:T(-4-o,P.sy+14),R:T(4+o,P.sy+14)}}
 case'cheer':return{L:T(-bw-44,hc-60+w*5),R:T(bw+44,hc-60-w*5)};
 case'think':return{L:T(-bw*.35,-70),R:T(bw*.25,hc+44)};
 case'shrug':return{L:T(-bw-40,P.sy+36+sw*3),R:T(bw+40,P.sy+36+sw*3)};
 case'hold':return{L:T(-bw-28,P.sy+52),R:T(bw+28,P.sy+52)};
 case'hold_up':return{L:idle(L),R:T(bw+34,P.sy-30+sw*3)};
 case'stretch':return{L:T(-bw-26,hc-100+sw*4),R:T(bw+26,hc-100-sw*4)};
 case'count':return{L:T(-bw*.3,P.sy+40),R:T(bw*.6+w*3,P.sy+6)};
 case'cry_hands':return{L:T(10,hc+22),R:T(-10,hc+22)};
 case'hug':return{L:T(bw*.8,P.sy+40),R:T(-bw*.8,P.sy+52)};
 case'idle_a':return{L:{a:12+sw*2,b:-6},R:{a:34+sw*2,b:-24}};
 default:return{L:idle(L),R:idle(Rr)}}}

/* ---------- head ---------- */
function headPath(shape,hw,r){const w=r*.94*hw;
 return()=>{ctx.beginPath();
  if(shape==='oval'){ctx.ellipse(0,4,w*.86,r*1.14,0,0,7)}
  else if(shape==='square_jaw'){ctx.moveTo(-w,-r*.1);ctx.bezierCurveTo(-w*1.02,-r*1.08,w*1.02,-r*1.08,w,-r*.1);ctx.lineTo(w*.93,r*.72);ctx.lineTo(w*.58,r*1.02);ctx.lineTo(-w*.58,r*1.02);ctx.lineTo(-w*.93,r*.72);ctx.closePath()}
  else if(shape==='pointed'){ctx.moveTo(-w,-r*.1);ctx.bezierCurveTo(-w*1.02,-r*1.1,w*1.02,-r*1.1,w,-r*.1);ctx.bezierCurveTo(w*.96,r*.6,w*.3,r*.95,0,r*1.22);ctx.bezierCurveTo(-w*.3,r*.95,-w*.96,r*.6,-w,-r*.1);ctx.closePath()}
  else{ctx.ellipse(0,2,w,r*1.04,0,0,7)}}}
function eyeDraw(ex,ey,sx,sp,E,look,ly,blink,hid){const shut=E.shut||blink;ctx.lineCap='round';
 if(shut){ctx.strokeStyle='#241c18';ctx.lineWidth=2.6;ctx.beginPath();ctx.arc(ex,ey+(E.happy?3:0),6.5,E.happy?3.4:.15,E.happy?6:3);ctx.stroke();return}
 const sh=sp.eye_shape;let rx=sh==='round'?7:7.6,ry=sh==='round'?7:sh==='narrow'?3.4:5.2;if(E.wide){rx=8.6;ry=9.4}if(E.narrow)ry*=.55*(E.narrow===1?1:1.3);
 const path=()=>{ctx.beginPath();if(sh==='round'||E.wide)ctx.ellipse(ex,ey,rx,ry,0,0,7);else{ctx.moveTo(ex-rx,ey+(sx<0?-1.2:0)+(sx>0?0:0));ctx.quadraticCurveTo(ex,ey-ry*1.7,ex+rx,ey+(sx>0?-1.2:0));ctx.quadraticCurveTo(ex,ey+ry*1.6,ex-rx,ey)}};
 ctx.save();path();ctx.fillStyle='#F4EEE2';ctx.fill();ctx.clip();
 const pr=E.wide?(E.pup?2.3:2.8):3.3;ctx.fillStyle=sp.eye_hex||'#2a1a12';ctx.beginPath();ctx.arc(ex+look,ey+ly+.4,pr,0,7);ctx.fill();circ(ex+look-1,ey+ly-.8,1,'#fff');
 if(E.lid){ctx.fillStyle=shade(sp.skin_hex,-.1);ctx.fillRect(ex-rx-2,ey-ry*2,rx*2+4,ry*2*E.lid*1.9)}
 ctx.restore();path();ctx.strokeStyle='#241c18';ctx.lineWidth=E.wide?1.8:2;ctx.stroke();
 if(E.lid){ctx.beginPath();ctx.moveTo(ex-rx,ey-ry*.8+ry*2*E.lid*1.9);ctx.lineTo(ex+rx,ey-ry*.8+ry*2*E.lid*1.9);ctx.stroke()}}
function browDraw(sp,E,ey){const wd=sp.brow==='bushy'?6.5:sp.brow==='thick'?4.6:2.6,col=(sp.age==='old'&&sp.brow!=='thin')?'#d4d4d4':(sp.brow_hex||sp.hair_hex);ctx.strokeStyle=col;ctx.lineWidth=wd;ctx.lineCap='round';
 [-1,1].forEach(sx=>{let bo=E.bo||0,bi=E.bi||0;if(E.asym===1&&sx>0)bo-=6;if(E.asym===2&&sx>0)bi+=2;const oy=ey-13+bo+bi*.45,iy=ey-15+bo-bi;
  ctx.beginPath();ctx.moveTo(sx*27,oy);ctx.quadraticCurveTo(sx*17,(oy+iy)/2-4,sx*7,iy);ctx.stroke();
  if(sp.brow==='bushy'){ctx.lineWidth=1.6;for(let i=0;i<7;i++){const k=i/6,bx=sx*(27-k*20),by=oy+(iy-oy)*k-4-(i%2)*2;ctx.beginPath();ctx.moveTo(bx,by+3);ctx.lineTo(bx+sx*-2,by-2);ctx.stroke()}ctx.lineWidth=wd}})}
function mouthDraw(m,o,E,TP,sp){ctx.lineCap='round';ctx.strokeStyle='#2a1612';ctx.lineWidth=2.6;
 if(o.talk&&m!=='shout'&&m!=='o'&&m!=='sad'){const k=Math.abs(Math.sin(TP*11)),h=2+k*7;ctx.fillStyle='#4a1510';ctx.beginPath();ctx.ellipse(0,36,7+k*1.5,h,0,0,7);ctx.fill();ctx.stroke();return}
 ctx.beginPath();
 if(m==='smile'){ctx.arc(0,31,9,.25,2.9);ctx.stroke()}
 else if(m==='grin'){ctx.fillStyle='#4a1510';ctx.beginPath();ctx.arc(0,31,12,.1,3.04);ctx.closePath();ctx.fill();ctx.fillStyle='#fff';ctx.fillRect(-9,32,18,4)}
 else if(m==='o'){ctx.fillStyle='#4a1510';ctx.beginPath();ctx.ellipse(0,39,6.5,8.5,0,0,7);ctx.fill();ctx.stroke()}
 else if(m==='shout'){const k=.75+.25*Math.sin(TP*14);ctx.fillStyle='#4a1510';ctx.beginPath();ctx.ellipse(0,38,11,11*k,0,0,7);ctx.fill();ctx.stroke();ctx.fillStyle='#fff';ctx.fillRect(-8,30,16,4);ctx.fillStyle='#c4564a';ctx.beginPath();ctx.ellipse(0,38+5*k,6,3.5*k,0,0,7);ctx.fill()}
 else if(m==='sad'){ctx.arc(0,47,8,3.4,6);ctx.stroke()}
 else if(m==='wobble'){ctx.moveTo(-8,40);for(let i=1;i<=8;i++)ctx.lineTo(-8+i*2,40+Math.sin(i*1.6+TP*9)*1.8);ctx.stroke()}
 else if(m==='tight'){ctx.moveTo(-8,38);ctx.lineTo(8,38);ctx.moveTo(-8,38);ctx.lineTo(-9,41);ctx.moveTo(8,38);ctx.lineTo(9,41);ctx.stroke()}
 else if(m==='purse'){ctx.ellipse(7,38,4,2.6,0,0,7);ctx.stroke()}
 else{ctx.moveTo(-7,37);ctx.lineTo(7,37);ctx.stroke()}}
function hairBack(sp,r,hw){const st=sp.hair_style,hc=sp.hair_hex,w=r*hw;
 if(st==='curly'){const R2=R(hashS(sp.id));for(let i=0;i<13;i++){const a=Math.PI+.05+i*(Math.PI-.1)/12;circ(Math.cos(a)*w*1.02,-6+Math.sin(a)*r*.98,11+R2()*4,hc)}}
 if(st==='long_braid'||st==='two_braids'){[st==='two_braids'?-1:1,1].forEach((sd,k)=>{if(st==='long_braid'&&k)return;for(let i=0;i<7;i++){const sw=Math.sin(TNOW*1.5+i*.4+sp.phase)*1.6*(i/6);ell(sd*w*.86+sw+(i*.5)*sd,r*.35+i*16.5,9.5-i*.4,11,hc,{lw:1.4,ns:i>0})}
   const ey=r*.35+7*16.5;poly([[sd*w*.86-9,ey],[sd*w*.86+9,ey],[sd*w*.86+3,ey+8],[sd*w*.86+11,ey+18],[sd*w*.86-11,ey+18],[sd*w*.86-3,ey+8]],'#C0392B',{lw:1.2,ns:1})})}
 if(st==='bald_with_side_hair'){[-1,1].forEach(sd=>{ell(sd*w*.93,-2,9,22,hc,{lw:1.4,ns:1})})}}
function hairFront(sp,r,hw){const st=sp.hair_style,hc=sp.hair_hex,w=r*hw,hl='rgba(255,255,255,.16)';ctx.save();ctx.fillStyle=hc;
 const cap=(top,hy)=>{ctx.beginPath();ctx.ellipse(0,-12,w*.99,r*top,0,Math.PI+.06,-.06);ctx.lineTo(w*.74,-r*hy);ctx.quadraticCurveTo(0,-r*(hy+.2),-w*.74,-r*hy);ctx.closePath();ctx.fill()};
 if(st==='side_part_short'){ctx.beginPath();ctx.ellipse(0,-12,w*.99,r*.9,0,Math.PI+.06,-.06);ctx.lineTo(w*.2,-r*.5);ctx.quadraticCurveTo(-w*.1,-r*.68,-w*.3,-r*.5);ctx.closePath();ctx.fill();
  ctx.strokeStyle='rgba(200,150,95,.8)';ctx.lineWidth=1.6;ctx.beginPath();ctx.moveTo(-w*.3,-r*.5);ctx.quadraticCurveTo(-w*.24,-r*.78,-w*.32,-r*.96);ctx.stroke();ctx.strokeStyle=hl;ctx.lineWidth=1.2;for(let i=0;i<4;i++){ctx.beginPath();ctx.moveTo(8+i*9,-r*.9);ctx.quadraticCurveTo(14+i*9,-r*.72,10+i*9,-r*.54);ctx.stroke()}}
 else if(st==='crew_cut'){ctx.beginPath();ctx.moveTo(-w*.97,-r*.05);ctx.lineTo(-w*.95,-r*.78);ctx.quadraticCurveTo(-w*.9,-r*1.06,-w*.6,-r*1.06);ctx.lineTo(w*.6,-r*1.06);ctx.quadraticCurveTo(w*.9,-r*1.06,w*.95,-r*.78);ctx.lineTo(w*.97,-r*.05);ctx.lineTo(w*.8,-r*.42);ctx.lineTo(-w*.8,-r*.42);ctx.closePath();ctx.fill();
  ctx.fillStyle='rgba(255,255,255,.22)';const R2=R(7);for(let i=0;i<34;i++)ctx.fillRect(-w*.8+R2()*w*1.6,-r*1.0+R2()*r*.55,1.6,1.6)}
 else if(st==='grey_thin'){ctx.beginPath();ctx.moveTo(-w*.97,-r*.02);ctx.quadraticCurveTo(-w*1.05,-r*.55,-w*.78,-r*.7);ctx.lineTo(-w*.84,-r*.1);ctx.closePath();ctx.fill();ctx.beginPath();ctx.moveTo(w*.97,-r*.02);ctx.quadraticCurveTo(w*1.05,-r*.55,w*.78,-r*.7);ctx.lineTo(w*.84,-r*.1);ctx.closePath();ctx.fill();
  ctx.strokeStyle=hc;ctx.lineWidth=1.5;for(let i=0;i<11;i++){const x0=-w*.5+i*w*.1;ctx.beginPath();ctx.moveTo(x0,-r*.92);ctx.quadraticCurveTo(x0+8,-r*.98,x0+20,-r*.84);ctx.stroke()}
  ctx.fillStyle='rgba(255,255,255,.14)';ctx.beginPath();ctx.ellipse(-w*.2,-r*.7,w*.28,r*.12,-.3,0,7);ctx.fill()}
 else if(st==='bald_with_side_hair'){ctx.fillStyle='rgba(255,255,255,.22)';ctx.beginPath();ctx.ellipse(-w*.25,-r*.72,w*.3,r*.12,-.4,0,7);ctx.fill();ctx.strokeStyle=hc;ctx.lineWidth=1.4;[[-.5,-.9],[.1,-.96]].forEach(p=>{ctx.beginPath();ctx.moveTo(w*p[0],r*p[1]);ctx.quadraticCurveTo(w*p[0]+6,r*p[1]-5,w*p[0]+12,r*p[1]+1);ctx.stroke()})}
 else if(st==='bun'){cap(.9,.42);ctx.strokeStyle='rgba(255,255,255,.2)';ctx.lineWidth=1.4;ctx.beginPath();ctx.moveTo(0,-r*.95);ctx.lineTo(0,-r*.55);ctx.stroke();ctx.fillStyle=hc;ctx.beginPath();ctx.arc(0,-r*1.08,r*.3,0,7);ctx.fill();ctx.strokeStyle='rgba(255,255,255,.2)';ctx.beginPath();ctx.arc(0,-r*1.08,r*.19,.4,4);ctx.stroke()}
 else if(st==='long_braid'||st==='two_braids'){cap(.9,.4);ctx.strokeStyle='rgba(255,255,255,.2)';ctx.lineWidth=1.4;ctx.beginPath();ctx.moveTo(0,-r*.95);ctx.lineTo(0,-r*.5);ctx.stroke()}
 else if(st==='topi_cap'){ctx.beginPath();ctx.ellipse(-w*.9,-4,6,16,0,0,7);ctx.ellipse(w*.9,-4,6,16,0,0,7);ctx.fill();const cc=sp.cap_hex||'#F4F1EA';ctx.beginPath();ctx.moveTo(-w*.99,-r*.34);ctx.lineTo(-w*.96,-r*.8);ctx.quadraticCurveTo(0,-r*1.5,w*.96,-r*.8);ctx.lineTo(w*.99,-r*.34);ctx.quadraticCurveTo(0,-r*.2,-w*.99,-r*.34);ctx.closePath();paper(()=>{ctx.moveTo(-w*.99,-r*.34);ctx.lineTo(-w*.96,-r*.8);ctx.quadraticCurveTo(0,-r*1.5,w*.96,-r*.8);ctx.lineTo(w*.99,-r*.34);ctx.quadraticCurveTo(0,-r*.2,-w*.99,-r*.34)},cc,{lw:1.8});
  ctx.strokeStyle='rgba(120,100,80,.35)';ctx.lineWidth=1.2;for(let i=-2;i<=2;i++){ctx.beginPath();ctx.moveTo(i*w*.3,-r*.34);ctx.quadraticCurveTo(i*w*.34,-r*.8,i*w*.18,-r*1.06);ctx.stroke()}}
 else if(st==='curly'){const R2=R(hashS(sp.id)+3);for(let i=0;i<11;i++){const a=Math.PI+.15+i*(Math.PI-.3)/10;circ(Math.cos(a)*w*.9,-12+Math.sin(a)*r*.82,10+R2()*3,hc)}for(let i=0;i<4;i++)circ(-w*.45+i*w*.3,-r*.68+R2()*4,7.5+R2()*2,hc);ctx.strokeStyle=hl;ctx.lineWidth=1.2;ctx.beginPath();ctx.arc(-w*.2,-r*.9,10,3.3,5);ctx.stroke()}
 else{cap(.88,.45)}
 ctx.restore()}
function facialHair(sp,hw){const f=sp.facial_hair,hc=sp.facial_hex||(f==='grey_mustache'?'#CFCFCF':f==='white_mustache'?'#F2F2F2':sp.hair_hex);ctx.save();
 if(f==='beard'){ctx.fillStyle=hc;ctx.beginPath();ctx.moveTo(-48*hw,6);ctx.quadraticCurveTo(-52*hw,50,-18,62);ctx.quadraticCurveTo(0,70,18,62);ctx.quadraticCurveTo(52*hw,50,48*hw,6);ctx.lineTo(34*hw,20);ctx.quadraticCurveTo(0,6,-34*hw,20);ctx.closePath();ctx.fill();ctx.fillStyle=shade(sp.skin_hex,-.02);ctx.beginPath();ctx.ellipse(0,36,15,11,0,0,7);ctx.fill()}
 if(f==='mustache'||f==='beard'){ctx.fillStyle=hc;ctx.beginPath();ctx.moveTo(-26,26);ctx.quadraticCurveTo(-13,14,0,21);ctx.quadraticCurveTo(13,14,26,26);ctx.quadraticCurveTo(13,32,0,27);ctx.quadraticCurveTo(-13,32,-26,26);ctx.fill()}
 else if(f==='grey_mustache'||f==='white_mustache'){ctx.fillStyle=hc;ctx.strokeStyle='#8a8a8a';ctx.lineWidth=1.4;ctx.beginPath();ctx.moveTo(-32,31);ctx.quadraticCurveTo(-22,14,0,20);ctx.quadraticCurveTo(22,14,32,31);ctx.quadraticCurveTo(24,38,12,29);ctx.quadraticCurveTo(0,33,-12,29);ctx.quadraticCurveTo(-24,38,-32,31);ctx.fill();ctx.stroke()}
 else if(f==='thin_mustache'){ctx.strokeStyle=hc;ctx.lineWidth=2.2;ctx.beginPath();ctx.moveTo(-17,26);ctx.quadraticCurveTo(-8,21,0,24);ctx.quadraticCurveTo(8,21,17,26);ctx.stroke()}
 ctx.restore()}
function pHead(sp,E,o,r,TP){const hw=sp.head_width,turn=o.look||0,skin=sp.skin_hex,tx=turn*6;ctx.save();ctx.translate(0,(o.bob||0)+Math.sin(TP*2.3)*1.2);ctx.rotate((o.tilt||0)+Math.sin(TP*1.3)*.012+(sp.age==='old'?.03:0));ctx.scale(1-.08*Math.abs(turn),1);
 hairBack(sp,r,hw);const earW=sp.ear==='big'?10:6.5,earH=sp.ear==='big'?16:11;[-1,1].forEach(sd=>ell(sd*r*.93*hw,6,earW,earH,shade(skin,-.08)));
 paper(headPath(sp.head_shape,hw,r),rg(-8,-10,6,r+8,[[0,shade(skin,.08)],[1,shade(skin,-.08)]]),{lw:2.6});
 if(sp.facial_hair==='beard')facialHair(sp,hw);
 ctx.save();ctx.translate(tx,0);
 circ(-18,14,9,'rgba(205,110,85,.2)');circ(18,14,9,'rgba(205,110,85,.2)');
 const nz=sp.nose,nc=shade(skin,-.22);if(nz==='big'){ctx.strokeStyle=nc;ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(-3,-6);ctx.quadraticCurveTo(-6,8,-9,13);ctx.stroke();ell(0,13,9,6.5,shade(skin,-.14),{ns:1,ne:1,nt:1});ell(-4,14,2,1.5,'rgba(60,30,20,.5)',{ns:1,ne:1,nt:1});ell(4,14,2,1.5,'rgba(60,30,20,.5)',{ns:1,ne:1,nt:1})}
 else if(nz==='small'){ell(0,10,3.6,2.8,shade(skin,-.14),{ns:1,ne:1,nt:1})}else{ell(0,10,5.5,4.4,shade(skin,-.15),{ns:1,ne:1,nt:1});ctx.strokeStyle=nc;ctx.lineWidth=1.4;ctx.beginPath();ctx.moveTo(1,-4);ctx.lineTo(3,5);ctx.stroke()}
 const ey=-2,blink=((TP*1)%(2.3+(sp.phase%1.3)))<.13,lx=(o.look||0)*3+(E.look?(o.face||1)*2.6:0),ly=E.lookUp?-3.2:(E.ly||0);
 [-1,1].forEach(sx=>eyeDraw(sx*15,ey,sx,sp,E,lx,ly,blink));
 browDraw(sp,E,ey);
 if(sp.glasses){ctx.strokeStyle='#2b2b2b';ctx.lineWidth=2.2;[-1,1].forEach(sx=>{ctx.beginPath();if(sp.glasses==='rect')ctx.roundRect(sx*16-11,-12,22,16,3);else ctx.arc(sx*16,-2,11,0,7);ctx.fillStyle='rgba(200,230,255,.16)';ctx.fill();ctx.stroke()});ctx.beginPath();ctx.moveTo(-5,-4);ctx.quadraticCurveTo(0,-8,5,-4);ctx.stroke();ctx.beginPath();ctx.moveTo(-27,-4);ctx.lineTo(-r*.93*hw,0);ctx.moveTo(27,-4);ctx.lineTo(r*.93*hw,0);ctx.stroke()}
 if(sp.age==='old'){ctx.strokeStyle='rgba(80,50,30,.38)';ctx.lineWidth=1.4;[-r*.66,-r*.57,-r*.48].forEach((y,i)=>{ctx.beginPath();ctx.moveTo(-22+i*2,y);ctx.quadraticCurveTo(0,y-4,22-i*2,y);ctx.stroke()});[-1,1].forEach(sx=>{[-3,2].forEach(dy=>{ctx.beginPath();ctx.moveTo(sx*29,ey+dy);ctx.lineTo(sx*36,ey+dy+(dy>0?4:-3));ctx.stroke()});ctx.beginPath();ctx.moveTo(sx*13,16);ctx.quadraticCurveTo(sx*19,28,sx*15,40);ctx.stroke()})}
 mouthDraw(E.m,o,E,TP,sp);if(sp.facial_hair!=='beard')facialHair(sp,hw);
 if(sp.accessory==='bindi')circ(0,-r*.48,3.3,'#C0182B');
 if(E.tear){const t=(TP*1.4)%1;circ(-17,16+t*24,4,'rgba(170,215,255,.9)');circ(17,16+((t+.5)%1)*24,3.4,'rgba(170,215,255,.9)')}
 ctx.restore();hairFront(sp,r,hw);ctx.restore()}
/* ---------- arms ---------- */
function parm(side,ang,bend,sx,sy,k){ctx.save();ctx.translate(sx,sy);ctx.rotate(-side*(ang+Math.sin(TNOW*1.7+k.ph+side)*1.6)*Math.PI/180);
 if(k.short)rrect(-k.tw/2+1,-12,k.tw-2,k.l1+10,10,k.skin);rrect(-k.tw/2,-14,k.tw,(k.short?k.l1*.55:k.l1)+14,11,k.sleeve);
 ctx.translate(0,k.l1);ctx.rotate(-side*(bend||0)*Math.PI/180);rrect(-k.fw/2,-6,k.fw,k.l2+6,8,k.skinD);
 if(k.watch&&side<0)rrect(-k.fw/2-1,k.l2-14,k.fw+2,6,2,'#3b3b3b',{ns:1,lw:1});
 ell(0,k.l2+8,k.fw*.56,k.fw*.62,k.hand);if(k.hold){ctx.save();ctx.translate(0,k.l2+8);k.hold();ctx.restore()}brad(0,0);ctx.restore();brad(sx,sy)}
/* ---------- the person ---------- */
function personFloorOffset(sp){return((sp.age==='child')?58:108)+18}
function makePerson(sp,x,floor,s,o={}){if(typeof sp==='string')sp=CASTREG[sp];if(!sp)throw new Error('makePerson: unknown cast id');
 const kid=sp.age==='child',old=sp.age==='old',bw=BUILDW[sp.build]*(kid?.82:1),TH=kid?98:138,legL=kid?58:108,S=s*sp.height_scale,by=o.nolegs?floor:floor-(legL+18)*S,TP=TNOW+sp.phase,c=sp.c,sk=sp.skin_hex,face=o.face||1;
 const E=EM[o.emotion||sp.default_emotion]||EM.calm,sy=-(TH-20),hs=kid?1.28:.9,hc=-TH-54*hs+3,u=o.u||0,lean=o.lean||0;
 if(!o.nolegs&&!o.noshadow)ell(x,floor,58*S,8,'rgba(60,30,10,.3)',{ns:1,ne:1});
 ctx.save();ctx.translate(x,by);ctx.scale(S*face,S*(1+Math.sin(TP*2.1)*.006));
 const torso=(B,fill,ex=0)=>paper(()=>{const w=bw+ex;ctx.moveTo(-bw*.5,-TH);ctx.lineTo(bw*.5,-TH);ctx.quadraticCurveTo(bw+4,-TH+4,bw+5,-TH+40);ctx.lineTo(w+(sp.build==='heavy'?7:0),B);ctx.lineTo(-w-(sp.build==='heavy'?7:0),B);ctx.lineTo(-bw-5,-TH+40);ctx.quadraticCurveTo(-bw-4,-TH+4,-bw*.5,-TH)},fill);
 const lw=40*bw/60,lx=26*bw/60,shoe=(ox,oy)=>ell(ox,legL+8+oy,27*Math.sqrt(bw/60),10,'#3a2a22');
 const legs=(col,o2={})=>{[-1,1].forEach(sd=>{const dy=(sd===1?-lean:lean)*3;rrect(sd*lx-lw/2,-6,lw,legL+6+dy,9,col);if(!o2.noknee)brad(sd*lx,legL*.57);if(o2.sock)rrect(sd*lx-lw*.3,legL-26+dy,lw*.6,28,5,o2.sock,{ns:1});shoe(sd*lx*1.15,dy)})};
 if(sp.accessory==='bag')rrect(bw-24,-TH+6,40,64,8,'#C0574A',{lw:1.6});
 let sleeve=c[0],short=false,lgFill='#4a4f5c';
 if(!o.nolegs){const og=sp.outfit;
  if(og==='kurta')legs(c[1]);else if(og==='dhoti'){shoe(-lx,0);shoe(lx,0)}else if(og==='saree'||og==='frock'){if(og==='frock')legs('#A56B3E',{sock:'#F4F1EA',noknee:1});else{shoe(-lx*.8,0);shoe(lx*.8,0)}}
  else if(og==='school_uniform'){legs(c[2],{sock:'#F4F1EA'})}else legs(og==='lab_coat'||og==='sweater'||og==='apron'||og==='shirt_tie'?c[2]:'#4a4f5c')}
 ctx.save();ctx.rotate(lean*.03+(old?.07:0));
 const og=sp.outfit,tl=(y)=>y;
 if(og==='shirt_tie'){torso(2,lg(0,-TH,0,0,[[0,c[0]],[1,shade(c[0],-.07)]]));rrect(-bw,-16,bw*2,16,3,shade(c[2],-.35),{ne:1,so:2});rrect(-9,-17,18,18,3,'#c9a24a',{ne:1,ns:1});
  poly([[-bw*.45,-TH],[0,-TH+18],[-8,-TH-12],[-bw*.47,-TH-10]],'#F7F3EA',{lw:1.6,ns:1});poly([[bw*.45,-TH],[0,-TH+18],[8,-TH-12],[bw*.47,-TH-10]],'#F7F3EA',{lw:1.6,ns:1});
  poly([[-6,-TH+4],[6,-TH+4],[10,-TH+68],[0,-TH+80],[-10,-TH+68]],c[1],{ns:1});rrect(-6,-TH+1,12,10,3,shade(c[1],-.25),{ns:1,ne:1});
  rrect(bw*.25,-TH+34,bw*.5,36,4,'rgba(0,0,0,0)',{ns:1,lw:1.6,ec:'rgba(130,120,110,.75)'});if(sp.accessory==='pen_in_pocket')rrect(bw*.42,-TH+26,5,28,2,'#26357a',{ns:1,ne:1});circ(0,-34,3.2,'#c8c2b4');}
 else if(og==='kurta'){const B=kid?40:62;paper(()=>{ctx.moveTo(-bw*.5,-TH);ctx.lineTo(bw*.5,-TH);ctx.quadraticCurveTo(bw+4,-TH+4,bw+5,-TH+40);ctx.lineTo(bw+9,B);ctx.lineTo(bw*.1,B);ctx.lineTo(0,B-6);ctx.lineTo(-bw*.1,B);ctx.lineTo(-bw-9,B);ctx.lineTo(-bw-5,-TH+40);ctx.quadraticCurveTo(-bw-4,-TH+4,-bw*.5,-TH)},lg(0,-TH,0,B,[[0,c[0]],[1,shade(c[0],-.1)]]));
  ctx.strokeStyle='rgba(255,255,255,.55)';ctx.lineWidth=1.6;ctx.beginPath();ctx.moveTo(0,-TH+6);ctx.lineTo(0,B-8);ctx.stroke();rrect(-12,-TH-4,24,12,4,shade(c[0],-.12),{ns:1,lw:1.2});for(let i=0;i<4;i++)circ(0,-TH+26+i*22,3.2,'#EFE9DA');}
 else if(og==='lab_coat'){const B=kid?40:60;paper(()=>{ctx.moveTo(-bw*.5,-TH);ctx.lineTo(bw*.5,-TH);ctx.quadraticCurveTo(bw+4,-TH+4,bw+5,-TH+40);ctx.lineTo(bw+9,B);ctx.lineTo(-bw-9,B);ctx.lineTo(-bw-5,-TH+40);ctx.quadraticCurveTo(-bw-4,-TH+4,-bw*.5,-TH)},lg(0,-TH,0,B,[[0,c[0]],[1,shade(c[0],-.08)]]));
  poly([[-bw*.28,-TH],[bw*.28,-TH],[bw*.1,-TH+52],[0,-TH+66],[-bw*.1,-TH+52]],c[1],{ns:1,ne:1});poly([[-bw*.38,-TH-6],[-6,-TH+54],[-bw*.2,-TH+4],[-bw*.5,-TH-2]],shade(c[0],-.04),{lw:1.4,ns:1});poly([[bw*.38,-TH-6],[6,-TH+54],[bw*.2,-TH+4],[bw*.5,-TH-2]],shade(c[0],-.04),{lw:1.4,ns:1});
  rrect(bw*.25,-30,bw*.5,34,3,'rgba(0,0,0,0)',{ns:1,lw:1.5,ec:'rgba(110,120,130,.7)'});rrect(-bw*.72,-30,bw*.5,34,3,'rgba(0,0,0,0)',{ns:1,lw:1.5,ec:'rgba(110,120,130,.7)'});circ(0,-40,3,'#aeb7bd');circ(0,-16,3,'#aeb7bd');}
 else if(og==='saree'){const B=legL+10;paper(()=>{ctx.moveTo(-bw*.9,-30);ctx.lineTo(bw*.9,-30);ctx.lineTo(bw+16,B);ctx.lineTo(-bw-16,B)},lg(0,-30,0,B,[[0,c[0]],[1,shade(c[0],-.12)]]));
  ctx.strokeStyle='rgba(0,0,0,.18)';ctx.lineWidth=1.3;for(let i=-3;i<=3;i++){ctx.beginPath();ctx.moveTo(i*bw*.2,-26);ctx.lineTo(i*bw*.26,B-4)}ctx.stroke();rrect(-bw-16,B-14,2*bw+32,14,2,c[2],{ns:1,ne:1});
  torso(-26,lg(0,-TH,0,-26,[[0,c[1]],[1,shade(c[1],-.1)]]),-4);
  poly([[-bw-4,-TH+30],[-bw*.2,-TH+4],[bw*.1,-TH+8],[bw+8,-24],[bw+14,-4],[bw*.1,-10],[-bw*.5,-30]],c[0],{lw:1.6,ns:1});ctx.strokeStyle=c[2];ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(-bw*.2,-TH+4);ctx.lineTo(bw+8,-24);ctx.stroke();short=true;sleeve=c[1];}
 else if(og==='school_uniform'){torso(2,lg(0,-TH,0,0,[[0,c[0]],[1,shade(c[0],-.06)]]));poly([[-bw*.45,-TH],[0,-TH+16],[-8,-TH-10],[-bw*.47,-TH-8]],'#fff',{lw:1.6,ns:1});poly([[bw*.45,-TH],[0,-TH+16],[8,-TH-10],[bw*.47,-TH-8]],'#fff',{lw:1.6,ns:1});poly([[-5,-TH+4],[5,-TH+4],[8,-TH+54],[0,-TH+64],[-8,-TH+54]],c[1],{ns:1});rrect(-bw,-14,bw*2,14,3,c[2],{ne:1,so:2});short=true;sleeve=c[0];}
 else if(og==='sweater'){torso(4,lg(0,-TH,0,0,[[0,c[0]],[1,shade(c[0],-.1)]]));ctx.save();ctx.beginPath();ctx.rect(-bw-6,-TH,2*bw+12,TH+4);ctx.clip();ctx.strokeStyle=c[1];ctx.lineWidth=3;for(let k=0;k<3;k++){ctx.beginPath();const y0=-TH+46+k*28;ctx.moveTo(-bw-6,y0);for(let i=0;i<=14;i++)ctx.lineTo(-bw-6+i*(2*bw+12)/14,y0+(i%2?6:-6));ctx.stroke()}ctx.restore();rrect(-bw-4,-6,2*bw+8,12,4,shade(c[0],-.18),{ns:1,ne:1});rrect(-bw*.5,-TH-8,bw,14,7,shade(c[0],-.18),{ns:1,lw:1.4});}
 else if(og==='apron'){torso(2,lg(0,-TH,0,0,[[0,c[0]],[1,shade(c[0],-.06)]]));ctx.strokeStyle='rgba(120,90,60,.35)';ctx.lineWidth=1.6;for(let i=-4;i<=4;i++){ctx.beginPath();ctx.moveTo(i*bw*.22,-TH+6);ctx.lineTo(i*bw*.22,0);ctx.stroke()}poly([[-bw*.45,-TH],[0,-TH+14],[-8,-TH-10],[-bw*.47,-TH-8]],shade(c[0],.15),{lw:1.4,ns:1});poly([[bw*.45,-TH],[0,-TH+14],[8,-TH-10],[bw*.47,-TH-8]],shade(c[0],.15),{lw:1.4,ns:1});
  const AB=kid?40:78;paper(()=>{ctx.moveTo(-bw*.55,-TH+30);ctx.lineTo(bw*.55,-TH+30);ctx.lineTo(bw*.8,AB);ctx.lineTo(-bw*.8,AB)},c[1]);ctx.strokeStyle=c[1];ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(-bw*.5,-TH+30);ctx.lineTo(-bw*.3,-TH);ctx.moveTo(bw*.5,-TH+30);ctx.lineTo(bw*.3,-TH);ctx.stroke();rrect(-bw*.4,-20,bw*.8,26,3,shade(c[1],-.12),{ns:1,lw:1.4});}
 else if(og==='dhoti'){torso(-30,lg(0,-TH,0,-30,[[0,c[0]],[1,shade(c[0],-.08)]]));short=true;
  const B=legL+8;paper(()=>{ctx.moveTo(-bw-6,-34);ctx.lineTo(bw+6,-34);ctx.lineTo(bw+12,B);ctx.lineTo(8,B);ctx.lineTo(0,B-26);ctx.lineTo(-8,B);ctx.lineTo(-bw-12,B)},c[1]);ctx.strokeStyle='rgba(120,100,80,.4)';ctx.lineWidth=1.4;[-.55,-.25,.25,.55].forEach(k=>{ctx.beginPath();ctx.moveTo(k*bw,-30);ctx.lineTo(k*bw*1.1,B-4);ctx.stroke()});rrect(-bw-6,-40,2*bw+12,12,4,c[2],{ns:1,ne:1});}
 else if(og==='frock'){const B=kid?62:80;paper(()=>{ctx.moveTo(-bw*.5,-TH);ctx.lineTo(bw*.5,-TH);ctx.lineTo(bw*.62,-TH+44);ctx.lineTo(bw+26,B);ctx.lineTo(-bw-26,B);ctx.lineTo(-bw*.62,-TH+44)},lg(0,-TH,0,B,[[0,c[0]],[1,shade(c[0],-.04)]]));rrect(-bw*.65,-TH+40,bw*1.3,12,3,c[1],{ns:1,ne:1});rrect(-bw-28,B-12,2*bw+56,12,3,c[1],{ns:1,ne:1});poly([[-bw*.42,-TH],[0,-TH+16],[-6,-TH-8],[-bw*.45,-TH-6]],c[1],{lw:1.4,ns:1});poly([[bw*.42,-TH],[0,-TH+16],[6,-TH-8],[bw*.45,-TH-6]],c[1],{lw:1.4,ns:1});short=true;sleeve=c[0];}
 else torso(2,c[0]);
 if(og==='lab_coat'||og==='kurta'||og==='sweater'||og==='apron'||og==='school_uniform'||og==='shirt_tie'){}
 if(sp.accessory==='shawl'){const sc=sp.shawl_hex||c[2];paper(()=>{ctx.moveTo(-bw-12,-TH+14);ctx.quadraticCurveTo(0,-TH-14,bw+12,-TH+14);ctx.lineTo(bw+20,-14);ctx.lineTo(bw*.2,-34);ctx.lineTo(0,-TH+30);ctx.lineTo(-bw*.4,-18);ctx.lineTo(-bw-20,-8)},sc,{lw:1.6});ctx.strokeStyle='rgba(255,255,255,.35)';ctx.lineWidth=1.4;for(let i=0;i<5;i++){ctx.beginPath();ctx.moveTo(-bw-8+i*8,-TH+22+i*16);ctx.lineTo(-bw+10+i*8,-TH+38+i*16);ctx.stroke()}}
 if(sp.accessory==='bag'){ctx.strokeStyle='#8a3a30';ctx.lineWidth=7;ctx.beginPath();ctx.moveTo(-bw*.35,-TH+2);ctx.lineTo(bw*.65,-12);ctx.stroke()}
 rrect(-14*(bw/60)*.9,-TH-14,28*(bw/60)*.9,30,7,shade(sk,-.1),{ns:1});
 const dk=shade(sk,-.1),P={bw,hc,sy};let ar=null;const g=o.gesture||sp.signature_pose;if(g&&o.aL==null&&o.aR==null)ar=gestureArms(g,u,P,sp.phase);
 const AK=kid?.78:1,l1=46*AK,l2=50*AK,tw=(sp.build==='thin'?22:sp.build==='heavy'?32:26)*(kid?.85:1),fw=(sp.build==='thin'?15:sp.build==='heavy'?22:18)*(kid?.85:1);
 const K=(h)=>({sleeve,short,l1,l2,tw,fw,skin:dk,skinD:dk,hand:shade(sk,.06),hold:h,watch:sp.accessory==='watch',ph:sp.phase});
 const armOf=(side,x,key,h,aKey,bKey)=>{let a,b;if(o[aKey]!=null){a=o[aKey];b=o[bKey]||0}else if(ar){const t=ar[key];if(t.x!=null){const r2=ik(side,t.x,t.y,side*(bw+2),sy,l1,l2+8,true);a=r2.a;b=r2.b}else{a=t.a;b=t.b}}else{a=side<0?9:27;b=side<0?-4:-20}
  const wob=o.gesture==='point'||o.gesture==='point_left'?0:0;parm(side,a+wob,b,side*(bw+2),sy,K(h))};
 armOf(-1,0,'L',o.hL,'aL','bL');armOf(1,0,'R',o.hR,'aR','bR');
 ctx.save();ctx.translate(0,hc);ctx.scale(hs,hs);pHead(sp,E,Object.assign({},o,{face}),50,TP);ctx.restore();
 ctx.restore();ctx.restore()}
