#!/usr/bin/env python3
"""Turn a short role list into a full cast sheet where EVERY character differs from every other in >=5 attributes.
Input  roles.json : [{"id":"grandfather","role":"grandfather","age":"old","gender":"m"}, ...]   (any field of the cast spec may be added to pin it)
Output cast.json  : full cast-sheet entries (see agent_prompt_fix_characters.md section 3).
python3 scripts/auto_cast.py roles.json cast.json [--seed 1]
"""
import json,random,sys
DIFF=['build','height_scale','head_shape','hair_style','hair_hex','skin_hex','facial_hair','glasses','outfit','outfit_colours','accessory']
SKINS=['#E0B08A','#C58C5C','#B5784B','#A86F45','#9A6240','#8A5636','#D2A074']
DARK=['#1f1816','#17110f','#241a16','#3a2418']
GREY=['#E6E6E6','#9a9a9a','#cfcfcf']
OUT_M={'adult':['shirt_tie','kurta','apron','sweater','lab_coat','dhoti'],'young':['shirt_tie','sweater','lab_coat','kurta','school_uniform'],'old':['kurta','dhoti','sweater','shirt_tie'],'child':['school_uniform','sweater','kurta']}
OUT_F={'adult':['saree','sweater','lab_coat','kurta','apron'],'young':['sweater','lab_coat','kurta','saree'],'old':['saree','sweater','kurta'],'child':['frock','school_uniform','sweater']}
PAL=[['#B5382E','#E7B531','#E0A020'],['#2E7D6B','#E8D9B0','#C9962B'],['#4D6DA8','#EFE9DA','#6b4a2a'],['#8A4B6B','#E8D9B0','#3b4350'],['#C98A3A','#2457A6','#26357a'],['#6A8F6B','#F2EEE2','#8a5a30'],['#B9674F','#2E7D6B','#4a4f5c'],['#7A5A8A','#F3EDE0','#3b4350']]
def pick(r,g,age):
    f=g=='f'
    s={'id':None,'age':age,'skin_hex':r.choice(SKINS),'head_shape':r.choice(['round','oval','square_jaw','pointed']),'head_width':round(r.uniform(.9,1.08),2),
       'brow':r.choice(['thin','thick','bushy'] if age=='old' else ['thin','thick']),'eye_shape':r.choice(['almond','round','narrow']),'nose':r.choice(['small','medium','big']),'ear':r.choice(['small','big']),
       'outfit':r.choice((OUT_F if f else OUT_M)[age]),'accessory':'none','glasses':False}
    s['build']=r.choice(['thin','medium','heavy'] if age not in('child',) else ['thin','medium'])
    s['height_scale']={'child':round(r.uniform(.58,.68),2),'old':round(r.uniform(.9,.98),2)}.get(age,round(r.uniform(.94,1.12),2))
    if age=='old':
        s['hair_hex']=r.choice(GREY);s['hair_style']=r.choice(['grey_thin','bald_with_side_hair','bun'] if f else ['grey_thin','bald_with_side_hair','topi_cap','crew_cut']);s['glasses']=r.choice([False,'round','rect'])
    elif age=='child':
        s['hair_hex']=r.choice(DARK);s['hair_style']=r.choice(['two_braids','long_braid','curly'] if f else ['crew_cut','side_part_short','curly'])
    else:
        s['hair_hex']=r.choice(DARK+['#5a3a22','#7a4a22']);s['hair_style']=r.choice(['bun','long_braid','curly','two_braids'] if f else ['side_part_short','crew_cut','curly','topi_cap'])
        s['glasses']=r.choice([False,False,'round','rect'])
    s['facial_hair']='none' if f or age=='child' else r.choice(['none','mustache','thin_mustache','beard','grey_mustache' if age=='old' else 'mustache'])
    if age=='old' and s['facial_hair']!='none' and s['facial_hair']!='beard': s['facial_hair']='white_mustache'
    s['accessory']=r.choice(['bindi','shawl','watch','none'] if f else ['watch','pen_in_pocket','shawl','none'])
    if age=='child' and s['accessory'] in('pen_in_pocket','shawl'): s['accessory']='bag'
    if s['accessory']=='pen_in_pocket' and s['outfit']!='shirt_tie': s['accessory']='watch'
    s['outfit_colours']=r.choice(PAL)
    return s
def ndiff(a,b): return sum(1 for k in DIFF if a.get(k)!=b.get(k))
def main():
    roles=json.load(open(sys.argv[1]));out=sys.argv[2];seed=int(sys.argv[sys.argv.index('--seed')+1]) if '--seed' in sys.argv else 1
    r=random.Random(seed);cast=[]
    for ro in roles:
        best=None
        for _ in range(400):
            c=pick(r,ro.get('gender','m'),ro.get('age','adult'));c.update({k:v for k,v in ro.items() if k not in('gender',)})
            md=min([ndiff(c,o) for o in cast] or [99])
            if best is None or md>best[0]: best=(md,c)
            if md>=5: break
        c=best[1];c.setdefault('signature_pose','idle_a');c.setdefault('default_emotion','calm');cast.append(c)
        if best[0]<5: print('WARNING',c['id'],'only differs in',best[0],'attributes; pin more fields or change seed')
    json.dump(cast,open(out,'w'),indent=1);print('wrote',out,len(cast),'characters')
main()
