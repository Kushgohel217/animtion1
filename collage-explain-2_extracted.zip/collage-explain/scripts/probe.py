#!/usr/bin/env python3
"""Render a few frames (and a contact sheet) without making a video.
python3 scripts/probe.py examples/cast-demo/index.html 1.0 4.5 8 --out probe   -> probe_<t>.png + probe_sheet.png"""
import sys,pathlib,argparse
from playwright.sync_api import sync_playwright
from PIL import Image
a=argparse.ArgumentParser();a.add_argument('html');a.add_argument('times',nargs='*',type=float);a.add_argument('--out',default='probe');a.add_argument('--every',type=float,default=0,help='one frame every N seconds (contact sheet of the whole video)')
a=a.parse_args();ims=[]
with sync_playwright() as p:
    b=p.chromium.launch();pg=b.new_page(viewport={'width':360,'height':640});pg.on('pageerror',lambda e:print('PAGE ERROR',e))
    pg.add_init_script('window.SCALE=1');pg.goto(pathlib.Path(a.html).resolve().as_uri());pg.evaluate('window.ready')
    ts=a.times
    if a.every:
        d=pg.evaluate('window.DURATION||54.43');ts=[i*a.every+a.every/2 for i in range(int(d/a.every))]
    for t in ts:
        pg.evaluate(f'render({t})');f=f'{a.out}_{t:.1f}.png';pg.locator('#c').screenshot(path=f);ims.append(Image.open(f))
    b.close()
if ims:
    cols=min(len(ims),6);rows=(len(ims)+cols-1)//cols;sh=Image.new('RGB',(cols*360,rows*640))
    for i,im in enumerate(ims):sh.paste(im,((i%cols)*360,(i//cols)*640))
    sh.save(a.out+'_sheet.png');print('wrote',a.out+'_sheet.png',len(ims),'frames')
