#!/usr/bin/env python3
"""Render index.html frame by frame with Chromium and mux audio with ffmpeg.
Draft : python3 scripts/render.py --html examples/cast-demo/index.html --audio narration.wav --fps 15 --scale 2 --out draft.mp4
Final : ... --fps 30 --scale 3 --out final.mp4   (1080x1920) -- only after the user says "render it"
Duration comes from window.DURATION in the page (story.js sets it) unless --dur is given. Any PAGE ERROR makes the run fail.
"""
import argparse,base64,subprocess,pathlib,sys
from playwright.sync_api import sync_playwright
a=argparse.ArgumentParser()
a.add_argument('--html',required=True);a.add_argument('--audio');a.add_argument('--out',required=True)
a.add_argument('--fps',type=int,default=15);a.add_argument('--scale',type=int,default=2,help='2=720x1280, 3=1080x1920')
a.add_argument('--dur',type=float,default=None);a.add_argument('--start',type=float,default=0.0)
a=a.parse_args()
errs=[]
with sync_playwright() as p:
    b=p.chromium.launch();pg=b.new_page(viewport={'width':360,'height':640});pg.on('pageerror',lambda e:(errs.append(str(e)),print('PAGE ERROR',e)))
    pg.add_init_script(f'window.SCALE={a.scale}')
    pg.goto(pathlib.Path(a.html).resolve().as_uri());pg.evaluate('window.ready')
    dur=a.dur or pg.evaluate('window.DURATION||54.43');n=int(dur*a.fps)
    cmd=['ffmpeg','-v','error','-y','-framerate',str(a.fps),'-f','image2pipe','-c:v','mjpeg','-i','-']
    if a.audio: cmd+=['-ss',str(a.start),'-i',a.audio,'-map','0:v','-map','1:a','-c:a','aac','-b:a','160k']
    cmd+=['-c:v','libx264','-preset','fast','-crf','18','-pix_fmt','yuv420p','-r',str(a.fps),'-t',str(dur),a.out]
    ff=subprocess.Popen(cmd,stdin=subprocess.PIPE)
    for i in range(n):
        d=pg.evaluate(f"(()=>{{render({a.start+i/a.fps});return document.getElementById('c').toDataURL('image/jpeg',.93)}})()")
        ff.stdin.write(base64.b64decode(d.split(',')[1]))
    b.close()
ff.stdin.close();ff.wait()
print('rendered',n,'frames ->',a.out)
if errs: print('INVALID RENDER:',len(errs),'page errors');sys.exit(1)
