#!/usr/bin/env python3
"""Synthesise all sound effects in code (free to use, no samples). 48 kHz mono WAV into ../sfx/."""
import numpy as np,pathlib
from scipy.io import wavfile
SR=48000;out=pathlib.Path(__file__).resolve().parent.parent/'sfx';out.mkdir(exist_ok=True)
rng=np.random.default_rng(7)
def t(d):return np.linspace(0,d,int(SR*d),endpoint=False)
def env(x,a=.005,r=.1):
    n=len(x);e=np.ones(n);ia=max(1,int(a*SR));ir=max(1,int(r*SR));e[:ia]=np.linspace(0,1,ia);e[-ir:]=np.linspace(1,0,ir);return x*e
def lp(x,k):return np.convolve(x,np.ones(k)/k,'same')
def save(n,x):x=x/max(1e-9,np.abs(x).max())*.8;wavfile.write(out/f'{n}.wav',SR,(x*32767).astype(np.int16))
tt=t(.35);save('whoosh',env(lp(rng.standard_normal(len(tt)),int(40-30*np.linspace(0,1,1)[0]))*np.sin(np.pi*tt/.35)**2,.05,.15))   # board-slap transition
tt=t(.12);save('pop',env(np.sin(2*np.pi*(420+900*np.exp(-tt*40))*tt),.002,.08))                                                  # caption chip
tt=t(.6);save('ding',env(np.sin(2*np.pi*1318*tt)*np.exp(-tt*6)+.4*np.sin(2*np.pi*1976*tt)*np.exp(-tt*8),.002,.2))               # idea bulb
tt=t(.5);save('thud',env(np.sin(2*np.pi*55*tt)*np.exp(-tt*9)+lp(rng.standard_normal(len(tt)),60)*np.exp(-tt*20),.002,.1))        # price tag / impact
tt=t(.9);save('burst',env(lp(rng.standard_normal(len(tt)),12)*np.exp(-tt*3.5)+.3*np.sin(2*np.pi*(200+300*tt)*tt),.01,.3))        # powder burst
tt=t(.4);save('sparkle',env(sum(np.sin(2*np.pi*f*tt)*np.exp(-tt*(9+i*2)) for i,f in enumerate([2093,2637,3136])),.002,.15))    # sparkles / stamp-in
tt=t(1.2);save('rain',env(lp(rng.standard_normal(len(tt)),5)*.6+lp(rng.standard_normal(len(tt)),90)*.8,.2,.4))                   # rain bed (loop)
tt=t(.8);save('flash',env(np.sin(2*np.pi*(900-700*tt)*tt)*np.exp(-tt*4)+lp(rng.standard_normal(len(tt)),6)*np.exp(-tt*6),.002,.2))  # headlight flash
print('wrote',sorted(p.name for p in out.glob('*.wav')))
