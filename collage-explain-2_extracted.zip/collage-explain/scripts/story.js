/* story.js - builds the whole video from window.STORY + window.CASTLIST. Load AFTER runtime.js and cast.js.
   STORY = {duration, scenes:[{start,end,bg,framing,layout,cast:[ids],stage?:[{id,x,floor,s,face}],
            lines:[{start,end,text,speaker,emotion,gesture?,reactions?:{id:emotion},gestures?:{id:gesture},look?}]}]}
   Every scene is generated from the script lines; characters come from the cast sheet (cast.js).
   Call buildStory() once after fonts load (index.html does this). */
const FLOOR_F=440,FLOOR_B=418;
const BGS={
 shop_night:{bg(u){sky(0,640,[[0,'#1F2750'],[1,'#3E4290']]);mottle('120,110,200',.25,3);
   blur(1.2,()=>{for(let r=0;r<3;r++){rrect(14,120+r*70,150,8,2,'#6b4a2a');for(let i=0;i<5;i++)rrect(20+i*28,92+r*70,22,28,4,['#C98A3A','#7BA05B','#B5525A','#6D8FC0','#D9C28A'][(i+r)%5])}});
   rrect(222,70,110,130,6,'#2a2f66');for(let i=0;i<14;i++)circ(230+(i*37)%96,80+(i*53)%110,1.4,'#fff');glow(300,100,50,'255,240,190',.8);circ(300,100,14,'#FBE7A0');line([277,70],[277,200],'#6b4a2a',3);line([222,135],[332,135],'#6b4a2a',3);
   rrect(190,222,70,58,3,'#F3EDE0');txt('NOV',225,238,16,C.red);for(let i=0;i<12;i++)rrect(196+(i%4)*15,250+Math.floor(i/4)*9,11,6,1,'#cfc6b0',{ns:1,ne:1});
   line([110,0],[110,40],'#222',2);poly([[84,64],[136,64],[124,38],[96,38]],'#C98A3A',{});glow(110,70,130,'255,225,150',.55);
   sky(400,640,[[0,'#6B4226'],[1,'#3B2414']]);ctx.strokeStyle='rgba(30,10,0,.3)';for(let i=0;i<7;i++){ctx.beginPath();ctx.moveTo(0,410+i*i*5);ctx.lineTo(W,410+i*i*5);ctx.stroke()}},
  fg(u,fr){if(fr==='bust'){rrect(0,430,W,210,0,'#7A4A2A');rrect(0,424,W,12,3,'#9A6A3C')}else{rrect(240,404,112,18,3,'#9A6A3C');for(let i=0;i<4;i++)circ(262+i*12,398,5,'#E0B040')}}},
 classroom:{bg(u){sky(0,640,[[0,'#E8DCB8'],[1,'#CDBE94']]);mottle('255,255,255',.3,5,0,400);
   rrect(30,70,200,110,4,'#2F4A3E',{lw:3,ec:'#8a5a30'});txt('2 + 2 = 4',130,110,26,'#EDEDE0');line([50,150],[200,150],'rgba(255,255,255,.5)',2);
   rrect(250,60,90,120,3,'#9fd0e8');line([295,60],[295,180],'#fff',3);line([250,120],[340,120],'#fff',3);glow(290,120,110,'255,245,200',.5);
   circ(40,40,20,'#fff');circ(40,40,17,'#F3EDE0');line([40,40],[40,28],C.ink,2);line([40,40],[50,44],C.ink,2);
   blur(1.2,()=>{rrect(60,10,70,40,2,'#4a7ab0');rrect(140,16,60,30,2,'#B5525A')});
   sky(400,640,[[0,'#B07A48'],[1,'#7B4F2C']]);ctx.strokeStyle='rgba(60,30,10,.3)';for(let i=0;i<8;i++){ctx.beginPath();ctx.moveTo(0,405+i*i*5);ctx.lineTo(W,405+i*i*5);ctx.stroke()}
   rrect(10,380,70,32,3,'#C79A5F');rrect(280,384,70,30,3,'#C79A5F');ell(300,372,16,13,'#C0574A')},
  fg(u,fr){rrect(0,508,70,10,3,'#8a5a30');rrect(300,500,60,60,6,'#2457A6')}},
 home_day:{bg(u){sky(0,420,[[0,'#F3E3C8'],[1,'#E3C9A0']]);mottle('255,235,200',.3,7,0,420);
   rrect(24,70,92,96,3,'#9fd0e8',{lw:3,ec:'#8a5a30'});line([70,70],[70,166],'#fff',3);line([24,118],[116,118],'#fff',3);glow(70,118,110,'255,245,200',.55);
   rrect(230,50,70,92,3,'#D8B77A');ell(265,92,22,26,'#C98A5A');rrect(300,70,36,54,3,'#B5525A');
   blur(1,()=>{rrect(150,40,60,34,3,'#6D8FC0');rrect(220,160,110,70,6,'#A24B36')});
   rrect(18,200,110,10,3,'#8a5a30');ell(40,190,12,12,'#7BA05B');rrect(90,176,22,24,3,'#E8B04A');
   sky(420,640,[[0,'#A5663A'],[1,'#6F3F22']]);ctx.strokeStyle='rgba(50,20,5,.3)';for(let i=0;i<6;i++){ctx.beginPath();ctx.moveTo(0,425+i*i*6);ctx.lineTo(W,425+i*i*6);ctx.stroke()}
   ell(180,470,120,26,'rgba(180,70,60,.55)',{ns:1,ne:1})},fg(u,fr){rrect(285,470,70,60,6,'#7BA05B');circ(320,462,16,'#4F7D3A')}},
 bedroom_night:{bg(u){sky(0,640,[[0,'#1F2750'],[1,'#3E4290']]);mottle('140,120,210',.22,9);
   rrect(210,60,100,120,5,'#16204a',{lw:3,ec:'#6b4a2a'});glow(260,100,90,'255,240,190',.7);circ(260,100,18,'#FBE7A0');for(let i=0;i<10;i++)circ(220+(i*31)%80,72+(i*47)%100,1.4,'#fff');
   circ(60,60,22,'#F3EDE0');line([60,60],[60,46],C.ink,2);line([60,60],[70,64],C.ink,2);
   rrect(18,300,200,70,8,'#7A5A8A');rrect(18,276,70,34,10,'#E8DDF0');rrect(18,360,200,10,2,'#4a3354');
   blur(1,()=>{rrect(250,240,80,150,4,'#2c3270')});rrect(260,320,60,70,3,'#6b4a2a');rrect(268,290,12,30,3,'#E8B04A');
   sky(400,640,[[0,'#3a2a4a'],[1,'#1c1428']]);ctx.strokeStyle='rgba(255,255,255,.07)';for(let i=0;i<7;i++){ctx.beginPath();ctx.moveTo(0,410+i*i*5);ctx.lineTo(W,410+i*i*5);ctx.stroke()}},fg(){}},
 street_day:{bg(u){sky(0,380,[[0,'#7FB2D8'],[.6,'#CFE4EE'],[1,'#F6E9C8']]);mottle('255,255,255',.5,4,0,250);glow(300,60,90,'255,240,170',.9);circ(300,60,24,'#FBE7A0');
   ell(80,70,40,14,'#fff',{ns:1,ne:1});ell(110,62,30,12,'#fff',{ns:1,ne:1});
   blur(1.3,()=>{for(let i=0;i<7;i++){const h=60+((i*37)%70);rrect(-10+i*54,340-h,48,h+20,2,['#B5784B','#C98A5A','#9AA7B0','#D9B38A'][i%4])}});
   for(let i=0;i<3;i++){rrect(20+i*120,250,90,100,3,['#C98A3A','#B5525A','#6D8FC0'][i]);rrect(32+i*120,266,26,34,2,'#F6E9C8');rrect(66+i*120,266,26,34,2,'#F6E9C8')}
   sky(350,640,[[0,'#9A9A9A'],[1,'#6F6F6F']]);rrect(0,350,W,22,0,'#C9BFA8');for(let i=0;i<5;i++)rrect(20+i*76,500,40,6,2,'#F2EAD0',{ns:1,ne:1});
   rrect(310,200,8,170,2,'#3a3a3a');circ(314,196,10,'#FBE7A0');},fg(){ell(60,520,36,8,'rgba(0,0,0,.25)',{ns:1,ne:1})}},
 lab:{bg(u){sky(0,640,[[0,'#D3E7EB'],[1,'#BBD6DC']]);ctx.strokeStyle='#AECBD3';ctx.lineWidth=1.4;for(let x=0;x<W;x+=30){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,400);ctx.stroke()}for(let y=0;y<400;y+=30){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(W,y);ctx.stroke()}
   mottle('255,255,255',.3,5,0,400);glow(220,60,120,'255,240,190',.6);line([220,0],[220,34],'#444',1.5);poly([[190,56],[250,56],[238,32],[202,32]],'#1F6F6A',{});
   rrect(0,262,150,8,3,C.brown);[['#E8B04A',16],['#4A9AD8',46],['#9AD0A8',78],['#B06A3A',110]].forEach(c=>{ctx.save();ctx.translate(c[1]+14,262);flask(34,c[0]);ctx.restore()});
   rrect(230,320,130,8,3,C.brown);[['#2A4A8A',246],['#D8573A',280],['#cfe0ea',314]].forEach(c=>rrect(c[1],284,22,36,4,c[0],{lw:1.5}));
   rrect(240,90,90,70,3,'#F3EDE0');txt('H2O',285,125,26,'#1F7A73');
   sky(400,640,[[0,'#1F7A73'],[1,'#17605B']]);for(let i=0;i<4;i++)brad(40+i*95,560,3.6)},fg(){}},
 sunset_roof:{bg(u){sky(0,380,[[0,'#A24E72'],[.4,'#E98B52'],[.7,'#F5B866'],[1,'#F8D88E']]);mottle('255,225,170',.3,2,0,300);glow(270,262,170,'255,240,170',.9);circ(270,262,50,'#FBE7A0');
   blur(1.2,()=>{ctx.fillStyle='#8E4A74';for(let i=0;i<13;i++){const h=24+((i*37)%46);ctx.fillRect(i*32-10,336-h,28,h+14)}});
   ctx.fillStyle='#6E3A5C';for(let i=0;i<6;i++)ctx.fillRect(i*66,300-((i*29)%40),34,80);for(let i=0;i<3;i++)line([20+i*120,140+i*12],[90+i*120,150+i*12],'#5a2a40',1.5);
   sky(374,640,[[0,'#C26B3C'],[1,'#7B3A22']]);rrect(0,372,W,14,0,'#8a4a2a');for(let i=0;i<9;i++)line([i*44,386],[i*44,400],'#5a2a14',3);line([0,372],[W,372],'#5a2a14',2);
   for(let i=0;i<4;i++)rrect(20+i*80,455,50,26,3,'rgba(90,40,20,.35)',{ns:1,ne:1})},fg(){}}
};
/* whole-body actions: p=0..1 progress through the line; d=+1/-1 direction. returns offsets about the feet */
const ACTS={
 hop:(p,d)=>({dy:-Math.abs(Math.sin(p*Math.PI*3))*34,sy:1+Math.cos(p*Math.PI*6)*.03}),
 jump:(p,d)=>{const q=clamp(p*1.6);const up=4*q*(1-q)*95;const land=p>.62?Math.exp(-(p-.62)*10)*Math.sin((p-.62)*40)*.06:0;return{dy:-up,sy:1+(q<.15||q>.9?-.09:q<.5?.05:0)+land,sx:1-(q<.15||q>.9?-.07:0)}},
 jump_fail:(p,d)=>{const q=clamp(p*1.5);const up=4*q*(1-q)*80;return{dy:-up,rot:p>.7?Math.sin((p-.7)*30)*.12*Math.exp(-(p-.7)*6):0,sy:p>.66&&p<.8?.88:1,sx:p>.66&&p<.8?1.1:1}},
 walk_in:(p,d)=>({dx:-d*(1-ease(p))*230,dy:-Math.abs(Math.sin(p*Math.PI*9))*6*(1-ease(p)*.6),rot:Math.sin(p*Math.PI*9)*.03}),
 walk_out:(p,d)=>({dx:d*ease(p)*230,dy:-Math.abs(Math.sin(p*Math.PI*9))*6,rot:Math.sin(p*Math.PI*9)*.03}),
 step:(p,d)=>({dx:d*ease(p)*46,dy:-Math.abs(Math.sin(p*Math.PI*3))*5}),
 step_back:(p,d)=>({dx:-d*ease(p)*40,rot:-.04*d*ease(p)}),
 shake:(p,d)=>({dx:Math.sin(p*80)*5,rot:Math.sin(p*60)*.02}),
 laugh:(p,d)=>({dy:-Math.abs(Math.sin(p*Math.PI*7))*12,rot:Math.sin(p*Math.PI*7)*.05,sy:1+Math.sin(p*Math.PI*14)*.025}),
 lean_in:(p,d)=>({rot:d*.1*ease(p),dx:d*14*ease(p)}),
 sag:(p,d)=>({dy:10*ease(p),rot:-.05*d*ease(p),sy:1-.04*ease(p)}),
 tumble:(p,d)=>({rot:-d*1.45*ease(p),dy:36*ease(p),dx:d*30*ease(p)}),
 turn_away:(p,d)=>({dx:d*70*ease(p),rot:.05*d*ease(p),look:-d*.9}),
 bow:(p,d)=>({rot:d*.2*Math.sin(p*Math.PI),dy:6*Math.sin(p*Math.PI)}),
 tremble:(p,d)=>({dx:Math.sin(p*120)*2.2,dy:Math.sin(p*90)*1.2}),
 anticipate_jump:(p,d)=>({sy:1-.12*Math.sin(p*Math.PI),sx:1+.06*Math.sin(p*Math.PI),dy:6*Math.sin(p*Math.PI)})
};
function ambient(u,sc){const R2=R(11);for(let i=0;i<14;i++){const x0=R2()*W,y0=R2()*H,sp=10+R2()*18,x=(x0+u*sp+Math.sin(u*.8+i)*14)%(W+20)-10,y=(y0+u*(sp*.35)+Math.sin(u*1.1+i*2)*10)%(H+20)-10;
  ctx.save();ctx.globalAlpha=.35;ctx.translate(x,y);ctx.rotate(u*.6+i);ell(0,0,3.2+R2()*2,1.6+R2(),(sc.bg==='shop_night'||sc.bg==='bedroom_night')?'#FFF1B8':'#FFFFFF',{ns:1,ne:1,nt:1});ctx.restore()}}
function stagePlan(sc){const ids=sc.cast,n=ids.length;if(sc.stage)return sc.stage.map(p=>Object.assign({s:1,floor:FLOOR_F,x:180},p));
 if(sc.framing==='bust')return ids.map((id,i)=>({id,x:n===1?180:100+i*(160/Math.max(1,n-1)),floor:452,s:1.0,row:0}));
 const H=id=>CASTREG[id].height_scale,byH=ids.slice().sort((x,y)=>H(y)-H(x));
 const nb=n===1?0:n===2?0:Math.floor(n/2),back=byH.slice(0,nb),front=byH.slice(nb);
 const sF=n===1?1.0:n===2?.8:n===3?.68:n===4?.6:.52,sB=sF*.88,out=[];
 const spread=(arr,row,shift)=>{const k=arr.length,rows=ids.length;arr.forEach((id,j)=>{const x=n===1?180:row?360*(j+1)/(k+1):360*(j+.5)/k;
   out.push({id,x:Math.min(330,Math.max(30,x)),floor:row?FLOOR_B-4:FLOOR_F,s:row?sB:sF,row})})};
 spread(front,0,0);spread(back,1,0);
 /* keep the original script order for the draw/ID lookup, back row is drawn first in buildStory */
 return out}
function buildStory(){const ST=window.STORY;registerCast(window.CASTLIST);window.DURATION=ST.duration;S.length=0;CH.length=0;
 ST.scenes.forEach((sc,si)=>{const plan=stagePlan(sc),bgp=BGS[sc.bg]||BGS.home_day,fr=sc.framing||'full';
  S.push([sc.start,sc.end,(u,d)=>{const t=sc.start+u,dur=sc.end-sc.start,cam=sc.cam||'push',pc=clamp(u/dur);
   ctx.save();ctx.translate(W/2,H/2);const zz=cam==='push'?1+.07*pc:cam==='pull'?1.07-.07*pc:1.02;ctx.scale(zz,zz);ctx.translate((cam==='pan_left'?-1:cam==='pan_right'?1:0)*(pc-.5)*26-W/2,-H/2);
   const line=(sc.lines||[]).find(l=>t>=l.start&&t<l.end)||null;
   if(line&&line.shake&&t-line.start<.5)ctx.translate(Math.sin((t-line.start)*70)*4*(1-(t-line.start)/.5),Math.cos((t-line.start)*60)*3*(1-(t-line.start)/.5));
   ctx.save();ctx.translate(W/2,H/2);ctx.scale(1.04,1.04);ctx.translate(Math.sin(u*.6)*5-W/2,-H/2);bgp.bg(u);ctx.restore();
   const spk=line?plan.find(p=>p.id===line.speaker):null;
   const order=plan.slice().sort((a,b)=>(b.row||0)-(a.row||0));
   order.forEach((p,k)=>{const sp=CASTREG[p.id],isSp=line&&line.speaker===p.id;
    let emo=isSp?line.emotion:(line&&line.reactions&&line.reactions[p.id])||(sc.moods&&sc.moods[p.id])||sp.default_emotion;
    let ges=isSp?(line.gesture||sp.signature_pose):(line&&line.gestures&&line.gestures[p.id])||(sc.gestures&&sc.gestures[p.id])||(k%2?'idle_a':'idle');
    let an=isSp?line.action:(line&&line.actions&&line.actions[p.id]);let ap=line?clamp((t-line.start)/Math.max(.01,line.end-line.start)):0;
    const tgt=spk&&!isSp?spk:plan.find(q=>q.id!==p.id),dirx=tgt?Math.sign(tgt.x-p.x)||1:1,look0=tgt?dirx*.7:0,pi=ease((u-.05*k)/.35);
    let A={};if(an&&ACTS[an])A=ACTS[an](ap,dirx);
    /* hold the end pose of the last action until the next line so nobody snaps back */
    if(!an&&sc.lines){const prev=sc.lines.filter(l=>l.end<=t).pop();const pa=prev&&(prev.speaker===p.id?prev.action:(prev.actions&&prev.actions[p.id]));if(pa&&ACTS[pa]&&/^(walk_in|walk_out|step|step_back|turn_away|tumble|sag)$/.test(pa))A=ACTS[pa](1,dirx)}
    const bx=Math.sin(u*1.3+k*1.7)*3,by=Math.sin(u*2.2+k)*1.2;
    ctx.save();ctx.globalAlpha=clamp(pi*1.6);ctx.translate(p.x+(A.dx||0)+bx,p.floor+(A.dy||0)+by+(1-pi)*14);ctx.rotate(A.rot||0);ctx.scale(A.sx||1,A.sy||1);
    makePerson(p.id,0,0,p.s,{emotion:emo,gesture:ges,u:u,talk:isSp,look:A.look!=null?A.look:(p.look!=null?p.look:look0),lean:(k%3-1)*.7,nolegs:fr==='bust',face:p.face||1,tilt:((k%2)?1:-1)*.05+(A.rot||0)*.5});ctx.restore()});
   ambient(u,sc);if(bgp.fg)bgp.fg(u,fr);ctx.restore()}]);
  /* captions from the lines: 2-3 word chips, <=75% of the screen */
  (sc.lines||[]).forEach((l,li)=>{if(!l.text)return;const words=l.text.toUpperCase().split(/\s+/),chips=[];ctx.font='29px Anton, "DejaVu Sans", sans-serif';let cur=[];
   words.forEach(w=>{const test=cur.concat(w).join(' ');if(cur.length&&(cur.length>=3||ctx.measureText(test).width>238)){chips.push(cur.join(' '));cur=[w]}else cur.push(w)});if(cur.length)chips.push(cur.join(' '));
   const dd=(l.end-l.start)/chips.length;chips.forEach((c,i)=>CH.push([l.start+i*dd,c]));const nx=(sc.lines||[])[li+1];if(!nx||nx.start>l.end+.01)CH.push([l.end,''])})});
 CH.sort((a,b)=>a[0]-b[0])}
