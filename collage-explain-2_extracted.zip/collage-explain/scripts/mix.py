#!/usr/bin/env python3
"""Cue sheet of SFX on exact times + voice + optional bed, mastered to a LUFS target.
cues.json: {"voice":"narration.wav","bed":null,"bed_gain_db":-18,"lufs":-14,
            "cues":[{"t":4.37,"file":"whoosh","gain_db":-6}, ...]}
python3 mix.py cues.json out.wav"""
import json,subprocess,sys,pathlib
cfg=json.load(open(sys.argv[1]));out=sys.argv[2];sfx=pathlib.Path(__file__).resolve().parent.parent/'sfx'
ins=[cfg['voice']];fl=['[0:a]aformat=sample_rates=48000:channel_layouts=stereo[v]'];lab=['[v]']
if cfg.get('bed'):
    ins.append(cfg['bed']);fl.append(f"[1:a]aformat=sample_rates=48000:channel_layouts=stereo,volume={cfg.get('bed_gain_db',-18)}dB[bed]");lab.append('[bed]')
for c in cfg['cues']:
    i=len(ins);ins.append(str(sfx/(c['file']+'.wav')));ms=int(c['t']*1000)
    fl.append(f"[{i}:a]aformat=sample_rates=48000:channel_layouts=stereo,volume={c.get('gain_db',-6)}dB,adelay={ms}|{ms}[s{i}]");lab.append(f'[s{i}]')
fl.append(''.join(lab)+f"amix=inputs={len(lab)}:normalize=0:duration=first,loudnorm=I={cfg.get('lufs',-14)}:TP=-1.0:LRA=11[o]")
cmd=['ffmpeg','-v','error','-y']
for f in ins:cmd+=['-i',f]
cmd+=['-filter_complex',';'.join(fl),'-map','[o]','-ar','48000',out];subprocess.run(cmd,check=True);print('mixed ->',out)
