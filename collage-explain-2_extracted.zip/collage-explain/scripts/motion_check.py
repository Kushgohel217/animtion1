#!/usr/bin/env python3
"""Motion QA: fails if the video is (nearly) static. Renders frames every 0.2 s and measures frame-to-frame change.
python3 scripts/motion_check.py examples/<n>/index.html [--min 0.6]
Rules: every 1.5 s window must change >= --min (mean abs pixel diff of the character area), and every scene must contain a big pose change."""
import sys,pathlib,argparse,numpy as np
from playwright.sync_api import sync_playwright
from PIL import Image
import io
a=argparse.ArgumentParser();a.add_argument('html');a.add_argument('--min',type=float,default=0.6);a=a.parse_args()
fr=[]
with sync_playwright() as p:
    b=p.chromium.launch();pg=b.new_page(viewport={'width':360,'height':640});pg.on('pageerror',lambda e:print('PAGE ERROR',e))
    pg.add_init_script('window.SCALE=1');pg.goto(pathlib.Path(a.html).resolve().as_uri());pg.evaluate('window.ready')
    D=pg.evaluate('window.DURATION||54.43');step=.2;n=int(D/step)
    for i in range(n):
        pg.evaluate(f'render({i*step:.3f})');im=Image.open(io.BytesIO(pg.locator('#c').screenshot())).convert('L').crop((0,60,360,470));fr.append(np.asarray(im,dtype=np.float32))
    story=pg.evaluate('window.STORY||null');b.close()
d=[float(np.abs(fr[i+1]-fr[i]).mean()) for i in range(len(fr)-1)];w=int(1.5/step);bad=0
for i in range(0,len(d)-w+1,w//2 or 1):
    m=sum(d[i:i+w])/w
    if m<a.min: bad+=1;print(f'STATIC {i*step:.1f}-{(i+w)*step:.1f}s  motion={m:.2f} (< {a.min})')
big=[(i*step,float(np.abs(fr[min(i+5,len(fr)-1)]-fr[i]).mean())) for i in range(0,len(fr)-1,5)]
if story:
    for i,sc in enumerate(story['scenes']):
        ls=sc.get('lines',[]);na=sum(1 for l in ls if l.get('action') or l.get('actions'))
        if na<max(1,len(ls)//2): bad+=1;print(f'NO ACTIONS: scene {i} ({sc.get("bg")}) has {na}/{len(ls)} lines with a whole-body action (need >= half, min 1)')
        if not sc.get('cam'): print(f'note: scene {i} has no cam (defaults to push)')
print('mean motion %.2f  min window ok=%s'%(sum(d)/len(d),bad==0))
sys.exit(1 if bad else 0)
