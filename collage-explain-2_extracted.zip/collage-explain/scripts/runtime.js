// Collage Explain runtime (core + scenes). Every frame is a pure function of t: render(t).
// Collage Explain v2 — core: painterly paper primitives + jointed puppets. Pure functions of t.
const W=360,H=640,cv=document.getElementById('c'),ctx=cv.getContext('2d');const SC=window.SCALE||2;cv.width=360*SC;cv.height=640*SC;
const C={cream:'#F3EDE0',ink:'#1F1A18',red:'#C0392B',must:'#F2B705',blue:'#2457A6',skin:'#B5784B',skinL:'#C98E60',brown:'#7A4A2A'};
const ease=x=>x<0?0:x>1?1:1-Math.pow(1-x,3),clamp=(x,a=0,b=1)=>Math.min(b,Math.max(a,x)),mix=(a,b,k)=>a+(b-a)*k;
const back=x=>{x=clamp(x);const c=1.70158;return 1+(c+1)*Math.pow(x-1,3)+c*Math.pow(x-1,2)};
function R(seed){let s=(Math.abs(Math.floor(seed))%2147483646)+1;return()=>{s=s*16807%2147483647;return s/2147483647}}
let BOIL=0,TNOW=0;
// paper grain with fibres
const grain=document.createElement('canvas');grain.width=360;grain.height=640;
(function(){const g=grain.getContext('2d'),r=R(7);g.fillStyle='#fff';g.fillRect(0,0,360,640);
 for(let i=0;i<14000;i++){const a=r()*6.28,l=1+r()*4,x=r()*360,y=r()*640;g.strokeStyle=r()<.5?'rgba(255,255,255,.55)':'rgba(90,60,30,.22)';g.lineWidth=.6;g.beginPath();g.moveTo(x,y);g.lineTo(x+Math.cos(a)*l,y+Math.sin(a)*l);g.stroke()}})();
const crum=document.createElement('canvas');crum.width=360;crum.height=640;
(function(){const g=crum.getContext('2d'),r=R(31);g.fillStyle='rgb(128,128,128)';g.fillRect(0,0,360,640);
 for(let i=0;i<70;i++){let x=r()*360,y=r()*640;g.lineWidth=1+r()*2;g.strokeStyle=r()<.5?'rgba(255,255,255,.12)':'rgba(0,0,0,.12)';g.beginPath();g.moveTo(x,y);for(let k=0;k<5;k++){x+=(r()-.5)*90;y+=(r()-.5)*90;g.lineTo(x,y)}g.stroke()}
 for(let i=0;i<30;i++){const x=r()*360,y=r()*640,rad=40+r()*90,gr=g.createRadialGradient(x,y,0,x,y,rad),cl=r()<.5?'255,255,255':'0,0,0';gr.addColorStop(0,`rgba(${cl},.12)`);gr.addColorStop(1,`rgba(${cl},0)`);g.fillStyle=gr;g.fillRect(x-rad,y-rad,rad*2,rad*2)}})();
const GP=ctx.createPattern(grain,'repeat');
const tmpc=document.createElement('canvas');tmpc.width=360*SC;tmpc.height=640*SC;const tcx=tmpc.getContext('2d');
function grade(){tcx.setTransform(1,0,0,1,0,0);tcx.clearRect(0,0,cv.width,cv.height);tcx.drawImage(cv,0,0);ctx.save();ctx.setTransform(1,0,0,1,0,0);ctx.clearRect(0,0,cv.width,cv.height);ctx.filter='saturate(.8) contrast(.95) sepia(.12)';ctx.drawImage(tmpc,0,0);ctx.restore()}
function wash(y0,y1,seed){const r=R(seed);ctx.save();ctx.beginPath();ctx.rect(0,y0,W,y1-y0);ctx.clip();for(let i=0;i<16;i++){const cl=r()<.5?'255,255,255':'30,15,5';glow(r()*W,y0+r()*(y1-y0),50+r()*90,cl,.10+r()*.08)}ctx.restore()}
const lg=(x0,y0,x1,y1,st)=>{const g=ctx.createLinearGradient(x0,y0,x1,y1);st.forEach((s,i)=>g.addColorStop(s[0],s[1]));return g};
const rg=(x,y,r0,r1,st)=>{const g=ctx.createRadialGradient(x,y,r0,x,y,r1);st.forEach(s=>g.addColorStop(s[0],s[1]));return g};
function paper(fn,fill,o={}){ctx.save();if(!o.ns){ctx.shadowColor='rgba(40,20,10,.4)';ctx.shadowBlur=o.sb||10;ctx.shadowOffsetX=2;ctx.shadowOffsetY=o.so||5}
 ctx.beginPath();fn();ctx.fillStyle=fill;ctx.fill();ctx.shadowColor='transparent';
 if(!o.nt){ctx.save();ctx.clip();ctx.globalCompositeOperation='multiply';ctx.globalAlpha=.45;ctx.fillStyle=GP;ctx.fillRect(-900,-900,2400,2400);ctx.globalCompositeOperation='source-over';ctx.globalAlpha=1;ctx.lineWidth=7;ctx.strokeStyle='rgba(70,45,20,.16)';ctx.stroke();ctx.restore()}
 if(!o.ne){ctx.lineWidth=o.lw||2.2;ctx.strokeStyle=o.ec||'rgba(255,252,244,.92)';ctx.stroke()}ctx.restore()}
const rrect=(x,y,w,h,r,f,o)=>paper(()=>ctx.roundRect(x,y,w,h,r),f,o);
const ell=(x,y,rx,ry,f,o)=>paper(()=>ctx.ellipse(x,y,rx,ry,0,0,7),f,o);
const poly=(p,f,o)=>paper(()=>p.forEach((q,i)=>i?ctx.lineTo(q[0],q[1]):ctx.moveTo(q[0],q[1])),f,o);
function jrect(x,y,w,h,f,o={}){const r=R(x*13+y*7+w+BOIL*977),j=o.j??2,p=[],n=4;const J=()=>(r()-.5)*j;
 for(let i=0;i<n;i++)p.push([x+w*i/n+J(),y+J()]);for(let i=0;i<n;i++)p.push([x+w+J(),y+h*i/n+J()]);for(let i=0;i<n;i++)p.push([x+w-w*i/n+J(),y+h+J()]);for(let i=0;i<n;i++)p.push([x+J(),y+h-h*i/n+J()]);poly(p,f,o)}
function circ(x,y,r,f,a=1){ctx.save();ctx.globalAlpha=a;ctx.fillStyle=f;ctx.beginPath();ctx.arc(x,y,r,0,7);ctx.fill();ctx.restore()}
function glow(x,y,r,rgb,a){const g=ctx.createRadialGradient(x,y,0,x,y,r);g.addColorStop(0,`rgba(${rgb},${a})`);g.addColorStop(1,`rgba(${rgb},0)`);ctx.fillStyle=g;ctx.fillRect(x-r,y-r,r*2,r*2)}
function txt(s,x,y,sz,col,al='center',rot=0,ff='Anton'){ctx.save();ctx.translate(x,y);ctx.rotate(rot);ctx.font=sz+'px '+ff+', "DejaVu Sans", sans-serif';ctx.textAlign=al;ctx.textBaseline='middle';ctx.fillStyle=col;ctx.fillText(s,0,0);ctx.restore()}
function line(a,b,c,w=2,dash){ctx.save();ctx.strokeStyle=c;ctx.lineWidth=w;if(dash)ctx.setLineDash(dash);ctx.beginPath();ctx.moveTo(a[0],a[1]);ctx.lineTo(b[0],b[1]);ctx.stroke();ctx.restore()}
function blur(px,fn){ctx.save();ctx.filter=`blur(${px*SC}px)`;fn();ctx.restore()}
function mottle(rgb,a,seed,y0=0,y1=H){const r=R(seed);for(let i=0;i<9;i++)glow(r()*W,y0+r()*(y1-y0),90+r()*90,rgb,a*(.5+r()*.7))}
function brad(x,y,r=4.2){circ(x,y,r+1,'#6b4a12');circ(x,y,r,rg(x-1,y-1,0,r,[[0,'#ffe28a'],[1,'#b8861e']]))}
function tape(x,y,rot=0){ctx.save();ctx.translate(x,y);ctx.rotate(rot);ctx.globalAlpha=.7;ctx.fillStyle='#E7D9A4';ctx.fillRect(-16,-6,32,12);ctx.restore()}
function sparkle(x,y,r,a){ctx.save();ctx.globalAlpha=a;ctx.fillStyle='#fff';ctx.beginPath();for(let i=0;i<8;i++){const rad=i%2?r*.28:r;ctx.lineTo(x+Math.cos(i*.785)*rad,y+Math.sin(i*.785)*rad)}ctx.fill();ctx.restore()}
// ---- puppet parts ----
function arm(side,ang,bend,sx,sy,sleeve,len1,len2,hold){ctx.save();ctx.translate(sx,sy);ctx.rotate(-side*(ang+Math.sin(TNOW*1.7+sx*.1)*1.6)*Math.PI/180);
 rrect(-13,-14,26,len1+14,11,sleeve);ctx.translate(0,len1);ctx.rotate(-side*(bend||0)*Math.PI/180);
 rrect(-9,-6,18,len2+6,8,'#A56B3E');ell(0,len2+8,10,11,'#B27C4C');if(hold){ctx.save();ctx.translate(0,len2+8);hold();ctx.restore()}brad(0,0);ctx.restore();brad(sx,sy)}
function head(o,r=50){const m=o.mouth||'smile',blink=(TNOW%2.7)<.13&&!o.shut;ctx.save();ctx.translate(0,(o.bob||0)+Math.sin(TNOW*2.3)*1.2);ctx.rotate((o.tilt||0)+Math.sin(TNOW*1.3)*.012);
 ell(-r*.9,6,7,11,'#A66B40');ell(r*.9,6,7,11,'#A66B40');
 paper(()=>ctx.ellipse(0,2,r*.94,r*1.04,0,0,7),rg(-8,-10,6,r+8,[[0,'#C58C5C'],[1,'#A66D43']]),{lw:2.6});
 ctx.fillStyle='#262020';ctx.beginPath();ctx.ellipse(0,-12,r*.97,r*.86,0,Math.PI+.1,-.1);ctx.lineTo(r*.2,-r*.5);ctx.quadraticCurveTo(-r*.1,-r*.64,-r*.28,-r*.5);ctx.closePath();ctx.fill();
 ctx.strokeStyle='rgba(200,150,95,.8)';ctx.lineWidth=1.6;ctx.beginPath();ctx.moveTo(-r*.28,-r*.5);ctx.quadraticCurveTo(-r*.22,-r*.75,-r*.3,-r*.92);ctx.stroke();
 ctx.strokeStyle='rgba(255,255,255,.16)';ctx.lineWidth=1.2;for(let i=0;i<4;i++){ctx.beginPath();ctx.moveTo(8+i*9,-r*.88);ctx.quadraticCurveTo(14+i*9,-r*.7,10+i*9,-r*.52);ctx.stroke()}
 circ(-18,14,9,'rgba(205,110,85,.2)');circ(18,14,9,'rgba(205,110,85,.2)');ell(0,10,5,4,'rgba(110,60,30,.28)',{ns:1,ne:1,nt:1});
 const ey=-2;[-1,1].forEach(s=>{const ex=s*15;
  if(o.shut||blink){ctx.strokeStyle='#241c18';ctx.lineWidth=2.6;ctx.beginPath();ctx.arc(ex,ey+(o.happy?3:0),6.5,o.happy?3.4:.15,o.happy?6:3);ctx.stroke()}
  else{const wide=o.wide;ctx.fillStyle='#F2ECDF';ctx.beginPath();ctx.ellipse(ex,ey,wide?8.5:6.4,wide?9:5,0,0,7);ctx.fill();ctx.fillStyle='#2a1a12';ctx.beginPath();ctx.arc(ex+(o.look||0),ey+.5,wide?3.2:3,0,7);ctx.fill();circ(ex+(o.look||0)-1,ey-.5,1,'#fff');
   if(!wide){ctx.fillStyle='#B27A4E';ctx.beginPath();ctx.ellipse(ex,ey,6.8,5.4,0,Math.PI,0);ctx.fill();ctx.strokeStyle='#241c18';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(ex-7,ey);ctx.lineTo(ex+7,ey);ctx.stroke()}else{ctx.strokeStyle='#241c18';ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(ex,ey,8.5,9,0,0,7);ctx.stroke()}}});
 const sad=m==='sad';ctx.strokeStyle='#221a16';ctx.lineWidth=3;ctx.lineCap='round';[-1,1].forEach(s=>{ctx.beginPath();ctx.moveTo(s*27,ey-13+(sad?3:(o.wide?-8:0)));ctx.quadraticCurveTo(s*17,ey-19+(sad?-3:(o.wide?-9:0)),s*7,ey-15+(sad?-7:(o.wide?-8:-1)));ctx.stroke()});
 if(o.kind!=='woman'){ctx.fillStyle=o.kind==='old'?'#cfcfcf':'#1f1816';ctx.beginPath();ctx.moveTo(-24,24);ctx.quadraticCurveTo(-13,13,0,19);ctx.quadraticCurveTo(13,13,24,24);ctx.quadraticCurveTo(13,30,0,26);ctx.quadraticCurveTo(-13,30,-24,24);ctx.fill()}
 ctx.strokeStyle='#2a1612';ctx.lineWidth=2.6;ctx.beginPath();
 if(m==='smile'){ctx.arc(0,31,9,.25,2.9);ctx.stroke()}else if(m==='sad'){ctx.arc(0,47,8,3.4,6);ctx.stroke()}
 else if(m==='open'){ctx.fillStyle='#4a1510';ctx.beginPath();ctx.ellipse(0,38,9,8,0,0,7);ctx.fill();ctx.fillStyle='#fff';ctx.fillRect(-6,31,12,4)}
 else if(m==='grin'){ctx.fillStyle='#4a1510';ctx.beginPath();ctx.arc(0,31,12,.1,3.04);ctx.closePath();ctx.fill();ctx.fillStyle='#fff';ctx.fillRect(-9,32,18,4)}
 else{ctx.moveTo(-7,37);ctx.lineTo(7,37);ctx.stroke()}
 if(o.tear){const t=o.tear;circ(-17,18+(t*22)%26,4,'rgba(170,215,255,.9)')}
 if(o.kind==='old'){ctx.strokeStyle='#222';ctx.lineWidth=2;[-1,1].forEach(s=>{ctx.strokeRect(s*16-10,-12,20,15)});ctx.beginPath();ctx.moveTo(-6,-6);ctx.lineTo(6,-6);ctx.stroke()}
 ctx.restore()}
function man(x,y,s,o={}){ctx.save();ctx.translate(x,y);ctx.scale(s,s*(1+Math.sin(TNOW*2.1)*.006));const k=o.kind||'man',coat=o.coat;
 const shirt=k==='woman'?'#B5382E':k==='old'?'#4D6DA8':coat?'#E6ECEE':'#EAE4D6';
 if(!o.nolegs){if(k==='woman'){poly([[-52,-6],[52,-6],[62,230],[-62,230]],'#1E7A72');ctx.fillStyle='#E0A020';ctx.fillRect(-62,222,124,8)}
  else{rrect(-46,-6,40,114,9,'#7F8798');rrect(6,-6,40,114,9,'#7F8798');brad(-26,62);brad(26,62);ell(-30,116,27,10,'#3a2a22');ell(30,116,27,10,'#3a2a22')}}
 {const B=coat?45:2;paper(()=>{ctx.moveTo(-30,-138);ctx.lineTo(30,-138);ctx.quadraticCurveTo(64,-134,65,-98);ctx.lineTo(60,B);ctx.lineTo(-60,B);ctx.lineTo(-65,-98);ctx.quadraticCurveTo(-64,-134,-30,-138)},lg(0,-135,0,0,[[0,shirt],[1,k==='man'&&!coat?'#DED7C6':shirt]]))}
 if(k==='man'&&!coat){rrect(-60,-16,120,16,3,'#5a3a22',{ne:1,so:2});rrect(-10,-17,20,18,3,'#c9a24a',{ne:1,ns:1})}
 if(coat){poly([[-14,-135],[0,-95],[-28,-135]],'#dfe8ec',{lw:1.4,ns:1});poly([[14,-135],[0,-95],[28,-135]],'#dfe8ec',{lw:1.4,ns:1})}
 rrect(-14,-152,28,28,7,'#A66B40',{ns:1});
 poly([[-26,-138],[0,-120],[-8,-150],[-28,-148]],coat?'#f6f9fa':'#F7F3EA',{lw:1.6,ns:1});poly([[26,-138],[0,-120],[8,-150],[28,-148]],coat?'#f6f9fa':'#F7F3EA',{lw:1.6,ns:1});
 if(k==='man'&&!coat)poly([[-6,-136],[6,-136],[0,-120]],'#7a4a2a',{ns:1,ne:1});
 for(let i=0;i<4;i++)circ(0,-108+i*28,3.6,'#c8c2b4');
 rrect(12,-108,40,42,4,'rgba(0,0,0,0)',{ns:1,lw:1.6,ec:'rgba(130,120,110,.75)'});rrect(24,-116,6,26,2,'#26357a',{ns:1,ne:1});
 if(k==='woman'){poly([[-55,-130],[55,-60],[40,-40],[-55,-100]],'#1E7A72',{lw:1.6,ns:1});rrect(-60,-100,120,14,6,'#E0A020',{ns:1,ne:1,so:1})}
 const sl=shirt;
 arm(-1,o.aL??10,o.bL,-62,-118,sl,46,50,o.hL);arm(1,o.aR??10,o.bR,62,-118,sl,46,50,o.hR);
 ctx.save();ctx.translate(0,-184);ctx.scale(.9,.9);if(k==='woman'){ell(0,-58,22,22,'#211a18')}head(o);ctx.restore();ctx.restore()}
function girl(x,y,s,o={}){ctx.save();ctx.translate(x,y);ctx.scale(s,s);
 rrect(-14,60,12,66,5,'#A56B3E');rrect(2,60,12,66,5,'#A56B3E');ell(-8,130,15,7,'#1d1612');ell(8,130,15,7,'#1d1612');
 const sw=o.sw||64;ctx.save();paper(()=>{ctx.moveTo(-26,-40);ctx.lineTo(26,-40);ctx.lineTo(sw,78);for(let i=0;i<8;i++)ctx.arc(sw-(i+.5)*sw*2/8,78,sw/8,0,Math.PI);ctx.lineTo(-sw,78)},'#FBFBF6');
 ctx.fillStyle=C.blue;for(let i=0;i<7;i++){ctx.beginPath();ctx.ellipse(-sw+14+i*(sw*2-28)/6,82,4.5,2.6,0,0,7);ctx.fill()}ctx.restore();rrect(-28,-8,56,10,4,'#3A78C8',{ns:1,ne:1});
 arm(-1,o.aL??75,0,-28,-34,'#FBFBF6',22,34,0);arm(1,o.aR??75,0,28,-34,'#FBFBF6',22,34,0);
 ctx.save();ctx.translate(0,-84);[-1,1].forEach(sd=>{rrect(sd*44-8,0,16,50,8,'#221a16',{ns:1});circ(sd*44,6,6,C.red)});
 ell(0,0,40,40,rg(-6,-6,4,44,[[0,'#C48B5C'],[1,'#A8703F']]));ctx.fillStyle='#221a16';ctx.beginPath();ctx.ellipse(0,-6,41,34,0,Math.PI,0);ctx.fill();
 circ(-14,0,4,'#231b17');circ(14,0,4,'#231b17');ctx.strokeStyle='#221a16';ctx.lineWidth=2.4;ctx.beginPath();ctx.arc(0,14,10,.2,2.9);ctx.stroke();circ(-22,12,7,'rgba(210,110,90,.28)');circ(22,12,7,'rgba(210,110,90,.28)');ctx.restore();ctx.restore()}
function packet(x,y,w,h,rot=0,o={}){ctx.save();ctx.translate(x,y);ctx.rotate(rot);
 rrect(-w/2,-h/2,w,h,4,lg(0,-h/2,0,h/2,[[0,'#F9C71E'],[1,'#EEB10A']]));
 ctx.fillStyle='#D9A004';for(let i=0;i<9;i++){ctx.beginPath();ctx.moveTo(-w/2+i*w/9,-h/2);ctx.lineTo(-w/2+(i+.5)*w/9,-h/2-h*.04);ctx.lineTo(-w/2+(i+1)*w/9,-h/2);ctx.fill()}
 ell(0,-h*.12,w*.36,h*.18,'#CFE6F6',{ns:1,lw:1.2});rrect(-w/2+2,h*.06,w-4,h*.2,2,'#2f62b4',{ns:1,ne:1});
 for(let i=0;i<3;i++)circ(-w*.25+i*w*.22,h*.38,w*.045,'rgba(255,245,200,.8)');
 if(o.name)txt('NIRMA',0,h*.16,w*.25,'#fff','center',.02);if(o.girl)girl(0,-h*.14,w*.0021,{});
 if(o.blank)0;ctx.restore()}
function boxBlue(x,y,w,h,rot=0){ctx.save();ctx.translate(x,y);ctx.rotate(rot);rrect(-w/2,-h/2,w,h,3,'#3562B8');ctx.save();ctx.beginPath();ctx.rect(-w/2,-h/2,w,h);ctx.clip();ctx.fillStyle='#F0A030';ctx.rotate(-.5);ctx.fillRect(-w,-h*.12,w*2,h*.2);ctx.restore();circ(-w*.2,-h*.25,w*.07,'#fff');circ(w*.05,-h*.32,w*.05,'#fff');ctx.restore()}
function lampcone(x,y,w,a){ctx.fillStyle=lg(0,y,0,y+440,[[0,`rgba(255,235,170,${a})`],[1,'rgba(255,235,170,0)']]);ctx.beginPath();ctx.moveTo(x-8,y);ctx.lineTo(x+8,y);ctx.lineTo(x+w,y+440);ctx.lineTo(x-w,y+440);ctx.fill()}
function cloth(x,y,type,rot,sw){ctx.save();ctx.translate(x,y);ctx.rotate(rot);ctx.fillStyle='#8a5a30';rrect(-4,-6,8,14,2,'#9a6a38',{ns:1,lw:1});
 if(type==='shirt')poly([[-30,6],[-10,6],[0,14],[10,6],[30,6],[44,24],[30,34],[22,28],[22,66],[-22,66],[-22,28],[-30,34],[-44,24]],'#F4F1EA',{});
 else if(type==='dress')poly([[-8,6],[8,6],[10,24],[34,66],[-34,66],[-10,24]],'#FBFBF6',{});
 else if(type==='towel')rrect(-26,6,52,64,3,'#F2EEE4',{});else if(type==='check'){rrect(-24,6,48,60,3,'#C0574A',{});ctx.strokeStyle='#F2E8DA';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(-8,6);ctx.lineTo(-8,66);ctx.moveTo(8,6);ctx.lineTo(8,66);ctx.moveTo(-24,26);ctx.lineTo(24,26);ctx.moveTo(-24,46);ctx.lineTo(24,46);ctx.stroke()}
 ctx.restore()}

const S=[],st=u=>Math.floor(u*10)/10,sky=(y0,y1,stops)=>{ctx.fillStyle=lg(0,y0,0,y1,stops);ctx.fillRect(0,y0,W,y1-y0);wash(y0,y1,y0*3+y1)};
function flask(w,col){poly([[-4,-w*.8],[4,-w*.8],[4,-w*.35],[w*.5,w*.35],[-w*.5,w*.35],[-4,-w*.35]],col,{lw:1.6,ns:1})}
S.push([0,4.37,(u,d)=>{const pan=ease((u-1.4)/.9)*40+ease((u-3)/1.2)*40;
 sky(0,380,[[0,'#A24E72'],[.4,'#E98B52'],[.7,'#F5B866'],[1,'#F8D88E']]);mottle('255,225,170',.3,2,0,300);glow(270-pan*.3,262,170,'255,240,170',.9);circ(270-pan*.3,262,50,'#FBE7A0');
 blur(1.2,()=>{ctx.fillStyle='#8E4A74';for(let i=0;i<13;i++){const h=24+((i*37)%46);ctx.fillRect(-pan*.4+i*32-10,336-h,28,h+14)}});
 ctx.fillStyle=lg(0,345,0,374,[[0,'#7BB0D4'],[1,'#3F7FB8']]);ctx.fillRect(0,345,W,29);ctx.fillStyle='rgba(255,255,255,.5)';for(let i=0;i<4;i++)ctx.fillRect(40+i*90-pan*.6,360,24,3);
 sky(374,640,[[0,'#C26B3C'],[1,'#7B3A22']]);ctx.strokeStyle='rgba(80,30,10,.25)';ctx.lineWidth=1;for(let i=0;i<8;i++){ctx.beginPath();ctx.moveTo(0,390+i*i*5);ctx.lineTo(W,390+i*i*5);ctx.stroke()}
 line([-10,40],[W+10,46],'#3a2a22',1.4);[[20,'towel'],[96,'shirt'],[176,'dress'],[252,'shirt'],[330,'check']].forEach((c,i)=>cloth(c[0]-pan+Math.sin(u*1.7+i)*2,44,c[1],Math.sin(u*1.7+i)*.03));
 rrect(-6-pan,30,10,360,2,'#B58A52',{ns:1,lw:1.4});
 const dx=245-ease((u-1.5)/.6)*80-ease((u-3)/.8)*25,pour=u<2.0,bx=dx-172-pan*.4;
 rrect(bx-48,486,96,32,3,'#A24B36');rrect(bx-38,420,76,70,10,lg(0,420,0,490,[[0,'#B2B9C2'],[1,'#808893']]));
 for(let i=0;i<7;i++)ell(bx-30+i*10,420+Math.sin(st(u)*9+i)*2,9,8,'#fff',{ns:1,lw:1});
 if(pour){rrect(bx-3,300,7,120,3,C.must,{ns:1,ne:1});for(let i=0;i<6;i++)circ(bx+Math.sin(i*2)*8,410-((u*60+i*20)%40),2.6,C.must)}
 man(dx,418,1.12,{aL:pour?118:14,bL:pour?-50:0,aR:u>3.4?150+Math.sin(st(u)*16)*14:10,mouth:u<2.4?'smile':u<3?'grin':'sad',bob:Math.sin(u*5)*1.2,hL:()=>{ctx.save();ctx.rotate(pour?1.0:3.1);packet(0,-30,50,74,0);ctx.restore()}});
 if(u>2){const gx=430-ease((u-2)/.9)*115;girl(gx,470,.95,{aL:u>3?70:115,aR:70,sw:62+Math.sin(st(u)*12)*3})}}]);
S.push([4.37,6.57,(u,d)=>{ctx.fillStyle='#D3E7EB';ctx.fillRect(0,0,W,H);ctx.strokeStyle='#AECBD3';ctx.lineWidth=1.4;for(let x=0;x<W;x+=30){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,430);ctx.stroke()}for(let y=0;y<430;y+=30){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(W,y);ctx.stroke()}
 mottle('255,255,255',.25,5,0,400);glow(220,60,120,'255,240,190',.6);line([220,0],[220,34],'#444',1.5);poly([[190,56],[250,56],[238,32],[202,32]],'#1F6F6A',{});
 rrect(0,282,150,8,3,C.brown);[['#E8B04A',16],['#4A9AD8',46],['#9AD0A8',78],['#B06A3A',110]].forEach(c=>{ctx.save();ctx.translate(c[1]+14,282);flask(34,c[0]);ctx.restore()});rrect(245,336,115,8,3,C.brown);[['#2A4A8A',262],['#D8573A',296],['#cfe0ea',330]].forEach(c=>rrect(c[1],300,22,36,4,c[0],{lw:1.5}));
 sky(400,640,[[0,'#1F7A73'],[1,'#17605B']]);
 man(205,482,1.0,{coat:1,nolegs:1,aL:100,bL:-28,aR:12,mouth:u>1.2?'smile':'flat',hL:()=>{ctx.save();ctx.rotate(.5);ctx.translate(0,-12);flask(44,'#7fc3ee');ctx.restore()}});
 rrect(0,466,W,14,2,'#1c1f22',{ns:1,ne:1});sky(480,640,[[0,'#1E706A'],[1,'#13504C']]);for(let i=0;i<4;i++)brad(40+i*95,560,3.6);
 rrect(36,430,52,40,3,'rgba(220,240,250,.85)',{lw:1.6});rrect(40,462-ease(u/2)*26,44,ease(u/2)*26+2,2,'#3b9ae0',{ns:1,ne:1});rrect(100,296,5,130,2,'#3b9ae0',{ns:1,ne:1,lw:0});
 rrect(262,452,86,16,3,C.brown);for(let i=0;i<4;i++)rrect(268+i*20,420,12,44,4,['#e8a43a','#3b9ae0','#d8573A','#4aa070'][i],{lw:1.4});
 if(u>.5){const s=back((u-.5)/.35);ctx.save();ctx.translate(90,112);ctx.rotate(-.07);ctx.scale(s,s);jrect(-80,-19,160,38,'#E9E4D4');txt('GUJARAT · 1960s',0,2,21,'#33405a');tape(-74,-16,-.4);ctx.restore()}
 if(u>1.1){const k=clamp((u-1.1)/.5);ctx.save();ctx.translate(292,26+ease(k)*72);ctx.rotate(Math.sin(u*7)*.05*(1-k));line([-34,-30],[-30,-10],'#333',1.4);line([34,-30],[30,-10],'#333',1.4);jrect(-42,-17,84,34,'#EFEAE0');ctx.strokeStyle=C.blue;ctx.lineWidth=2.4;ctx.strokeRect(-36,-12,72,24);txt('LAB',0,2,23,'#1e2f58');brad(-36,-12,3);brad(36,-12,3);ctx.restore()}}]);
S.push([6.57,9.87,(u,d)=>{ctx.save();const z=1+.9*ease((u-1.9)/1.3);ctx.translate(290,200);ctx.scale(z,z);ctx.translate(-290,-200-ease((u-1.9)/1.3)*10);
 sky(0,640,[[0,'#94BDC0'],[1,'#7AA6AB']]);mottle('255,255,255',.3,8);
 ell(80,110,36,36,'#F3F0E8');ctx.strokeStyle='#6a4a34';ctx.lineWidth=5;ctx.beginPath();ctx.arc(80,110,34,0,7);ctx.stroke();line([80,110],[62,92],C.ink,3);line([80,110],[98,116],C.red,1.6);
 rrect(0,236,130,8,3,C.brown);for(let i=0;i<3;i++){rrect(8+i*40,198,36,38,3,'#E4CFA4',{lw:1.6});rrect(8+i*40,214,36,6,1,C.red,{ns:1,ne:1})}
 rrect(232,60,126,176,4,'#7A4A2A');rrect(242,70,106,156,3,'#D9876A',{ns:1});rrect(252,86,86,124,2,u>1.9?'#F7C44A':'#1b2036',{ns:1,lw:1.5});if(u>1.9){glow(295,148,70,'255,240,150',.8);circ(295,134,6,'#fff7cc')}else rrect(252,86,86,28,2,'#F3EFE2',{ns:1,lw:1});
 rrect(242,70,50,156,3,'rgba(240,160,120,.9)',{ns:1,ne:1});line([295,70],[295,226],'#6a3a28',3);ctx.restore();
 const sw=Math.floor(u*3)%2;man(150,450,1.0,{coat:1,nolegs:1,aL:30,bL:40,aR:92+(sw?40:0),bR:-50,mouth:u>1.6?'flat':'smile',tilt:u>1.5?.1:0,hR:()=>{rrect(-9,0,18,10,2,'#6b3a22');rrect(-14,8,28,9,2,'#1d1a18',{lw:1.2})}});
 sky(398,640,[[0,'#9A5F30'],[1,'#5E3720']]);rrect(0,398,W,8,2,'#B5753C',{ns:1,ne:1});ctx.strokeStyle='rgba(60,30,10,.25)';for(let i=0;i<7;i++){ctx.beginPath();ctx.moveTo(0,420+i*i*5);ctx.lineTo(W,420+i*i*5);ctx.stroke()}
 for(let i=0;i<4;i++)rrect(196,404-i*3,86,10,1,'#F2EEE4',{lw:1.2,so:2});rrect(196,380,86,6,1,'#5a8ad0',{ns:1,ne:1});rrect(26,402,40,12,2,C.blue,{lw:1.2});rrect(318,372,36,42,5,'rgba(220,235,242,.9)',{lw:1.4});ctx.save();ctx.translate(318,452);ctx.rotate(-.1);rrect(-4,-8,66,20,5,'#E2CFA6',{lw:1.4});rrect(26,-8,8,20,0,C.red,{ns:1,ne:1});ctx.restore()}]);
S.push([9.87,12.5,(u,d)=>{sky(0,640,[[0,'#1E706A'],[1,'#164E4B']]);mottle('120,200,190',.22,4);
 for(let r=0;r<3;r++){rrect(-4,86+r*100,W+8,7,2,'#6a4a2a',{ns:1});for(let i=0;i<8;i++)boxBlue(20+i*50-(r%2)*25,60+r*100,40,44,((i+r)%3-1)*.02)}
 for(let i=0;i<12;i++){ctx.fillStyle=i%2?'#F2EBDD':'#C84A3A';ctx.beginPath();ctx.moveTo(i*32,0);ctx.lineTo(i*32+32,0);ctx.arc(i*32+16,26,16,0,Math.PI);ctx.fill()}
 man(268,372,.8,{kind:'old',nolegs:1,aL:10,aR:10,mouth:'flat'});
 rrect(150,395,220,250,4,lg(0,395,0,640,[[0,'#8A5A30'],[1,'#5E3A1E']]));rrect(150,395,220,10,2,'#B5753C',{ns:1,ne:1});for(let i=1;i<4;i++)line([150+i*60,405],[150+i*60,640],'rgba(40,20,5,.4)',2);
 const w=u<1.6?'flat':u<2.2?'open':'sad';man(88,420,.86,{kind:'woman',aL:12,aR:92,bR:-70,mouth:w,wide:w==='open',hR:()=>{boxBlue(0,-22,42,46,.1)}});
 const s=u<1.6?1:1+.95*back((u-1.6)/.5);ctx.save();ctx.translate(250,380-(s-1)*18);ctx.scale(s,s);ctx.rotate(-.12);line([-20,-60],[-10,-20],'#444',1.3);poly([[-52,0],[-34,-26],[50,-26],[50,26],[-34,26]],'#F2ECDC',{});circ(-30,0,4,'#CFC4A8');txt('₹₹₹',8,2,28,C.red,'center',0,'DejaVu Sans');ctx.restore()}]);
S.push([12.5,16.93,(u,d)=>{sky(0,640,[[0,'#3E4290'],[.6,'#2B3070'],[1,'#1B2150']]);mottle('140,130,210',.3,3,0,420);const r=R(3);for(let i=0;i<40;i++)circ(r()*W,r()*300,.8+r()*1.3,'#fff',.45);
 ctx.fillStyle='#2A2F68';ctx.beginPath();ctx.moveTo(0,380);ctx.quadraticCurveTo(180,330,360,385);ctx.lineTo(360,640);ctx.lineTo(0,640);ctx.fill();
 [[26,'#6B6FB8'],[334,'#6B6FB8']].forEach(p=>{ell(p[0],452,12,12,p[1],{lw:1.5});poly([[p[0]-15,510],[p[0]+15,510],[p[0]+6,466],[p[0]-6,466]],p[1],{lw:1.5})});
 if(u>.7){const k=back((u-.7)/.5);ctx.save();ctx.translate(40,70);ctx.rotate(-.3);ctx.scale(k,k);rrect(-24,-24,48,48,6,'#F3EDE0');[[-9,-9],[9,9],[0,0]].forEach(p=>circ(p[0],p[1],3.4,C.ink));ctx.restore()}
 ctx.save();ctx.translate(0,Math.sin(u*3)*1.5);ctx.translate(180,500);paper(()=>{ctx.moveTo(-104,70);ctx.quadraticCurveTo(-108,-96,-38,-124);ctx.lineTo(38,-124);ctx.quadraticCurveTo(108,-96,104,70)},lg(0,-124,0,70,[[0,'#EFEBE0'],[1,'#DAD3C2']]));rrect(-15,-146,30,34,7,'#A66B40',{ns:1});poly([[-30,-122],[0,-100],[-8,-142],[-32,-136]],'#F6F2E8',{lw:1.6,ns:1});poly([[30,-122],[0,-100],[8,-142],[32,-136]],'#F6F2E8',{lw:1.6,ns:1});poly([[-7,-120],[7,-120],[0,-102]],'#7a4a2a',{ns:1,ne:1});for(let i=0;i<3;i++)circ(0,-80+i*30,3.6,'#c8c2b4');ctx.translate(0,-168);head({mouth:u<.7?'flat':u<2.6?'smile':'open',shut:u>3.4,happy:1,tilt:Math.sin(u*2)*.04,look:u<2?0:2});ctx.restore();
 for(let i=0;i<10;i++)rrect(i*40-16,462,40,36,2,['#E0A020','#F3EDE0','#2E8A80'][i%3],{ns:1,lw:1.2});rrect(0,498,W,8,2,'#D8A020',{ns:1,ne:1});sky(506,640,[[0,'#1d2250'],[1,'#12163a']]);
 for(let i=0;i<5;i++){const t0=1.1+.25*i;if(u>t0){const k=back((u-t0)/.3);ctx.save();ctx.translate(36+i*72,500);ctx.scale(1,k);const rc=['#D9573A','#2E8A80','#E0A020','#E6906A','#2E8A80'][i];rrect(-30,-66,60,66,3,['#F3EDE0','#EAD498','#F1DFA8','#F6D4B8','#F3EDE0'][i]);poly([[-36,-66],[36,-66],[0,-104]],rc,{});rrect(-12,-42,24,42,2,'#6b3a1e',{ns:1});rrect(4,-56,14,14,1,u>3?'#F6C34A':'#16183a',{ns:1,lw:1.4});ctx.restore()}}
 if(u>.5){const k=back((u-.5)/.4);ctx.save();ctx.translate(290,98);ctx.scale(k,k);glow(0,0,80,'200,190,255',.5);circ(0,0,36,'#4b4aa6');for(let i=0;i<12;i++){ctx.save();ctx.rotate(i*.5236);rrect(-2.5,-56,5,14,2,'#E7C96A',{ns:1,ne:1});ctx.restore()}ell(0,-2,22,23,'#F6D860',{lw:1.4});rrect(-7,20,14,10,2,'#9aa0a8',{lw:1.4});ctx.restore()}
 if(u>2.0){const y=100+ease((u-2)/.7)*80;packet(290,y,34,50,.1)}}]);
S.push([16.93,24.4,(u,d)=>{const shift=ease((u-3)/.4)*-30;sky(0,640,[[0,'#2C3C6C'],[.3,'#3D4A72'],[.45,'#6A5A48'],[1,'#3A2C20']]);mottle('180,150,110',.2,6,200,520);
 const r=R(9);for(let i=0;i<34;i++)circ(r()*W,r()*190,.8+r(),'#fff',.5);circ(310,52,25,'#E8E1CC');glow(310,52,70,'255,250,220',.3);
 glow(300,200,130,'255,200,110',.6);line([300,130],[300,160],C.ink,1.4);rrect(284,160,32,50,5,'#F8E8B4',{lw:1.6});rrect(280,208,40,9,2,'#B8553A',{ns:1});circ(300,186,6,'#F0A030');
 if(u>3.2){line([-10,110],[W+10,118],'#ddd',1.2);cloth(70,118,'check',-.02);cloth(150,118,'shirt',.03)}
 ctx.save();ctx.translate(0,u>3.2?60:0);rrect(30,170,74,86,2,'#F2EDE0',{lw:1.6});rrect(30,170,74,18,2,C.red,{ns:1,ne:1});txt('1969',68,226,30,'#1e2a52');ctx.restore();
 ctx.save();ctx.globalAlpha=.8;ctx.strokeStyle='#15121a';ctx.lineWidth=3;ctx.beginPath();ctx.arc(30,430,34,0,7);ctx.arc(120,430,34,0,7);ctx.moveTo(30,430);ctx.lineTo(70,380);ctx.lineTo(120,430);ctx.stroke();ctx.restore();
 rrect(170,436,200,10,2,'#2a2018',{ns:1});line([190,446],[190,640],'#1a120c',7);line([350,446],[350,640],'#1a120c',7);
 ell(235,432,44,12,'#7C93AE',{lw:1.6});rrect(195,414,80,22,8,'#6B84A2',{lw:1.4});rrect(296,396,24,40,4,'#7fc3ee',{lw:1.4});rrect(322,408,20,28,4,'#E2B84A',{lw:1.4});
 const st1=u<1.5?25:u<4?55+Math.sin(st(u)*14)*16:105;
 man(135+shift,452,1.1,{nolegs:u>=3.2,aL:15,aR:st1,bR:u<1.5?0:-75,mouth:u<4?'flat':u<4.6?'open':'smile',wide:u>4&&u<4.6,hR:()=>{if(u>1.5&&u<4)rrect(-3,10,6,40,2,'#6a4a2a',{ns:1})}});
 ctx.fillStyle='rgba(40,50,100,.18)';ctx.fillRect(0,0,W,H);
 sky(470,640,[[0,'rgba(20,14,10,.0)'],[1,'rgba(20,14,10,.7)']]);
 ell(235,430,60,14,'#7C93AE',{lw:1.6});
 if(u>4.1){const k=clamp((u-4.1)/1.4);for(let i=0;i<16;i++){const a=i*.7+k*3,rad=24+k*80*((i%4)+1)/4;circ(235+Math.cos(a)*rad*1.2,420-Math.abs(Math.sin(a))*rad*1.5-k*50,12+(i%5)*6*(1-k*.3),'rgba(246,204,60,.85)',.9*(1-Math.max(0,k-.8)*4))}}
 if(u>4.4)ell(235,426,48,12,'#F3C63A',{lw:1.4});
 if(u>6.1){const k=back((u-6.1)/.4);ctx.save();ctx.translate(292,330);ctx.scale(k,k);boxBlue(0,0,70,100);ctx.restore();for(let i=0;i<4;i++)ell(300,404-i*7,18,6,'#d6d6d6',{lw:1.2})}
 if(u>6.9)for(let i=0;i<3;i++)sparkle(130+i*60,250+(i%2)*40,12,.5+.5*Math.sin(u*8+i))}]);
S.push([24.4,30.9,(u,d)=>{const bokeh=u>3.2;sky(0,640,[[0,'#0F1530'],[.5,'#1C2850'],[1,'#0e0f1a']]);mottle('70,90,170',.28,12,0,420);const r=R(5);for(let i=0;i<30;i++)circ(r()*W,r()*250,.8+r(),'#fff',.45);
 ctx.save();const z=1+2.2*ease((u-3)/.7);ctx.translate(180,300);ctx.scale(z,z);ctx.translate(-180,-300);
 const bg=()=>{for(let y=280;y<=350;y+=24)rrect(-20,y,W+40,3,1,'#6b7aa8',{ns:1,ne:1});sky(380,640,[[0,'#12121c'],[1,'#080810']]);rrect(30,120,8,330,2,'#3a3a44',{ns:1});rrect(30,120,72,8,2,'#3a3a44',{ns:1});circ(98,140,8,'#fff6c8');glow(98,140,70,'255,240,170',.6);lampcone(98,142,110,.3)};
 if(bokeh)blur(3,bg);else bg();
 if(!bokeh){ctx.save();ctx.translate(95,-25);if(u>.3&&u<2.3){ctx.setLineDash([5,5]);ctx.strokeStyle='#cfd6ee';ctx.lineWidth=2;const k=clamp((u-.3)/1.2);ctx.beginPath();[[140,340],[140,270],[168,245],[168,270],[196,245],[196,270],[224,245],[224,270],[252,245],[252,340],[140,340]].slice(0,Math.ceil(k*11)).forEach((p,i)=>i?ctx.lineTo(p[0],p[1]):ctx.moveTo(p[0],p[1]));ctx.stroke();if(k>.8){ctx.strokeRect(228,196,16,52);ctx.strokeRect(156,296,22,22);ctx.strokeRect(204,296,22,22)}ctx.setLineDash([])}
 if(u>1.4&&u<2.7){ctx.setLineDash([4,4]);ctx.strokeStyle='#cfd6ee';ctx.beginPath();ctx.arc(320,200,20,0,7);ctx.stroke();ctx.setLineDash([])}
 if(u>2.2){ctx.save();ctx.translate(-10,-90);ctx.setLineDash([5,5]);ctx.strokeStyle='#cfd6ee';ctx.lineWidth=2;ctx.strokeRect(140,326,112,64);ctx.strokeRect(100,350,40,40);ctx.strokeRect(106,356,26,16);ctx.beginPath();ctx.arc(128,396,11,0,7);ctx.arc(216,396,11,0,7);ctx.stroke();ctx.setLineDash([]);ctx.restore()}
 ctx.restore();ctx.save();ctx.translate(230,470);ctx.fillStyle='#C9AE7C';ctx.beginPath();ctx.ellipse(0,0,30,34,0,0,7);ctx.fill();ctx.restore()}
 man(180,478,.95,{aL:8,aR:u<3?8:55,bR:u<3?0:-110,mouth:u<1.4?'smile':'sad',tilt:u>1.5?.05:0});ctx.restore();
 if(bokeh){const rr2=R(21);for(let i=0;i<9;i++)circ(rr2()*W,rr2()*500,6+rr2()*10,'rgba(255,215,130,.28)')}
 if(u>4.1){const k=ease((u-4.1)/1.0);ctx.save();ctx.translate(150+30*k,300+(1-k)*90);ctx.rotate(-.05*(1-k));const s=.18+k*.82;ctx.scale(s*1.1,s*1.1);rrect(-95,-125,190,240,4,'#F6F0E2');rrect(-84,-114,168,200,2,'#C9A66E',{ns:1,ne:1});ctx.save();ctx.beginPath();ctx.rect(-84,-114,168,200);ctx.clip();girl(0,158,2.2,{aL:55,aR:55});ctx.restore();ctx.restore()}
 if(u>5.2){const k=ease((u-5.2)/.5);for(let i=0;i<3;i++)rrect(W-110+(1-k)*110,196+i*26,110,22,10,'#B8794A')}}]);
S.push([30.9,32.6,(u,d)=>{sky(0,640,[[0,'#E9C58F'],[.5,'#F2D8A8'],[1,'#B9743A']]);mottle('255,235,190',.3,14);rrect(-6,214,W+12,240,2,'#F4DDB0',{ns:1,ne:1});sky(440,640,[[0,'#C07A3E'],[1,'#8C5226']]);
 blur(1,()=>{ell(318,96,52,40,'#6B8A3A',{ns:1,ne:1})});rrect(26,138,40,26,2,'#D9573A',{lw:1.6});rrect(258,215,92,200,5,'#7A4A2A');rrect(266,223,76,184,3,'#2F6AB8',{ns:1});line([304,223],[304,407],'#1d4a88',2);
 ell(338,436,26,24,'#B5512C',{lw:1.6});rrect(0,390,138,10,2,C.brown);for(let i=0;i<5;i++)line([10+i*26,400],[10+i*26,470],C.brown,5);rrect(0,372,138,22,3,'#D9B574',{lw:1.4});
 ell(90,490,60,8,'rgba(60,30,10,.3)',{ns:1,ne:1});ell(215,495,60,8,'rgba(60,30,10,.3)',{ns:1,ne:1});
 man(82,430,.9,{coat:0,aL:62+Math.sin(st(u)*14)*8,bL:80,aR:62,bR:80,mouth:'grin',shut:1,happy:1});girl(212,365,1.0,{aL:80,aR:80,sw:42+Math.abs(Math.sin(st(u)*9))*28})}]);
S.push([32.6,36.9,(u,d)=>{if(u<1.9){sky(0,240,[[0,'#B5586A'],[.6,'#EE9A55'],[1,'#F7C27A']]);mottle('255,230,170',.3,15,0,230);blur(1,()=>{ctx.fillStyle='#7C5A86';ctx.beginPath();ctx.moveTo(0,225);for(let x=0;x<=360;x+=30)ctx.lineTo(x,205+Math.sin(x*.03)*14);ctx.lineTo(360,235);ctx.lineTo(0,235);ctx.fill()});
 sky(228,640,[[0,'#6B7040'],[1,'#3E4426']]);poly([[172,232],[190,232],[350,640],[8,640]],'#44404E',{ns:1,ne:1});for(let i=0;i<8;i++){const y=250+i*i*7+i*8;poly([[178-i*.4,y],[184+i*.4,y],[185+i*1.5,y+10+i*3],[177-i*1.5,y+10+i*3]],'#eee',{ns:1,ne:1,lw:0})}
 rrect(100,296,20,30,3,'#F4EAD0',{lw:1.4});ell(110,300,10,6,'#F0C030',{ns:1,ne:1});line([300,232],[304,200],'#3a2a22',3);
 if(u>1.0){ctx.save();ctx.translate(140,360);ctx.rotate(-.2);rrect(-34,-26,68,52,6,'#B2382E',{lw:2});ctx.strokeStyle='#E6C070';ctx.setLineDash([3,3]);ctx.strokeRect(-28,-20,56,40);ctx.setLineDash([]);rrect(-12,-14,24,14,2,'#E0A020',{ns:1,lw:1});ctx.restore();
 poly([[150,380],[250,430],[240,446],[150,396]],'#B2382E',{lw:1.6});ctx.save();ctx.translate(240,470);ctx.rotate(-.1);poly([[-40,-6],[40,-12],[44,6],[-40,10]],'#D03A32',{lw:1.6});ctx.restore();}
 if(u<1.0){const k=clamp(u/.9),sc=.15+k*1.0,cy=270+k*250;ctx.save();ctx.translate(180,cy);ctx.scale(sc,sc);rrect(-90,-20,180,70,18,'#26282F');rrect(-60,-62,120,50,16,'#30323A');rrect(-50,-54,100,34,10,'#8EA6B8');[-1,1].forEach(sd=>{glow(sd*62,18,110,'255,240,190',.6);circ(sd*62,18,16,'#FFF7D0')});rrect(-30,32,60,12,4,'#444');ctx.restore()}
 const f=u<.4?0:u<1.1?1-Math.abs(u-.75)/.35:0;ctx.fillStyle='rgba(60,60,70,'+clamp((u-.9)*.55)*.65+')';ctx.fillRect(0,0,W,H);
 if(f>0){ctx.save();ctx.globalCompositeOperation='screen';const g=ctx.createLinearGradient(0,640,360,380);for(let i=0;i<6;i++){ctx.fillStyle=`rgba(255,250,235,${clamp(f)*.55})`;ctx.beginPath();ctx.moveTo(40,640);ctx.lineTo(40+i*90-100,300);ctx.lineTo(70+i*90-100,300);ctx.fill()}ctx.fillStyle=`rgba(255,252,240,${clamp(f)*.9})`;ctx.fillRect(0,0,W,H);ctx.restore()}}
 else{const v=u-1.9;sky(0,640,[[0,'#2A3A58'],[1,'#141C2E']]);mottle('120,150,200',.2,16);blur(1,()=>{ctx.strokeStyle='#161c2a';ctx.lineWidth=6;ctx.beginPath();ctx.moveTo(330,260);ctx.lineTo(300,360);ctx.moveTo(300,360);ctx.lineTo(260,300);ctx.moveTo(300,360);ctx.lineTo(340,330);ctx.stroke();ctx.beginPath();ctx.moveTo(300,300);ctx.lineTo(300,520);ctx.stroke()});
 glow(70,130,60,'220,230,255',.5);circ(70,130,3,'#fff');
 rrect(56,304,248,12,3,'#4a3a2e');rrect(56,326,248,12,3,'#4a3a2e');rrect(66,304,10,140,2,'#3a2e24',{ns:1});rrect(284,304,10,140,2,'#3a2e24',{ns:1});
 man(180,436,1.0,{nolegs:1,aL:40,aR:40,bL:-62,bR:-62,mouth:'sad',tear:v>1?v:0,bob:v>.6?4:0,tilt:v>.6?.06:0});rrect(142,322,76,92,3,'#6a4020',{lw:2});rrect(150,330,60,76,2,'#D8CCB0',{ns:1,ne:1});girl(180,372,.5,{aL:6,aR:6,sw:40});rrect(48,440,264,16,3,'#54402f');rrect(66,456,12,110,2,'#3a2e24',{ns:1});rrect(282,456,12,110,2,'#3a2e24',{ns:1});rrect(136,458,36,84,9,'#6B7385');rrect(188,458,36,84,9,'#6B7385');ell(148,548,26,9,'#2a1d18');ell(200,548,26,9,'#2a1d18');
 sky(470,640,[[0,'rgba(10,14,24,0)'],[1,'rgba(10,14,24,.5)']]);ell(100,590,60,10,'rgba(150,180,220,.2)',{ns:1,ne:1});
 ctx.strokeStyle='rgba(200,215,240,.55)';ctx.lineWidth=1.3;const rg2=R(4);for(let i=0;i<46;i++){const x=rg2()*W,y=(rg2()*H+u*520)%H;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x-4,y+18);ctx.stroke()}}}]);
S.push([36.9,39.73,(u,d)=>{sky(0,640,[[0,'#1A2823'],[1,'#0c120f']]);mottle('90,140,120',.2,17);
 rrect(18,56,78,96,2,'#0f1a24',{lw:3,ec:'#4a3a30'});circ(54,100,16,'#E6DFC8');circ(62,96,14,'#0f1a24');for(let i=0;i<4;i++)circ(30+i*18,70+((i*13)%60),1.2,'#fff');rrect(262,108,62,76,3,'#6a4020',{lw:2});rrect(269,115,48,62,2,'#D8CCB0',{ns:1,ne:1});girl(293,152,.38,{aL:6,aR:6,sw:40});
 line([180,0],[180,58],'#222',2);poly([[154,96],[206,96],[220,58],[140,58]],'#2A7A64',{});glow(180,104,170,'255,225,140',.55);circ(180,100,14,'#FFEFB8');
 ctx.save();ctx.translate(-20,60);ctx.fillStyle='#0a0705';ctx.beginPath();ctx.ellipse(40,440,70,80,0,0,7);ctx.fill();ctx.fillStyle='#1a1410';ctx.beginPath();ctx.ellipse(40,640,160,120,0,0,7);ctx.fill();ctx.restore();
 packet(185,328,150,300,0);const dr=clamp(u/2.2);ctx.save();ctx.strokeStyle='#8a5a3a';ctx.lineWidth=2.6;ctx.lineCap='round';
 ctx.beginPath();ctx.arc(185,262,12,0,6.28*clamp(dr*4));ctx.stroke();const seg=[[[185,276],[185,316]],[[150,292],[220,292]],[[185,316],[160,356]],[[185,316],[212,356]],[[165,336],[205,336]]];
 seg.forEach((s,i)=>{const k=clamp(dr*5-i*.7-.8);if(k>0){ctx.beginPath();ctx.moveTo(s[0][0],s[0][1]);ctx.lineTo(s[0][0]+(s[1][0]-s[0][0])*k,s[0][1]+(s[1][1]-s[0][1])*k);ctx.stroke()}});ctx.restore();if(u>2.3)txt('N',185,400,28,'#fff');
 ctx.save();ctx.translate(262+Math.sin(u*8)*2,372+Math.cos(u*6)*3);ctx.rotate(-.3);rrect(-30,-10,190,110,40,'#B5784B');for(let i=0;i<3;i++)rrect(-62+i*8,-40+i*22,60,20,10,'#B5784B');rrect(-70,-24,40,6,3,'#d9a04a',{ns:1,ne:1});ctx.restore();
 glow(180,380,200,'255,225,140',.12)}]);
S.push([39.73,43.13,(u,d)=>{ctx.fillStyle='#2A63B8';ctx.fillRect(0,0,W,H);for(let i=0;i<28;i++){ctx.fillStyle=i%2?'#3274CE':'#1F58AA';ctx.beginPath();ctx.moveTo(180,370);const a0=i*.2244+u*.05,a1=a0+.2244;ctx.lineTo(180+Math.cos(a0)*800,370+Math.sin(a0)*800);ctx.lineTo(180+Math.cos(a1)*800,370+Math.sin(a1)*800);ctx.fill()}
 const r=R(8);for(let i=0;i<12;i++){const y=(r()*700-u*28*(.5+r())+700)%700;ctx.strokeStyle='rgba(255,255,255,.75)';ctx.lineWidth=1.6;ctx.beginPath();ctx.arc(r()*W,y,5+r()*10,0,7);ctx.stroke();circ(r()*W,y,2,'rgba(255,255,255,.5)')}
 const bk=back(u/.35);ctx.save();ctx.translate(180,380);ctx.scale(bk,bk);const sp=[];for(let i=0;i<48;i++){const a=i/48*6.283,rad=i%2?150:172;sp.push([Math.cos(a)*rad,Math.sin(a)*rad])}poly(sp,'#F8F3E6');ell(0,0,148,148,C.must,{lw:1.4});ell(0,0,132,132,'#1F58B0',{lw:1.4});
 packet(0,0,150,246,0,{girl:1});if(u>1.0){const k=clamp((u-1)/.9);for(let i=0;i<5;i++){const s=clamp(k*5-i);if(s>0){const bb=back(s);ctx.save();ctx.translate(-48+i*24,32);ctx.rotate((i%2?.1:-.08));ctx.scale(bb,bb);txt('NIRMA'[i],0,0,36,'#fff');ctx.restore()}}}ctx.restore();
 if(u>.25){const b=back((u-.25)/.3);ctx.save();ctx.translate(180,70);ctx.rotate(-.08);ctx.scale(b,b);txt('WASHING',3,3,56,'rgba(80,40,0,.35)');txt('WASHING',0,0,56,'#F6C934');ctx.restore()}
 if(u>.75){const b=back((u-.75)/.3);ctx.save();ctx.translate(180,130);ctx.rotate(.06);ctx.scale(b,b);txt('POWDER',3,3,62,'rgba(80,40,0,.35)');txt('POWDER',0,0,62,'#F6C934');ctx.restore()}}]);
S.push([43.13,45.67,(u,d)=>{sky(0,640,[[0,'#E39A66'],[1,'#C07448']]);mottle('255,220,170',.3,19);rrect(70,-10,115,H+20,0,'#3d8a82',{ns:1,ne:1,lw:0});rrect(185,-10,135,H+20,0,'#352628',{ns:1,ne:1});rrect(330,-10,40,H+20,0,'#A33A2C',{ns:1,ne:1});for(let i=0;i<14;i++)circ(340+((i*7)%20),20+i*45,1.6,'#fff',.6);
 rrect(255,60,76,86,2,'#F2A04A',{lw:2});line([293,60],[293,146],'#352628',3);line([255,103],[331,103],'#352628',3);glow(293,103,90,'255,170,80',.4);
 for(let i=0;i<4;i++){const y=262+i*54,a=ease((u-.1*i)/.4);line([80,y],[80+90*a,y],'#2a2024',2.6);if(a>.9){ctx.save();ctx.translate(182,y);ctx.rotate(Math.sin(u*3+i)*.08);poly([[0,0],[12,-9],[12,9]],'#D14A4A',{ns:1,lw:1});poly([[0,0],[-12,-9],[-12,9]],'#D14A4A',{ns:1,lw:1});ctx.restore()}}
 poly([[185,440],[195,432],[195,448]],'#F5A44A',{ns:1,ne:1});sky(380,640,[[0,'rgba(20,10,10,0)'],[1,'rgba(20,10,10,.35)']]);
 const k=ease(u/1.2);ctx.save();ctx.translate(120,-60+k*250);ctx.rotate(-.12);rrect(-22,-170,44,170,8,'#F4F1EA');rrect(-14,0,28,66,11,'#B5784B');ell(0,70,14,16,'#B8805A');ctx.restore()}]);
S.push([45.67,48.17,(u,d)=>{sky(0,420,[[0,'#8FBBDB'],[1,'#C2DCEA']]);mottle('255,255,255',.3,20,0,300);ell(28,130,28,28,'#F6E7A0',{ns:1,ne:1});blur(.8,()=>{for(let i=0;i<4;i++)ell(70+i*110,96+(i%2)*18,46,22,'#F3EEE2',{ns:1,ne:1})});
 line([-10,24],[W+10,26],'#555',1.2);for(let i=0;i<6;i++)cloth(24+i*62+Math.sin(u*2+i)*2,26,i%2?'dress':'shirt',Math.sin(u*2+i)*.04);
 const off=-(u*46)%360;for(let j=-1;j<3;j++){const x=off+j*360;[['#E9A6A0',0],['#8FBF98',90],['#F0A870',180],['#8AA6DA',270]].forEach((h,i)=>{rrect(x+h[1],190,88,230,2,h[0],{lw:2});rrect(x+h[1]+24,330,40,90,18,'#6a3a22',{lw:1.6});rrect(x+h[1]+12,224,26,40,2,'#2b2f4a',{lw:1.6});rrect(x+h[1]+50,224,26,40,2,'#2b2f4a',{lw:1.6});rrect(x+h[1]+6,188,76,5,1,'#fff',{ns:1,ne:1});if(u>1.3){rrect(x+h[1]+16,236,18,16,1,C.must,{ns:1,lw:1});rrect(x+h[1]+54,236,18,16,1,C.must,{ns:1,lw:1})}})}
 sky(420,640,[[0,'#B58A52'],[1,'#7C5A34']]);rrect(0,420,W,6,1,'#D8C7A0',{ns:1,ne:1});
 const by=Math.sin(u*9)*2;ctx.save();ctx.translate(150,455+by);ctx.strokeStyle=C.ink;ctx.lineWidth=3.4;[-36,36].forEach(w=>{ctx.beginPath();ctx.arc(w,0,27,0,7);ctx.stroke()});ctx.beginPath();ctx.moveTo(-36,0);ctx.lineTo(-4,-34);ctx.lineTo(36,0);ctx.moveTo(-4,-34);ctx.lineTo(-10,0);ctx.stroke();
 rrect(-52,-84,26,32,3,'#C9A678');rrect(-20,-96,26,48,12,'#F4F1EA');ell(-4,-118,15,16,'#B5784B',{lw:1.6});ctx.fillStyle=C.ink;ctx.beginPath();ctx.ellipse(-4,-124,15,10,0,Math.PI,0);ctx.fill();const pa=u*10;line([-10,-6],[-10+Math.cos(pa)*14,-6+Math.sin(pa)*14],C.ink,3);line([-8,-60],[10+Math.cos(pa)*8,-30],'#8a99b0',7);ctx.restore();
 if(u>1.8){const k=back((u-1.8)/.35);ctx.save();ctx.translate(180,98);ctx.scale(k,k);rrect(-120,-74,240,148,4,'#2A63B8');ell(-56,0,40,40,C.must,{lw:1.4});girl(-56,0,.42,{aL:75,aR:75,sw:60});packet(64,0,60,104,0,{name:1});ctx.restore()}}]);
S.push([48.17,54.43,(u,d)=>{sky(0,640,[[0,'#C7B0D6'],[.3,'#F7C79A'],[.55,'#F7E3B8'],[1,'#F2D8B0']]);mottle('255,240,200',.3,22,0,400);
 ctx.save();ctx.translate(0,-Math.min(u*3,16));glow(180,160,200,'255,244,200',.8);for(let i=0;i<16;i++){ctx.save();ctx.translate(180,160);ctx.rotate(i*.39+u*.04);ctx.fillStyle='rgba(255,246,210,.5)';ctx.beginPath();ctx.moveTo(40,-8);ctx.lineTo(420,-26);ctx.lineTo(420,26);ctx.lineTo(40,8);ctx.fill();ctx.restore()}circ(180,160,56,'#FBE9A0');
 blur(1.2,()=>{const r=R(11);for(let i=0;i<14;i++)rrect(i*28-8,300-(r()*44),26,90+r()*40,1,'#D3A0AA',{ns:1,ne:1})});
 [[0,'#334F72',170],[170,'#8A4A2F',140],[310,'#3E6A4E',100]].forEach(b=>rrect(b[0]-6,380,b[2]+6,300,1,b[1],{lw:2}));
 [[26,430],[26,510],[150,440],[240,420]].forEach((p,i)=>{rrect(p[0],p[1],28,34,2,'#8a3f2c',{lw:1.6})});rrect(58,440,28,32,2,'#9bb6d0',{lw:1.6});
 [[200,420],[234,420],[170,520],[204,520]].forEach(p=>{rrect(p[0],p[1],26,30,2,'#6a2e22',{lw:1.4});rrect(p[0]+5,p[1]+9,16,16,1,C.must,{ns:1,ne:1})});
 line([-10,350],[W+10,356],'#333',1.2);for(let i=0;i<6;i++)cloth(26+i*62+Math.sin(u*1.6+i)*2,352+i*1,i%3===0?'dress':'shirt',Math.sin(u*1.6+i)*.06);ctx.restore();
 const k=ease((u-1.3)/1.1),py=720-k*(720-170)-Math.sin(u*.8)*3;packet(180,py,150,240,0,{name:1,girl:1});
 for(let i=0;i<3;i++)line([40+((u*12+i*120)%300),80+i*24],[54+((u*12+i*120)%300),76+i*24],C.ink,1.6)}]);
const CH=[[0,'YE KAPDE'],[.5,'DHONE WALA'],[1,'WASHING POWDER'],[1.5,'EK PAPA NE'],[2,'APNI BETI KO'],[3,'KHONE KE DUKH SE'],[3.5,'BANAYA'],[4.5,'WO EK SARKARI'],[5.5,'LAB MEIN'],[6,'KAAM KARTA THA'],[7,'NAUKRI THEEK THI'],[7.5,'LEKIN WOH KUCH'],[8.5,'APNA KARNA'],[9,'CHAHTA THA'],[10,'US WAQT'],[10.5,'KAPDE SAAF KARNA'],[11.5,'BOHUT MAHENGA THA'],[12.5,'TOH USNE SOCHA'],[13,'KYUN NA AISA KUCH'],[14.5,'BANAYA JAAYE'],[15,'JO AAM GHAR BHI'],[16,'KHAREED SAKE?'],[17,'OFFICE SE LAUTKAR'],[18,'WO CHEMICALS SE'],[19,'EXPERIMENTS'],[19.5,'KARTA THA'],[20,'AAKHIR MEIN'],[20.5,'EK PEELE RANG'],[21.5,'KA POWDER'],[22,'BANA LIYA'],[22.5,'JO BOHUT SASTA'],[23.5,'AUR ACCHA THA'],[24.5,'LEKIN USKE PAAS'],[25.5,'NA FACTORY THI'],[26.5,'NA DISTRIBUTOR'],[27.5,'BAS THA TOH'],[28.5,'EK NAAM'],[29.5,'APNI BETI KA'],[31,'USKI BETI'],[31.5,'JAB CHOTI THI'],[32.5,'EK CAR'],[33,'ACCIDENT MEIN'],[33.5,'GHAYAL HO GAYI'],[34.5,'AUR WO USE'],[35.5,'BACHA NAHI PAYA'],[36.5,'TOH WO APNE'],[37,'WASHING POWDER'],[38,'APNI BETI PE RAKHA'],[39.7,''],[43,'WOH APNI BETI KO'],[44,'BADA HOTE HUE'],[44.5,'NAHI DEKH PAAYA'],[45.5,'LEKIN USNE'],[46.5,'USKA NAAM'],[47,'ITNA BADA KAR DIYA'],[48,'KI PURA BHARAT'],[49,'USKI NAAM KO'],[49.5,'PAHECHAN GAYA'],[54.43,'']];
function caption(t){const i=CH.findIndex((c,k)=>t>=c[0]&&t<(CH[k+1]?CH[k+1][0]:1e9));if(i<0||!CH[i][1])return;const s=CH[i][0],e=CH[i+1]?CH[i+1][0]:s+1,w=CH[i][1].split(' ');
 const u=t-s,sc=back(u/.12),rot=(i%2?.016:-.016);ctx.font='29px Anton, "DejaVu Sans", sans-serif';const ws=w.map(x=>ctx.measureText(x+' ').width),tw=ws.reduce((a,b)=>a+b,0)-ctx.measureText(' ').width;
 ctx.save();ctx.translate(180,484);ctx.rotate(rot);ctx.scale(sc,sc);jrect(-tw/2-16,-25,tw+32,50,'#FBF7EC',{j:2.6,sb:6});
 const ri=Math.min(w.length-1,Math.floor((t-s)/(e-s)*w.length));let x=-tw/2;w.forEach((wd,j)=>{ctx.font='29px Anton, "DejaVu Sans", sans-serif';ctx.textAlign='left';ctx.textBaseline='middle';ctx.fillStyle=j===ri?C.red:C.ink;ctx.fillText(wd,x,2);x+=ws[j]});ctx.restore()}
function drawScene(k,t){const s=S[k],u=t-s[0],p=clamp(u/(s[1]-s[0]));ctx.save();ctx.beginPath();ctx.rect(0,0,W,H);ctx.clip();const z=1+.04*p;ctx.translate(180,320);ctx.scale(z,z);ctx.translate(-180-p*4,-320);s[2](u,s[1]-s[0]);ctx.restore()}
function render(t){TNOW=t;BOIL=Math.floor(t*8)%3;ctx.setTransform(SC,0,0,SC,0,0);ctx.clearRect(0,0,W,H);
 let k=S.findIndex(s=>t>=s[0]&&t<s[1]);if(k<0)k=S.length-1;const u=t-S[k][0];
 if(k>0&&u<.16){drawScene(k-1,S[k][0]-.001);ctx.save();ctx.translate((1-ease(u/.16))*W,0);ctx.shadowColor='rgba(0,0,0,.55)';ctx.shadowBlur=24;ctx.fillStyle='#000';ctx.fillRect(-3,0,3,H);ctx.shadowColor='transparent';drawScene(k,t);ctx.restore()}else drawScene(k,t);
 ctx.save();ctx.globalAlpha=.38;ctx.globalCompositeOperation='multiply';ctx.drawImage(grain,0,0);ctx.restore();ctx.save();ctx.globalAlpha=.12;ctx.globalCompositeOperation='overlay';ctx.drawImage(grain,0,0);ctx.restore();
 const v=ctx.createRadialGradient(180,320,180,180,320,430);v.addColorStop(0,'rgba(0,0,0,0)');v.addColorStop(1,'rgba(30,14,4,.34)');ctx.fillStyle=v;ctx.fillRect(0,0,W,H);ctx.save();ctx.globalAlpha=.6;ctx.globalCompositeOperation='overlay';ctx.drawImage(crum,0,0);ctx.restore();grade();ctx.setTransform(SC,0,0,SC,0,0);caption(t)}
window.render=render;
