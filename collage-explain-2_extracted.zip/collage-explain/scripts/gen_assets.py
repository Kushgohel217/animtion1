#!/usr/bin/env python3
"""Generate paper-grain and crumple textures as PNG (reference/preview and for pipelines that want image textures).
The canvas runtime also builds these procedurally, so this script is optional."""
import numpy as np,pathlib
from PIL import Image,ImageFilter
out=pathlib.Path(__file__).resolve().parent.parent/'assets';out.mkdir(exist_ok=True);r=np.random.default_rng(3)
g=(r.normal(128,22,(1280,720))).clip(0,255).astype('uint8');Image.fromarray(g).filter(ImageFilter.GaussianBlur(.6)).save(out/'paper_grain.png')
c=np.full((1280,720),128.0)
for _ in range(60):
    x,y=r.uniform(0,720),r.uniform(0,1280)
    for _ in range(5):
        nx,ny=x+r.uniform(-120,120),y+r.uniform(-120,120);n=200
        for t in np.linspace(0,1,n):
            px,py=int(x+(nx-x)*t),int(y+(ny-y)*t)
            if 0<=px<720 and 0<=py<1280:c[py,px]+=r.choice([-14,14])
        x,y=nx,ny
Image.fromarray(c.clip(0,255).astype('uint8')).filter(ImageFilter.GaussianBlur(1.6)).save(out/'paper_crumple.png');print('wrote textures')
