#!/usr/bin/env python3
"""Wikimedia Commons fetcher: public-domain / CC only, writes IMAGE_CREDITS.md   (NOT run in the build sandbox: no network there)
python3 fetch_images.py "Gujarat 1960s street" outdir 5"""
import json,sys,urllib.parse,urllib.request,pathlib
q,out,n=sys.argv[1],pathlib.Path(sys.argv[2]),int(sys.argv[3]);out.mkdir(parents=True,exist_ok=True)
OK=('public domain','cc0','cc by','cc-by','cc by-sa','cc-by-sa')
u='https://commons.wikimedia.org/w/api.php?'+urllib.parse.urlencode({'action':'query','generator':'search','gsrsearch':q,'gsrnamespace':6,'gsrlimit':n*3,'prop':'imageinfo','iiprop':'url|extmetadata','iiurlwidth':1200,'format':'json'})
d=json.load(urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'collage-explain/1.0'})))
cred=[];k=0
for p in d.get('query',{}).get('pages',{}).values():
    ii=p['imageinfo'][0];lic=ii['extmetadata'].get('LicenseShortName',{}).get('value','').lower()
    if not lic.startswith(OK) or k>=n:continue
    f=out/(f'img{k:02d}.jpg');f.write_bytes(urllib.request.urlopen(ii['thumburl']).read());k+=1
    cred.append(f"- {f.name}: {p['title']} - {ii['extmetadata'].get('Artist',{}).get('value','unknown')} - {lic.upper()} - {ii['descriptionurl']}")
(out/'IMAGE_CREDITS.md').write_text('# Image credits\n'+'\n'.join(cred)+'\n');print(k,'images')
