#!/usr/bin/env python3
"""Cast QA: pairwise difference check (>=5 of 11 attributes) + lineup.png + silhouettes.png.
python3 scripts/check_cast.py cast.json --out qa      (needs Chromium; fails with exit 1 if two characters are too alike)"""
import json,sys,pathlib,itertools
from playwright.sync_api import sync_playwright
DIFF=['build','height_scale','head_shape','hair_style','hair_hex','skin_hex','facial_hair','glasses','outfit','outfit_colours','accessory']
cl=json.load(open(sys.argv[1]));out=sys.argv[sys.argv.index('--out')+1] if '--out' in sys.argv else 'qa'
bad=0
for a,b in itertools.combinations(cl,2):
    d=[k for k in DIFF if a.get(k)!=b.get(k)]
    if len(d)<5: bad+=1;print('TOO ALIKE:',a['id'],'vs',b['id'],'differ in only',len(d),d)
here=pathlib.Path(__file__).resolve().parent;html=here.parent/'examples'/'cast-demo'/'lineup.html'
with sync_playwright() as p:
    b=p.chromium.launch();pg=b.new_page(viewport={'width':360,'height':640});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.add_init_script('window.SCALE=2;window.CASTLIST='+json.dumps(cl))
    pg.goto(html.as_uri());pg.evaluate('window.ready')
    for m,name in(('norm','lineup'),('sil','silhouettes')):
        pg.evaluate(f"lineup('{m}')");pg.locator('#c').screenshot(path=f'{out}_{name}.png')
    b.close()
print('wrote',out+'_lineup.png',out+'_silhouettes.png');
if errs: print('PAGE ERRORS',errs);bad+=1
sys.exit(1 if bad else 0)
