No images used: all art is procedural (scripts/runtime.js). Font: Anton (OFL).
