# Idea: "Collage Explain" — the Nirma story

## One line
The same 54 s true-story explainer (a chemist's daughter, a cheap washing powder, a name that reached all of India), redrawn as a mixed-media paper collage instead of the jointed-puppet look of the reference.

## Why this story works for the style
- It is a chain of cause and effect (problem → idea → product → loss → name → legacy), so each beat can be one collage "board".
- The emotional turn (accident, rain bench, pencil-drawn name) needs very few elements, which suits collage.

## The look (new, kept separate from the reference)
- Base: cream grid paper with grain, tape strips and torn edges.
- Characters: flat cut-out figures (no jointed limbs) shown as black-and-white halftone print cut-outs with one colour accent each (red shirt/saree, yellow powder).
- Colour blocks: flat torn shapes in mustard, teal, brick red, ink blue.
- Motion: stepped "stop-motion" at about 8-12 fps for cut-outs, smooth for camera; pieces slide in, stick down with a small bounce and tape.
- Captions: torn white chip, heavy condensed caps, one red word following the voice (kept from the reference because it carries the pacing).
- Palette: cream #F3EBDD, ink #1B1A1A, red #C8372D, mustard #F2B705, teal #2E7F7A, blue #2457A6.

## Structure (14 boards, matches the reference beats)
1 Laundry day · 2 Lab · 3 Office · 4 Price shock · 5 Idea · 6 Home experiments · 7 No factory · 8 The photo · 9 Daughter · 10 Accident · 11 Rain bench · 12 Naming · 13 Brand reveal · 14 Growth wall → India.

## Constraints
- 9:16 and 16:9 from one HTML timeline (16:9 re-laid out, not cropped).
- Draft 720p/15 fps for approval, final 1080p/30 fps only after "render it".
- Voice: Hinglish. See open question in script.md.
