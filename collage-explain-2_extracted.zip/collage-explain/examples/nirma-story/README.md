# Nirma story (approved draft)
Files: index.html (loads ../../scripts/runtime.js), work/words.json (caption chips and start times), idea.md, script.md, approved_draft_720p_15fps.mp4 (the approved render, uses the reference narration).
```bash
# audio: extract the narration from the reference video you studied
ffmpeg -i reference.mp4 -vn -ac 2 -ar 44100 narration.wav
python3 ../../scripts/render.py --html index.html --audio narration.wav --fps 15 --scale 2 --out draft.mp4
python3 ../../scripts/render.py --html index.html --audio narration.wav --fps 30 --scale 3 --out final.mp4   # after "render it"
ffprobe -v error -show_entries stream=codec_name,width,height,r_frame_rate:format=duration -of default=nw=1 final.mp4
```
