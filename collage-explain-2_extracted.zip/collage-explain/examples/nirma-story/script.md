# Script — Nirma story (Hinglish, ~54 s)
Taken from the on-screen captions of the reference video, not from a listening pass, so spellings may differ from the spoken words. Times are approximate (0.5 s steps).

| Time | Narration | Board / visual |
|---|---|---|
| 0.0–1.5 | Ye kapde dhone wala washing powder | Laundry line, powder poured into bucket |
| 1.5–4.4 | Ek papa ne apni beti ko khone ke dukh se banaya | Father, daughter enters, he turns sad |
| 4.4–6.5 | Wo ek sarkari lab mein kaam karta tha | Lab bench, beaker, "GUJARAT · 1960s" tag |
| 6.5–9.9 | Naukri theek thi, lekin woh kuch apna karna chahta tha | Office desk, stamp, lit window |
| 9.9–12.5 | Us waqt kapde saaf karna bohut mahenga tha | Shop, ₹₹₹ tag grows |
| 12.5–16.9 | Toh usne socha, kyun na aisa kuch banaya jaaye jo aam ghar bhi khareed sake? | Bulb, houses build, packet drops |
| 16.9–20.5 | Office se lautkar wo chemicals se experiments karta tha | 1969 yard, basin, lantern |
| 20.5–24.4 | Aakhir mein ek peele rang ka powder bana liya, jo bohut sasta aur accha tha | Yellow burst, coins, box |
| 24.4–27.5 | Lekin uske paas na factory thi, na distributor | Street lamp, dotted factory and truck |
| 27.5–30.9 | Bas tha toh ek naam, apni beti ka | Pocket photo, close-up |
| 30.9–32.6 | Uski beti jab choti thi | Doorstep, girl twirls |
| 32.6–34.5 | Ek car accident mein ghayal ho gayi | Road, headlight flash, bag and ribbon |
| 34.5–36.9 | Aur wo use bacha nahi paya | Rain bench, framed photo, tear |
| 36.9–39.7 | Toh wo apne washing powder pe apni beti ka naam rakha | Night room, pencil draws her on packet |
| 39.7–43.1 | WASHING POWDER — NIRMA | Brand reveal, bubbles, burst badge |
| 43.1–45.7 | Woh apni beti ko bada hote hue nahi dekh paaya | Height-chart wall, finger points |
| 45.7–48.2 | Lekin usne uska naam itna bada kar diya | Bicycle street, billboard |
| 48.2–54.4 | Ki pura Bharat uski naam ko pehchan gaya | Rooftop sunset, giant packet, held end |

## Script analysis
- Pace: about 3.3 words per second, one clause per board, so each board lasts 2-4 s.
- Hook: the product is shown in the first second and the emotional reason arrives by 4 s.
- Arc: problem (0-12) → idea and build (12-24) → obstacle (24-27) → personal loss (27-37) → name and payoff (37-54).
- Emotional peak at 34.5-36.9, followed by a hard cut to a warm, hopeful scene.
- Open item: line 14 ("apne washing powder pe") and a few other captions look slightly ungrammatical; I kept them as captioned until you confirm wording.
