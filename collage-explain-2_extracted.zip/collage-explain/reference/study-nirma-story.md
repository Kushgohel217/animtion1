# Study: reference video (54.43 s, 720x1280, 30 fps, AAC 44.1 kHz stereo, Hinglish narration)
Sampled every 0.5 s (109 frames). Fast motion between samples is inferred.

## Boards (cuts confirmed by scene-change detection)
| Time | Board | Key motion |
|---|---|---|
| 0-4.37 | Laundry sunset | pours powder, camera pans right, daughter walks in from right at 2.0, smile -> worried, waves |
| 4.37-6.57 | Lab 1960s | "GUJARAT 1960s" tag ~4.9, LAB sign swings in ~5.5, pours beaker |
| 6.57-9.87 | Office | stamping arm, window lamp lights ~8.5, slow push-in on window 9.0-9.9 |
| 9.87-12.5 | Shop | price tag pops and grows 11.5, customer calm -> shocked -> sad |
| 12.5-16.93 | Idea night | bulb pops 13.0, five houses build, packet drops, windows light |
| 16.93-24.4 | 1969 yard | stirs basin, powder burst 21.0-21.5, box + coins 23.0, sparkles 24.0 |
| 24.4-30.9 | Street lamp | dotted factory/truck, push-in to chest 27.5, pocket photo, macro fingers |
| 30.9-32.6 | Doorstep | daughter twirls, father laughs |
| 32.6-36.9 | Road then rain | headlight flash 33.0, bag+ribbon, desaturate, bench, tear 35.5 |
| 36.9-39.73 | Night room | first-person hand draws daughter on packet |
| 39.73-43.13 | Sunburst | badge, bubbles, WASHING POWDER, NIRMA letters ~40.5-41 |
| 43.13-45.67 | Height wall | ribbon marks, finger points |
| 45.67-48.17 | Street bicycle | parallax houses, packets in windows 47.0, billboard 47.5 |
| 48.17-54.43 | Rooftop sunset | rays, laundry lines, giant packet rises ~49.5, slow drift |

## Puppet
Separate cut-outs (head, torso, sleeves, forearms, hands, legs) pinned with brass brads at shoulders, elbows, knees; white cut-edge outline; faces swapped per mood, not tweened.

## Captions
Torn-paper strip, Anton-like heavy condensed caps, lower third, one red word that follows the voice, 2-3 words per chip, chip changes every 0.5-1.0 s.

## Audio
Continuous narration, no pauses > 0.35 s, 139 detected word onsets (~3.3 per second), integrated loudness -14.1 LUFS, true peak -1.0 dBFS. Music/effects were not separated (needs listening or stem separation).
