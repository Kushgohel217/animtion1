# Notes 01 - method
- ffmpeg fps=2 -> 109 frames, 3x2 contact sheets with timestamps; every sheet viewed.
- Scene cuts: ffmpeg select='gt(scene,0.35)'. Loudness: ebur128. Onsets: RMS envelope difference on 16 kHz mono (threshold 0.012, min gap 0.18 s).
- Sync check: nearest speech onset minus caption start -> median +0.04 s, mean abs 0.11 s over 58 chips; only 17.0 s and 43.0 s are 0.34 s off.
- Side-by-side reference/render strips at identical timestamps drive every fix (see SKILL.md lessons).
- Captions were transcribed from on-screen text, not from listening; spellings may differ from speech.
