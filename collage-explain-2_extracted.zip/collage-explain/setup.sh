#!/usr/bin/env bash
set -e
command -v ffmpeg >/dev/null || { echo "install ffmpeg first"; exit 1; }
pip install playwright pillow numpy scipy
pip install faster-whisper   # only needed for scripts/transcribe.py
python3 -m playwright install chromium
python3 scripts/make_sfx.py && python3 scripts/gen_assets.py
echo "ready"
